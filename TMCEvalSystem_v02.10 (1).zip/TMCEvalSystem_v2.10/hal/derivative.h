#ifndef _DERIVATIVE_H_
	#define  _DERIVATIVE_H_

//	#define Landungsbruecke
//	#define Startrampe

	#include <stdlib.h>
	#include "makeFor.h"
	#include "hal/typedefs.h"
	#include "hal/bits.h"

	#if defined(Startrampe)
		#define MODULE_ID "0011"
		#include "stm32f2xx.h"
	#elif defined(Landungsbruecke)
		#define MODULE_ID "0012"
		#include <MK20D10.h>
		#include "hal/Landungsbruecke/freescale/Cpu.h"
		#include "hal/Landungsbruecke/freescale/nvic.h"
		#define CPU_LITTLE_ENDIAN
		#define __MK_xxx_H__
	#endif

#endif
