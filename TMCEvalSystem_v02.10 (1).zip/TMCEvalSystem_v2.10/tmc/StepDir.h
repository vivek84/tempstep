#ifndef _STEP_DIR_H_
	#define _STEP_DIR_H_


	#define STEP_DIR_NO_CHANNELS 				2
	#define STEP_DIR_HALT_ALL					0

	#define UNBOND_STEP_DIR_PIN 				3
	#define IS_STEP_DIR_PIN_BOND(bitWeight) 	(bitWeight != 3)



	#include "../hal/hal.h"

	typedef enum {SD_RAMP_MODE_VELOCITY, SD_RAMP_MODE_POSITIONING} TRampMode;
	typedef enum {RAMP_IDLE, RAMP_ACCELERATE, RAMP_DRIVING, RAMP_DECELERATE} TRampState;

	typedef struct
	{
		volatile int 			actualVelocity;
		volatile int 			actualAcceleration;
		volatile int 			actualPosition;
		volatile int 			targetVelocity;
		volatile int 			targetPosition;
		volatile int 			maxPositioningSpeed;
		volatile TRampMode		rampMode;
		volatile unsigned char 	targetReached;
		volatile int 			stopOnStallVelocityTreshold;
		volatile int 			coolStepVelocityTreshold;
		IOPinTypeDef		*stepOut;
		IOPinTypeDef		*dirOut;
		IOPinTypeDef		*stallSignalIn;
		volatile uint8		stallFlagIn;
		volatile uint8		haltMask;
		volatile uint32		coolStepActiveValue;
		volatile uint32		coolStepInActiveValue;
		volatile uint32		coolStepActualValue;
		volatile uint8		stopOnStallActive;
		volatile int32 		profileFrom;
		volatile int32 		profileTo;
		volatile uint8 		useProfile;
		void (*coolStepActivationChanged) (uint32 active);

	} StepDirectionChannelType;

	typedef struct
	{
		volatile int32 				positionAccu;  		// position accumulator for computing velocity
		volatile int32 				positionAdd;
		volatile int32 				velocityAccu;  		// position accumulator for computing velocity
		volatile int32 				velocityAdd;
		volatile TRampState 		rampState;
		volatile int32 				accelerationSteps;
		StepDirectionChannelType	channel;
	} StepDirectionCtrlType;

	typedef struct
	{
		StepDirectionChannelType *ch1;
		StepDirectionChannelType *ch2;
		void (*init) (void);
		void (*deInit) (void);
	}

	StepDirectionTypeDef;

	StepDirectionTypeDef StepDir;

#endif
