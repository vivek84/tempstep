#include "TMC5062_tablet.h"
#include "../hal/HAL.h"
#include "../tmc/WTMCL.h"
#include "../tmc/TMCL.h"
#include "boards/TMC5062.h"



//SEARCH FOR UFO 4!



#define STATES_START 					1
#define STATES_VELOCITY 				2
#define STATES_DRIVER_STATE 			3
#define STATES_RAMP_STATE				4
#define STATES_SIX_POINT_RAMP			5
#define STATES_STALLGUARD				6
#define STATES_REFSEARCH				7
#define STATES_COOLSTEP					8
#define STATES_MOTOR_SINE_TABLE			9
#define STATES_MOTOR_TRIANGLE_TABLE		10
#define STATES_DC_STEP					11
#define STATES_DC_STEP_STOP_ON_STALL	12
#define STATES_LOAD_ANGLE				13
#define STATES_LOAD_ANGLE_COOL			14
#define STATES_MICROSTEPPING			15

static void setStateToSTATES_START(char set);
static void setStateToSTATES_VELOCITY(char set);
static void setStateToSTATES_DRIVER_STATE(char set);
static void setStateToSTATES_RAMP_STATE(char set);
static void setStateToSTATES_SIX_POINT_RAMP(char set);
static void setStateToSTATES_STALLGUARD(char set);
static void setStateToSTATES_REFSEARCH(char set);
static void setStateToSTATES_COOLSTEP(char set);
static void setStateToSTATES_MOTOR_SINE_TABLE(char set);
static void setStateToSTATES_MOTOR_TRIANGLE_TABLE(char set);
static void setStateToSTATES_DC_STEP(char set);
static void setStateToSTATES_DC_STEP_STOP_ON_STALL(char set);
static void setStateToSTATES_LOAD_ANGLE(char set);
static void setStateToSTATES_LOAD_ANGLE_COOL(char set);
static void setStateToSTATES_MICROSTEPPING(char set);

static void mealySTATES_START();
static void mealySTATES_VELOCITY();
static void mealySTATES_DRIVER_STATE();
static void mealySTATES_RAMP_STATE();
static void mealySTATES_SIX_POINT_RAMP();
static void mealySTATES_STALLGUARD();
static void mealySTATES_REFSEARCH();
static void mealySTATES_COOLSTEP();
static void mealySTATES_MOTOR_SINE_TABLE();
static void mealySTATES_MOTOR_TRIANGLE_TABLE();
static void mealySTATES_DC_STEP();
static void mealySTATES_DC_STEP_STOP_ON_STALL();
static void mealySTATES_LOAD_ANGLE();
static void mealySTATES_LOAD_ANGLE_COOL();
static void mealySTATES_MICROSTEPPING();

static void mooreSTATES_START();
static void mooreSTATES_VELOCITY();
static void mooreSTATES_DRIVER_STATE();
static void mooreSTATES_RAMP_STATE();
static void mooreSTATES_SIX_POINT_RAMP();
static void mooreSTATES_STALLGUARD();
static void mooreSTATES_REFSEARCH();
static void mooreSTATES_COOLSTEP();
static void mooreSTATES_MOTOR_SINE_TABLE();
static void mooreSTATES_MOTOR_TRIANGLE_TABLE();
static void mooreSTATES_DC_STEP();
static void mooreSTATES_DC_STEP_STOP_ON_STALL();
static void mooreSTATES_LOAD_ANGLE();
static void mooreSTATES_LOAD_ANGLE_COOL();
static void mooreSTATES_MICROSTEPPING();

static void init();
static void setState();
static void processPackage();
static void periodicJob();

typedef struct
{
	unsigned char state;
	unsigned char nextState;
	void (*onStateChange)(char);
	void (*mealy)(void);
	void (*moore)(void);
	void (*setState)(void);
} CTRLTypeDef;


static CTRLTypeDef CTRL =
{
	.state			= STATES_START,
	.nextState 		= STATES_START,
	.setState 		= setState,
	.onStateChange	= setStateToSTATES_START,
	.mealy			= mealySTATES_START,
	.moore			= mealySTATES_START,
};

DemoBoardsTypeDef TMC5062Demo =
{
	.init = init
};

static void init()
{
	WTMCL.in->type = STATES_START;
	CTRL.setState();
	WTMCL.periodicJob_delegate 		= periodicJob;
	WTMCL.processPackage_delegate 	= processPackage;
}

static void processPackage()
{
	if(WTMCL.in->error) return;
	CTRL.setState();
	CTRL.mealy();
}

static void periodicJob()
{
	CTRL.moore();
}

static void setState()
{
	if((CTRL.nextState = WTMCL.in->type) == CTRL.state) return;
	CTRL.onStateChange(0);

	switch(CTRL.nextState)
	{
		case STATES_START:
			CTRL.onStateChange	= setStateToSTATES_START;
			CTRL.mealy 			= mealySTATES_START;
			CTRL.moore 			= mooreSTATES_START;
		break;

		case STATES_VELOCITY:
			CTRL.onStateChange	= setStateToSTATES_VELOCITY;
			CTRL.mealy 			= mealySTATES_VELOCITY;
			CTRL.moore 			= mooreSTATES_VELOCITY;
		break;

		case STATES_DRIVER_STATE:
			CTRL.onStateChange	= setStateToSTATES_DRIVER_STATE;
			CTRL.mealy 			= mealySTATES_DRIVER_STATE;
			CTRL.moore 			= mooreSTATES_DRIVER_STATE;
		break;

		case STATES_RAMP_STATE:
			CTRL.onStateChange	= setStateToSTATES_RAMP_STATE;
			CTRL.mealy 			= mealySTATES_RAMP_STATE;
			CTRL.moore 			= mooreSTATES_RAMP_STATE;
		break;

		case STATES_SIX_POINT_RAMP:
			CTRL.onStateChange	= setStateToSTATES_SIX_POINT_RAMP;
			CTRL.mealy 			= mealySTATES_SIX_POINT_RAMP;
			CTRL.moore 			= mooreSTATES_SIX_POINT_RAMP;
		break;

		case STATES_STALLGUARD:
			CTRL.onStateChange	= setStateToSTATES_STALLGUARD;
			CTRL.mealy 			= mealySTATES_STALLGUARD;
			CTRL.moore 			= mooreSTATES_STALLGUARD;
		break;

		case STATES_REFSEARCH:
			CTRL.onStateChange	= setStateToSTATES_REFSEARCH;
			CTRL.mealy 			= mealySTATES_REFSEARCH;
			CTRL.moore 			= mooreSTATES_REFSEARCH;
		break;

		case STATES_COOLSTEP:
			CTRL.onStateChange	= setStateToSTATES_COOLSTEP;
			CTRL.mealy 			= mealySTATES_COOLSTEP;
			CTRL.moore 			= mooreSTATES_COOLSTEP;
		break;

		case STATES_MOTOR_SINE_TABLE:
			CTRL.onStateChange	= setStateToSTATES_MOTOR_SINE_TABLE;
			CTRL.mealy 			= mealySTATES_MOTOR_SINE_TABLE;
			CTRL.moore 			= mooreSTATES_MOTOR_SINE_TABLE;
		break;

		case STATES_MOTOR_TRIANGLE_TABLE:
			CTRL.onStateChange	= setStateToSTATES_MOTOR_TRIANGLE_TABLE;
			CTRL.mealy 			= mealySTATES_MOTOR_TRIANGLE_TABLE;
			CTRL.moore 			= mooreSTATES_MOTOR_TRIANGLE_TABLE;
		break;

		case STATES_DC_STEP:
			CTRL.onStateChange	= setStateToSTATES_DC_STEP;
			CTRL.mealy 			= mealySTATES_DC_STEP;
			CTRL.moore 			= mooreSTATES_DC_STEP;
		break;

		case STATES_DC_STEP_STOP_ON_STALL:
			CTRL.onStateChange	= setStateToSTATES_DC_STEP_STOP_ON_STALL;
			CTRL.mealy 			= mealySTATES_DC_STEP_STOP_ON_STALL;
			CTRL.moore 			= mooreSTATES_DC_STEP_STOP_ON_STALL;
		break;

		case STATES_LOAD_ANGLE:
			CTRL.onStateChange	= setStateToSTATES_LOAD_ANGLE;
			CTRL.mealy 			= mealySTATES_LOAD_ANGLE;
			CTRL.moore 			= mooreSTATES_LOAD_ANGLE;
		break;

		case STATES_LOAD_ANGLE_COOL:
			CTRL.onStateChange	= setStateToSTATES_LOAD_ANGLE_COOL;
			CTRL.mealy 			= mealySTATES_LOAD_ANGLE_COOL;
			CTRL.moore 			= mooreSTATES_LOAD_ANGLE_COOL;
		break;

		case STATES_MICROSTEPPING:
			CTRL.onStateChange	= setStateToSTATES_MICROSTEPPING;
			CTRL.mealy 			= mealySTATES_MICROSTEPPING;
			CTRL.moore 			= mooreSTATES_MICROSTEPPING;
		break;
	}

	CTRL.onStateChange(1);
	CTRL.state = CTRL.nextState;
}

static void setStateToSTATES_START(char set)
{
	if(!set) return;
// stop motors
	TMCL.command->Motor = 0;	// MOTOR 1
	EvalBoards.ch1.motorStop();

	TMCL.command->Motor = 1;
	EvalBoards.ch1.motorStop();		// MOTOR 2

// setStateTo max accelearation datagram
	TMCL.command->Opcode		= TMCL_SAP;
	TMCL.command->Type 			= 5;
	TMCL.command->Value.Int32 	= (int) 100000;
	TMCL.command->Motor 		= 0;	// MOTOR 1
	EvalBoards.ch1.setAxisParameter();

	TMCL.command->Opcode		= TMCL_SAP;
	TMCL.command->Type 			= 5;
	TMCL.command->Value.Int32 	= (int) 100000;
	TMCL.command->Motor 		= 1;	// MOTOR 2
	EvalBoards.ch1.setAxisParameter();

// setStateTo max current datagram
	TMCL.command->Opcode		= TMCL_SAP;
	TMCL.command->Type 			= 6;
	TMCL.command->Value.Int32 	= (int) 23;
	TMCL.command->Motor 		= 0;	// MOTOR 1
	EvalBoards.ch1.setAxisParameter();

// setStateTo max current datagram
	TMCL.command->Opcode		= TMCL_SAP;
	TMCL.command->Type 			= 6;
	TMCL.command->Value.Int32 	= (int) 23;
	TMCL.command->Motor 			= 1;	// MOTOR 2
	EvalBoards.ch1.setAxisParameter();

	TMCL.command->Type 			= 0x33;
	TMCL.command->Value.Int32	= 0;
	EvalBoards.ch1.writeRegister();

	TMCL.command->Type 			= 0x34;
	TMCL.command->Value.Int32	= 0;
	EvalBoards.ch1.writeRegister();
}

static void mealySTATES_START()
{

}

static void mooreSTATES_START()
{
//	HAL.LEDs->error.on();
}


static void setStateToSTATES_VELOCITY(char set)
{
	if(set) setStateToSTATES_START(set);
}

static void mealySTATES_VELOCITY()
{

	if(WTMCL.in->value < 400000)
	{
		if((WTMCL.in->number == 1) || (WTMCL.in->number == 2))
		{
			TMCL.command->Opcode		= TMCL_ROR;
			TMCL.command->Type 			= 0;
			TMCL.command->Motor 		= WTMCL.in->number-1;
			TMCL.command->Value.Int32 	= (int)  WTMCL.in->value;
			EvalBoards.ch1.rotateRight();
		}
	}
}

static void mooreSTATES_VELOCITY()
{
	// get measured speed
		TMCL.command->Motor	= 1;
		EvalBoards.ch1.getMeasuredSpeed();

		WTMCL.out->type		= CTRL.state;
		WTMCL.out->number	= 1;
		WTMCL.out->value	= TMCL.reply->Value.Int32;
		WTMCL.out->error	= 0;
		WTMCL.tx();
//	HAL.LEDs->error.off();
}


static void setStateToSTATES_DRIVER_STATE(char set)
{
	UNUSED(set);
}

static void mealySTATES_DRIVER_STATE()
{

}

static void mooreSTATES_DRIVER_STATE()
{
//	HAL.LEDs->error.toggle();

	TMCL.command->Type 		= 0x7F;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();

	WTMCL.out->type	= CTRL.state;
	WTMCL.out->number	= 1;
	WTMCL.out->value	= TMCL.reply->Value.Int32;
	WTMCL.out->error	= 0;
	WTMCL.tx();
}


static void setStateToSTATES_RAMP_STATE(char set)
{
	UNUSED(set);
}

static void mealySTATES_RAMP_STATE()
{

}

static void mooreSTATES_RAMP_STATE()
{
//	HAL.LEDs->error.on();

	TMCL.command->Type 		= 0x55;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();

	WTMCL.out->type	= CTRL.state;
	WTMCL.out->number	= 1;
	WTMCL.out->value	= TMCL.reply->Value.Int32;
	WTMCL.out->error	= 0;
	WTMCL.tx();

	TMCL.command->Type 		= 0x41;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();

	WTMCL.out->type	= CTRL.state;
	WTMCL.out->number	= 2;
	WTMCL.out->value	= TMCL.reply->Value.Int32;
	WTMCL.out->error	= 0;
	WTMCL.tx();


	TMCL.command->Type 		= 0x56;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();

	WTMCL.out->type	= CTRL.state;
	WTMCL.out->number	= 3;
	WTMCL.out->value	= TMCL.reply->Value.Int32;
	WTMCL.out->error	= 0;
	WTMCL.tx();
}


static void setStateToSTATES_SIX_POINT_RAMP(char set)
{
	if(!set)
	{
	// set RAMPMODE bit in RAMP GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x20;			// MOTOR 1
		TMCL.command->Value.Int32	= 1; 			// velocity mode
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x40;			// MOTOR 1
		TMCL.command->Value.Int32	= 1; 			// velocity mode
		EvalBoards.ch1.writeRegister();


	// set velocity datagram
		TMCL.command->Motor 		= 0;
		TMCL.command->Value.Int32 	= 159072;		// 1rpm
		EvalBoards.ch1.rotateRight();

	// set velocity datagram
		TMCL.command->Motor 		= 1;
		TMCL.command->Value.Int32 	= 159072;		// 1rpm
		EvalBoards.ch1.rotateRight();
	}
	else
	{
		setStateToSTATES_START(1);

	// stopMotors
		TMCL.command->Motor 		= 0;
		EvalBoards.ch1.motorStop();
		TMCL.command->Motor 		= 1;
		EvalBoards.ch1.motorStop();

	// set D1 in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x2A;			// MOTOR 1
		TMCL.command->Value.Int32	= 2000; 		// D1
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x4A;			// MOTOR 2
		TMCL.command->Value.Int32	= 9000; 		// D1
		EvalBoards.ch1.writeRegister();

	// set VSTOP in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x2B;			// MOTOR 1
		TMCL.command->Value.Int32	= 1; 			// VSTOP
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x4B;			// MOTOR 2
		TMCL.command->Value.Int32	= 1; 			// VSTOP
		EvalBoards.ch1.writeRegister();

	// set Target
		TMCL.command->Type 			= 0x2D;			// MOTOR 1
		TMCL.command->Value.Int32	= 1500000; 		// actual settings
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x4D;			// MOTOR 2
		TMCL.command->Value.Int32	= 1500000; 		// actual settings
		EvalBoards.ch1.writeRegister();


	// set VSTART in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x23;			// MOTOR 1
		TMCL.command->Value.Int32	= 0; 			// VSTART
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x43;			// MOTOR 2
		TMCL.command->Value.Int32	= 0; 			// VSTART
		EvalBoards.ch1.writeRegister();


	// set A1 in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x24;			// MOTOR 1
		TMCL.command->Value.Int32	= 2000; 		// A1
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x44;			// MOTOR 2
		TMCL.command->Value.Int32	= 9000; 		// A1
		EvalBoards.ch1.writeRegister();

	// set V1 in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x25;			// MOTOR 1
		TMCL.command->Value.Int32	= 500000; 		// V1
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x45;			// MOTOR 2
		TMCL.command->Value.Int32	= 350001; 		// V1
		EvalBoards.ch1.writeRegister();

	// set AMAX in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x26;			// MOTOR 1
		TMCL.command->Value.Int32	= 2000; 		// AMAX
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x46;			// MOTOR 2
		TMCL.command->Value.Int32	= 2000; 		// AMAX
		EvalBoards.ch1.writeRegister();

	// set DMAX in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x28;			// MOTOR 1
		TMCL.command->Value.Int32	= 2000; 		// DMAX
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x48;			// MOTOR 2
		TMCL.command->Value.Int32	= 2000; 		// DMAX
		EvalBoards.ch1.writeRegister();

	// preset actual position in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x21;			// MOTOR 1
		TMCL.command->Value.Int32	= 1500000; 		// preset
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x41;			// MOTOR 2
		TMCL.command->Value.Int32	= 1500000; 		// preset
		EvalBoards.ch1.writeRegister();
	}
}

static void mealySTATES_SIX_POINT_RAMP()
{
	if(WTMCL.in->number == 1)
	{

	// set RAMPMODE bit in RAMP GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x20;			// MOTOR 1
		TMCL.command->Value.Int32	= 0; 			// A,D,V positioning
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x40;			// MOTOR 1
		TMCL.command->Value.Int32	= 0; 			// A,D,V positioning
		EvalBoards.ch1.writeRegister();


	// set VMAX in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x27;			// MOTOR 1
		TMCL.command->Value.Int32	= 500001; 		// VMAX
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x47;			// MOTOR 2
		TMCL.command->Value.Int32	= 500001; 		// VMAX
		EvalBoards.ch1.writeRegister();

	// set Target by set register datagram
		TMCL.command->Type 			= 0x2D;			// MOTOR 1
		TMCL.command->Value.Int32	= 1500000; 		// actual settings
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x4D;			// MOTOR 2
		TMCL.command->Value.Int32	= 1500000; 		// actual settings
		EvalBoards.ch1.writeRegister();

	// reset actual position XACTUAL in GENERATOR MOTION CONTROL REGISTER SET by set register datagram
		TMCL.command->Type 			= 0x21;			// MOTOR 1
		TMCL.command->Value.Int32	= 0; 			// XACTUAL
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x41;			// MOTOR 2
		TMCL.command->Value.Int32	= 0; 			// XACTUAL
		EvalBoards.ch1.writeRegister();

	}
}

static void mooreSTATES_SIX_POINT_RAMP()
{
//	HAL.LEDs->error.off();

	// get measured speed
		TMCL.command->Motor	= 0;
		EvalBoards.ch1.getMeasuredSpeed();

		WTMCL.out->type	= CTRL.state;
		WTMCL.out->number	= 1;
		WTMCL.out->value	= TMCL.reply->Value.Int32;
		WTMCL.out->error	= 0;
		WTMCL.tx();

		WTMCL.out->type	= CTRL.state;
		WTMCL.out->number	= 1;
		WTMCL.out->value	= TMCL.reply->Value.Int32 & 0xFFFFFF;
		WTMCL.out->error	= 0;
		WTMCL.tx();

	// get measured speed
		TMCL.command->Motor	= 1;
		EvalBoards.ch1.getMeasuredSpeed();

		WTMCL.out->type	= CTRL.state;
		WTMCL.out->number	= 2;
		WTMCL.out->value	= TMCL.reply->Value.Int32;
		WTMCL.out->error	= 0;
		WTMCL.tx();

//	TMCL.command->Type 		= 0x22;
//	EvalBoards.ch1.readRegister();
//	EvalBoards.ch1.readRegister();
//
//	WTMCL.out->type	= CTRL.state;
//	WTMCL.out->number	= 1;
//	WTMCL.out->value	= TMCL.reply->Value.Int32 & 0xFFFFFF;
//	WTMCL.out->error	= 0;
//	WTMCL.tx();
//
//	TMCL.command->Type 		= 0x42;
//	EvalBoards.ch1.readRegister();
//	EvalBoards.ch1.readRegister();
//
//	WTMCL.out->type	= CTRL.state;
//	WTMCL.out->number	= 2;
//	WTMCL.out->value	= TMCL.reply->Value.Int32 & 0xFFFFFF;
//	WTMCL.out->error	= 0;
//	WTMCL.tx();

	TMCL.command->Type 		= 0x21;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();

	WTMCL.out->type	= CTRL.state;
	WTMCL.out->number	= 3;
	WTMCL.out->value	= TMCL.reply->Value.Int32;
	WTMCL.out->error	= 0;
	WTMCL.tx();

	TMCL.command->Type 		= 0x41;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();

	WTMCL.out->type	= CTRL.state;
	WTMCL.out->number	= 4;
	WTMCL.out->value	= TMCL.reply->Value.Int32;
	WTMCL.out->error	= 0;
	WTMCL.tx();
}


static void setStateToSTATES_STALLGUARD(char set)
{

// stop motors
	TMCL.command->Motor 		= 0;
	EvalBoards.ch1.motorStop();

	TMCL.command->Motor			= 1;
	EvalBoards.ch1.motorStop();

// unset COOLCONF register by set register datagram
	TMCL.command->Type 			= 0x6D;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();
	TMCL.command->Value.Int32	= 	TMCL.reply->Value.Int32; 	// actual settings
	TMCL.command->Value.Int32	&= (int) ~(0x7F<<16);			// unset stallGuard 2 threshold
	TMCL.command->Value.Int32	&= (int) ~(1<<24);				// unset stallguard filter
	TMCL.command->Value.Int32	&= (int) ~(1<<15);				// unset seimin -> 1/2 current
	TMCL.command->Value.Int32	&= (int) ~(3<<13);				// unset sedn

	if(!set) return;

// set velocity datagram
	TMCL.command->Motor 		= 0;
	TMCL.command->Value.Int32 	= 159072;		// 1rpm
	EvalBoards.ch1.rotateRight();

// set COOLCONF register by set register datagram
	TMCL.command->Type 			= 0x6D;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();
	TMCL.command->Value.Int32	|= (2 & 0x7F)<<16;				// set stallGuard 2 threshold
	TMCL.command->Value.Int32	|= (1<<24);						// set stallguard filter
	EvalBoards.ch1.writeRegister();
}

static void mealySTATES_STALLGUARD()
{

}

static void mooreSTATES_STALLGUARD()
{
//	HAL.LEDs->error.toggle();

	TMCL.command->Type 		= 0x6F;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();

	WTMCL.out->type		= CTRL.state;
	WTMCL.out->number	= 1;
	WTMCL.out->value	= TMCL.reply->Value.Int32;
	WTMCL.out->error	= 0;
	WTMCL.tx();
}


static void setStateToSTATES_REFSEARCH(char set)
{
	setStateToSTATES_STALLGUARD(set);

	if(!set)
	{
	// unset SG_STOP bit in SW_MODE register by set register datagram
		TMCL.command->Type 			= 0x34;
		EvalBoards.ch1.readRegister();
		EvalBoards.ch1.readRegister();
		TMCL.command->Value.Int32	= 	TMCL.reply->Value.Int32; 	// actual settings
		TMCL.command->Value.Int32	&= (int) ~(1<<10);				// unset SG_STOP
		EvalBoards.ch1.writeRegister();
	}
	else
	{
	// set SG_STOP bit in SW_MODE register by set register datagram
		TMCL.command->Type 			= 0x34;
		EvalBoards.ch1.readRegister();
		EvalBoards.ch1.readRegister();
		TMCL.command->Value.Int32	= TMCL.reply->Value.Int32; 	// actual settings
		TMCL.command->Value.Int32	|= 1<<10;					// enable SG_STOP
		EvalBoards.ch1.writeRegister();
	}

}

static void mealySTATES_REFSEARCH()
{


}

static void mooreSTATES_REFSEARCH()
{
	mooreSTATES_STALLGUARD();
//	HAL.LEDs->error.on();
}


static void setStateToSTATES_COOLSTEP(char set)
{
	setStateToSTATES_STALLGUARD(set);


// set COOLCONF register by set register datagram
	TMCL.command->Type 			= 0x6D;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();
	TMCL.command->Value.Int32	= TMCL.reply->Value.Int32; 		// actual settings
	TMCL.command->Value.Int32	&= (int) ~(0x0F<<8);			// unset stallGuard2 hysteresis width
	TMCL.command->Value.Int32	&= (int) ~(0x01<<1); 			// unset seimin
	TMCL.command->Value.Int32	&= (int) ~(0x0F<<0);			// unset stallGuard2 hysteresis start
	EvalBoards.ch1.writeRegister();

	if(!set) return;

	TMCL.command->Type 			= 0x6D;
	EvalBoards.ch1.readRegister();
	EvalBoards.ch1.readRegister();
	TMCL.command->Value.Int32	|= 	(2 & 0x7F)<<16; 			// set stallGuard2 threshold value
	TMCL.command->Value.Int32	|= 	(0 & 0x0F)<<8; 				// set stallGuard2 hysteresis width
	TMCL.command->Value.Int32	|= 	(1 & 0x01)<<15; 				// set seimin
	TMCL.command->Value.Int32	|= 	(1 & 0x0F)<<0; 				// set stallGuard2 hysteresis start
	TMCL.command->Value.Int32	|=  (0<<13);					// set set sedn

	EvalBoards.ch1.writeRegister();

	// set max velocity in RAMP GENERATOR DRIVER FEATURE CONTROL register by set register datagram

	TMCL.command->Type 			= 0x31;
	TMCL.command->Value.Int32	= 159070 & 0x7FFFFF;
	EvalBoards.ch1.writeRegister();

	// set max velocity in RAMP GENERATOR DRIVER FEATURE CONTROL register by set register datagram
	TMCL.command->Type 			= 0x32;
	TMCL.command->Value.Int32	= 200000 & 0x7FFFFF;
	EvalBoards.ch1.writeRegister();
}

static void mealySTATES_COOLSTEP()
{

}

static void mooreSTATES_COOLSTEP()
{
	mooreSTATES_STALLGUARD();
//	HAL.LEDs->error.off();
}


static void setStateToSTATES_MOTOR_SINE_TABLE(char set)
{
	const int
		table[] =
		{
			0b10101010101010101011010101010100,
			0b01001010100101010101010010101010,
			0b00100100010010010010100100101001,
			0b00010000000100000100001000100010,
			0b11111011111111111111111111111111,
			0b10110101101110110111011101111101,
			0b01001001001010010101010101010110,
			0b00000000010000000100001000100010
		};
	int
		i;

	UNUSED(set);

	// motor stop datagram
		TMCL.command->Motor 		= 0; // MOTOR 1
		EvalBoards.ch1.motorStop();

		TMCL.command->Motor 		= 1; // MOTOR 1
		EvalBoards.ch1.motorStop();

	// write lookup table set register datagram
		for(i=0; i<8; i++)
		{
			TMCL.command->Type 			= 0x60+i;
			TMCL.command->Value.Int32 	= table[i];
			EvalBoards.ch1.writeRegister();

			TMCL.command->Type 			= 0x70+i;
			TMCL.command->Value.Int32 	= table[i];
			EvalBoards.ch1.writeRegister();
		}


	// define segments in MSLUTSEL register by set register datagram
		TMCL.command->Type 			= 0x68;			// MOTOR1
		TMCL.command->Value.Int32 	= 0;
		TMCL.command->Value.Int32 	|= (2<<0);		//WO
		TMCL.command->Value.Int32 	|= (1<<2);		//W1
		TMCL.command->Value.Int32 	|= (1<<4);		//W2
		TMCL.command->Value.Int32 	|= (1<<6);		//W3
		TMCL.command->Value.Int32 	|= (128<<8);	//X1
		TMCL.command->Value.Int32 	|= (254<<16);	//X2
		TMCL.command->Value.Int32 	|= (255<<24);	//X3
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x78;			// MOTOR2
		TMCL.command->Value.Int32 	= 0;
		TMCL.command->Value.Int32 	|= (2<<0);		//WO
		TMCL.command->Value.Int32 	|= (1<<2);		//W1
		TMCL.command->Value.Int32 	|= (1<<4);		//W2
		TMCL.command->Value.Int32 	|= (1<<6);		//W3
		TMCL.command->Value.Int32 	|= (128<<8);	//X1
		TMCL.command->Value.Int32 	|= (254<<16);	//X2
		TMCL.command->Value.Int32 	|= (255<<24);	//X3
		EvalBoards.ch1.writeRegister();


	// define start/stop values register by set register datagram
		TMCL.command->Type 			= 0x69;			// MOTOR1
		TMCL.command->Value.Int32 	= 0;
		TMCL.command->Value.Int32 	|= (0<<0);		// start
		TMCL.command->Value.Int32 	|= (247<<16);	// stop
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x79;			// MOTOR2
		TMCL.command->Value.Int32 	= 0;
		TMCL.command->Value.Int32 	|= (0<<0);		// start
		TMCL.command->Value.Int32 	|= (247<<16);	// stop
		EvalBoards.ch1.writeRegister();

	// rotate motors by ROR datagram
		TMCL.command->Motor 		= 0;
		TMCL.command->Value.Int32 	= 159072;
		EvalBoards.ch1.rotateRight();

		TMCL.command->Motor 		= 1;
		TMCL.command->Value.Int32 	= 159072;
		EvalBoards.ch1.rotateRight();
}

static void mealySTATES_MOTOR_SINE_TABLE()
{

}

static void mooreSTATES_MOTOR_SINE_TABLE()
{
//	HAL.LEDs->error.toggle();
}


static void setStateToSTATES_MOTOR_TRIANGLE_TABLE(char set)
{
	const int
		table[] =
		{
			0xfffffeff,
			0xfffffeff,
			0xfffffeff,
			0xfffffeff,
			0xfffffeff,
			0xfffffeff,
			0xfffffeff,
			0xfffffe7f
		};
	int
		i;

	// motor stop datagram
		TMCL.command->Motor 		= 0; // MOTOR 1
		EvalBoards.ch1.motorStop();

		TMCL.command->Motor 		= 1; // MOTOR 1
		EvalBoards.ch1.motorStop();


		if(!set)
		{
			setStateToSTATES_MOTOR_SINE_TABLE(set);
		}
		else
		{


		// write lookup table set register datagram
			for(i=0; i<8; i++)
			{
				TMCL.command->Type 			= 0x60+i;
				TMCL.command->Value.Int32 	= table[i];
				EvalBoards.ch1.writeRegister();

				TMCL.command->Type 			= 0x70+i;
				TMCL.command->Value.Int32 	= table[i];
				EvalBoards.ch1.writeRegister();
			}


		// define segments in MSLUTSEL register by set register datagram
			TMCL.command->Type 			= 0x68;			// MOTOR1
			TMCL.command->Value.Int32 	= 0;
			TMCL.command->Value.Int32 	|= (1<<0);		//WO
			TMCL.command->Value.Int32 	|= (1<<2);		//W1
			TMCL.command->Value.Int32 	|= (1<<4);		//W2
			TMCL.command->Value.Int32 	|= (1<<6);		//W3
			TMCL.command->Value.Int32 	|= (128<<8);	//X1
			TMCL.command->Value.Int32 	|= (254<<16);	//X2
			TMCL.command->Value.Int32 	|= (255<<24);	//X3
			EvalBoards.ch1.writeRegister();

			TMCL.command->Type 			= 0x78;			// MOTOR2
			TMCL.command->Value.Int32 	= 0;
			TMCL.command->Value.Int32 	|= (1<<0);		//WO
			TMCL.command->Value.Int32 	|= (1<<2);		//W1
			TMCL.command->Value.Int32 	|= (1<<4);		//W2
			TMCL.command->Value.Int32 	|= (1<<6);		//W3
			TMCL.command->Value.Int32 	|= (128<<8);	//X1
			TMCL.command->Value.Int32 	|= (254<<16);	//X2
			TMCL.command->Value.Int32 	|= (255<<24);	//X3
			EvalBoards.ch1.writeRegister();


		// define start/stop values register by set register datagram
			TMCL.command->Type 			= 0x69;			// MOTOR1
			TMCL.command->Value.Int32 	= 0;
			TMCL.command->Value.Int32 	|= (0<<0);		// start
			TMCL.command->Value.Int32 	|= (247<<16);	// stop
			EvalBoards.ch1.writeRegister();

			TMCL.command->Type 			= 0x79;			// MOTOR2
			TMCL.command->Value.Int32 	= 0;
			TMCL.command->Value.Int32 	|= (0<<0);		// start
			TMCL.command->Value.Int32 	|= (247<<16);	// stop
			EvalBoards.ch1.writeRegister();

		// rotate motors by ROR datagram
			TMCL.command->Motor 		= 0;
			TMCL.command->Value.Int32 	= 159072;
			EvalBoards.ch1.rotateRight();

			TMCL.command->Motor 		= 1;
			TMCL.command->Value.Int32 	= 159072;
			EvalBoards.ch1.rotateRight();
		}
}

static void mealySTATES_MOTOR_TRIANGLE_TABLE()
{

}

static void mooreSTATES_MOTOR_TRIANGLE_TABLE()
{
//	HAL.LEDs->error.on();
}


static void setStateToSTATES_DC_STEP(char set)
{
// stop motors
	TMCL.command->Motor 			= 0;
	EvalBoards.ch1.motorStop();

	TMCL.command->Motor 			= 1;
	EvalBoards.ch1.motorStop();

	if(set)
	{
		TMCL.command->Type 			= 0x7D;
		TMCL.command->Value.Int32	= (0x01<<24) | (0x05<<16) | (0x42<<8) | (0x60<<0 );  	//CHOPCONF: Toff: 5,
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x7C;
		TMCL.command->Value.Int32	= (0x00<<24) | (0x0E<<16) | (0x81<<8) | (0xD5<<0 );  	//CHOPCONF: Toff: 5,
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x7E;
		TMCL.command->Value.Int32	= (0x00<<24) | (0x0<<16) | (4<<8) | (27<<0 );  			//DCCTL: VDC_TIME: 80, DC_SG: 4
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x53;
		TMCL.command->Value.Int32	= 1024;		//Vdcmin
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x42;
		TMCL.command->Value.Int32	= 4500000;	//Vhigh
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x43;
		TMCL.command->Value.Int32	= 0;		//Start_Velo = 0
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x45;
		TMCL.command->Value.Int32	= 0;		//V1_Velo = 0
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x47;
		TMCL.command->Value.Int32	= 565000;	//VMAX_Velo = (565000*60)/(0.93*200*256*2) (356RPM)
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x44;
		TMCL.command->Value.Int32	= 0;		//A1_Acc = 0
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x46;
		TMCL.command->Value.Int32	=  30000;	//AMAX_Acc = 12000�S/t^2
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x4A;
		TMCL.command->Value.Int32	= 1;		//D1_Acc = 1
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x48;
		TMCL.command->Value.Int32	= 30000;	//DMAX_Acc = 12000�S/t^2
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x4B;
		TMCL.command->Value.Int32	= 1;	//Stop_Velo = 1
		EvalBoards.ch1.writeRegister();
	}
	else
	{
	// set COOLCONF register by set register datagram
		TMCL.command->Type 			= 0x7D;
		EvalBoards.ch1.readRegister();
		EvalBoards.ch1.readRegister();
		TMCL.command->Value.Int32	= TMCL.reply->Value.Int32; 		// actual settings
		TMCL.command->Value.Int32	&= (int) ~(0x0F<<8);			// unset stallGuard2 hysteresis width
		TMCL.command->Value.Int32	&= (int) ~(0x0F<<0);			// unset stallGuard2 hysteresis start
		TMCL.command->Value.Int32	&= (int) ~(0x7F<<16);			// unset stallGuard 2 threshold
		TMCL.command->Value.Int32	&= (int) ~(1<<24);				// unset stallguard filter
		TMCL.command->Value.Int32	&= (int) ~(1<<15);				// unset seimin -> 1/2 current
		TMCL.command->Value.Int32	&= (int) ~(3<<13);				// unset sedn
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x7C;
		TMCL.command->Value.Int32	= (0x00<<24) | (0x01<<16) | (0x01<<8) | 0xd5;
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x53;
		TMCL.command->Value.Int32	= 0;
		EvalBoards.ch1.writeRegister();

		TMCL.command->Type 			= 0x54;
		TMCL.command->Value.Int32	= 0;
		EvalBoards.ch1.writeRegister();

	}
}

static void mealySTATES_DC_STEP()
{
	switch(WTMCL.in->number)
	{
		case 1:
			TMCL.command->Opcode			= TMCL_ROR;
			TMCL.command->Type 				= 1;
			TMCL.command->Motor 			= 1;
			TMCL.command->Value.Int32 		= (int)  WTMCL.in->value;
			EvalBoards.ch1.rotateRight();
		break;
	}
}

static void mooreSTATES_DC_STEP()
{
// get measured speed
	TMCL.command->Motor	= 1;
	EvalBoards.ch1.getMeasuredSpeed();

	WTMCL.out->type		= CTRL.state;
	WTMCL.out->number	= 1;
	WTMCL.out->value	= TMCL.reply->Value.Int32;
	WTMCL.out->error	= 0;
	WTMCL.tx();

//	HAL.LEDs->error.toggle();
}


static void setStateToSTATES_DC_STEP_STOP_ON_STALL(char set)
{
// stop motors
	TMCL.command->Motor 		= 0;
	EvalBoards.ch1.motorStop();

	TMCL.command->Motor			= 1;
	EvalBoards.ch1.motorStop();

	setStateToSTATES_DC_STEP(set);

	if(!set)
	{
	// unset SG_STOP bit in SW_MODE register by set register datagram
		TMCL.command->Type 			= 0x54;
		EvalBoards.ch1.readRegister();
		EvalBoards.ch1.readRegister();
		TMCL.command->Value.Int32	= 	TMCL.reply->Value.Int32; 	// actual settings
		TMCL.command->Value.Int32	&= (int) ~(1<<10);				// unset SG_STOP
		EvalBoards.ch1.writeRegister();
	}
	else
	{
	// set SG_STOP bit in SW_MODE register by set register datagram
		TMCL.command->Type 			= 0x54;
		EvalBoards.ch1.readRegister();
		EvalBoards.ch1.readRegister();
		TMCL.command->Value.Int32	= TMCL.reply->Value.Int32; 	// actual settings
		TMCL.command->Value.Int32	|= 1<<10;					// enable SG_STOP
		EvalBoards.ch1.writeRegister();
	}
}

static void mealySTATES_DC_STEP_STOP_ON_STALL()
{
	mealySTATES_DC_STEP();
}

static void mooreSTATES_DC_STEP_STOP_ON_STALL()
{
	mooreSTATES_DC_STEP();
//	HAL.LEDs->error.off();
}


static void setStateToSTATES_LOAD_ANGLE(char set)
{
	setStateToSTATES_STALLGUARD(set);
}

static void mealySTATES_LOAD_ANGLE()
{

}

static void mooreSTATES_LOAD_ANGLE()
{
	mooreSTATES_STALLGUARD();
}


static void setStateToSTATES_LOAD_ANGLE_COOL(char set)
{
	setStateToSTATES_COOLSTEP(set);

	if(set)
	{
	// setStateTo max current datagram
		TMCL.command->Opcode			= TMCL_SAP;
		TMCL.command->Type 				= 6;
		TMCL.command->Value.Int32 		= (int) 29;
		TMCL.command->Motor 			= 0;	// MOTOR 1
		EvalBoards.ch1.setAxisParameter();
	}
	else
	{
		// setStateTo max current datagram
			TMCL.command->Opcode		= TMCL_SAP;
			TMCL.command->Type 			= 6;
			TMCL.command->Value.Int32 	= (int) 23;
			TMCL.command->Motor 		= 0;	// MOTOR 1
			EvalBoards.ch1.setAxisParameter();
	}
}

static void mealySTATES_LOAD_ANGLE_COOL()
{
}

static void mooreSTATES_LOAD_ANGLE_COOL()
{
	mooreSTATES_LOAD_ANGLE();
}


static void setStateToSTATES_MICROSTEPPING(char set)
{
	int value;

	setStateToSTATES_START(set);

	if(!set)
	{
		TMCL.command->Type			= 0x6C;
		EvalBoards.ch1.readRegister();
		EvalBoards.ch1.readRegister();
		value = TMCL.reply->Value.Int32;
		value  &= ~(0x0F<<24);
		TMCL.command->Value.Int32 	= value;
		EvalBoards.ch1.writeRegister();


		TMCL.command->Type			= 0x7C;
		EvalBoards.ch1.readRegister();
		EvalBoards.ch1.readRegister();
		value 	= TMCL.reply->Value.Int32;
		value  &= ~(0x0F<<24);
		TMCL.command->Value.Int32 	= value;
		EvalBoards.ch1.writeRegister();

	}
}

static void mealySTATES_MICROSTEPPING()
{
	static char	lastRes = 9;
	int 		value;

	switch(WTMCL.in->number)
	{
		case 1:	// microstepResolution

			WTMCL.in->value &= 0x0F;
			if(WTMCL.in->value == lastRes) 	return;
			if(WTMCL.in->value > 8) 		return;

		// stop motors and wait them to be finished
			TMCL.command->Motor 	= 0;
			EvalBoards.ch1.motorStop();

			TMCL.command->Motor 	= 1;
			EvalBoards.ch1.motorStop();

			TMCL.reply->Value.Int32 = 1;
			TMCL.command->Type		= 0x22;
			while(TMCL.reply->Value.Int32)	EvalBoards.ch1.readRegister();

			TMCL.reply->Value.Int32 = 1;
			TMCL.command->Type		= 0x42;
			while(TMCL.reply->Value.Int32)	EvalBoards.ch1.readRegister();


		// determine position in microstep table and move to poition 85 of a quadrant MSCNT%256+85

			TMCL.command->Type	= 0x6C;
			EvalBoards.ch1.readRegister();
			value 	= 	TMCL.reply->Value.Int32;
			value	%= 	256;
			value 	-=	85;

			TMCL.command->Type	= 0x21;
			EvalBoards.ch1.readRegister();

			TMCL.command->Value.Int32	= TMCL.reply->Value.Int32+value;
			TMCL.command->Motor 		= 0;
			EvalBoards.ch1.moveToPosition();


			TMCL.command->Type	= 0x7C;
			EvalBoards.ch1.readRegister();
			value 	= 	TMCL.reply->Value.Int32;
			value	%= 	256;
			value 	-=	85;

			TMCL.command->Type	= 0x41;
			EvalBoards.ch1.readRegister();

			TMCL.command->Value.Int32	= TMCL.reply->Value.Int32+value;
			TMCL.command->Motor 		= 1;
			EvalBoards.ch1.moveToPosition();

		// set resolution

			lastRes = WTMCL.in->value;

			TMCL.command->Type			= 0x6C;
			EvalBoards.ch1.readRegister();
			value 	= TMCL.reply->Value.Int32;
			value  &= ~(0x0F<<24);
			value  |= ((WTMCL.in->value & 0x0F)<<24);
			TMCL.command->Value.Int32 	= value;
			EvalBoards.ch1.writeRegister();

			TMCL.command->Type			= 0x7C;
			EvalBoards.ch1.readRegister();

			value 	= TMCL.reply->Value.Int32;
			value  &= ~(0x0F<<24);
			value  |= ((WTMCL.in->value & 0x0F)<<24);
			TMCL.command->Value.Int32 	= value;
			EvalBoards.ch1.writeRegister();

		break;

		case 2:	// velocity
			if(WTMCL.in->value < 400000)
			{
				TMCL.command->Opcode		= TMCL_ROR;
				TMCL.command->Type 			= 0;
				TMCL.command->Motor 		= 0;
				TMCL.command->Value.Int32 	= (int)  WTMCL.in->value;
				EvalBoards.ch1.rotateRight();

				TMCL.command->Opcode		= TMCL_ROR;
				TMCL.command->Type 			= 0;
				TMCL.command->Motor 		= 1;
				TMCL.command->Value.Int32 	= (int)  WTMCL.in->value;
				EvalBoards.ch1.rotateRight();
			}
		break;

		default:
		break;
	}


}

static void mooreSTATES_MICROSTEPPING()
{
//	HAL.LEDs->error.toggle();
}
