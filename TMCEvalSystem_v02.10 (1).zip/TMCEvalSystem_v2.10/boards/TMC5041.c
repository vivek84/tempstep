#include "562v3.h"
#include "TMC5041.h"

#define ERRORS_VM 		(1<<0)
#define ERRORS_VM_UNDER (1<<1)
#define ERRORS_VM_OVER 	(1<<2)

#define VM_MIN			50	// VM[V/10] min
#define VM_MAX			280	// VM[V/10] max +10%

static int 		vMax[] 			= {0,0};
static uint8 	vMaxModified[] 	= {1,1};

static void RotateRight(void);
static void RotateLeft(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void writeRegister(void);
static void readRegister(void);
static void periodicJob(uint32 tick);
static void init(void);
static void deInit(void);
static void userFunction(void);

static void getMeasuredSpeed(void);
static void rotate(void);
static uint8 reset();
static void enableDriver(uint8 disable0Enable1global2);

EvalBoardTypeDef TMC5041 = { .init = init };

typedef struct
{
	IOPinTypeDef *DRV_ENN;
	IOPinTypeDef *INT_ENCA;
	IOPinTypeDef *PP_ENCB;
} PinsTypeDef;

static PinsTypeDef Pins;

static void rotate()
{
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		TMC562V3.writeInt(TMC562V3_VMAX|MOTOR_ADDR(TMCL.command->Motor), abs(TMCL.command->Value.Int32));
		vMaxModified[TMCL.command->Motor]=TRUE;
		if(TMCL.command->Value.Int32 >= 0)
		{
			TMC562V3.writeDatagram(TMC562V3_RAMPMODE|MOTOR_ADDR(TMCL.command->Motor), 0, 0, 0, TMC562V3_MODE_VELPOS);
		}
		else
		{
			TMC562V3.writeDatagram(TMC562V3_RAMPMODE|MOTOR_ADDR(TMCL.command->Motor), 0, 0, 0, TMC562V3_MODE_VELNEG);
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void RotateRight(void)
{
	rotate();
}

static void RotateLeft(void)
{
	TMCL.command->Value.Int32 = -TMCL.command->Value.Int32;
	rotate();
}

static void MotorStop(void)
{
	TMCL.command->Value.Int32 = 0;
	rotate();
}

static void MoveToPosition(void)
{
	int ActPos;

	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				if(vMaxModified[TMCL.command->Motor])
				{
					TMC562V3.writeInt(TMC562V3_VMAX|MOTOR_ADDR(TMCL.command->Motor), vMax[TMCL.command->Motor]);
					vMaxModified[TMCL.command->Motor]=FALSE;
				}
				TMC562V3.writeInt(TMC562V3_XTARGET|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
				TMC562V3.writeDatagram(TMC562V3_RAMPMODE|MOTOR_ADDR(TMCL.command->Motor), 0, 0, 0, TMC562V3_MODE_POSITION);
			break;

			case MVP_REL:
				ActPos=TMC562V3.readInt(TMC562V3_XACTUAL|MOTOR_ADDR(TMCL.command->Motor));
				if(vMaxModified[TMCL.command->Motor])
				{
					TMC562V3.writeInt(TMC562V3_VMAX|MOTOR_ADDR(TMCL.command->Motor), vMax[TMCL.command->Motor]);
					vMaxModified[TMCL.command->Motor]=FALSE;
				}
				TMC562V3.writeInt(TMC562V3_XTARGET|MOTOR_ADDR(TMCL.command->Motor), ActPos+TMCL.command->Value.Int32);
				TMC562V3.writeDatagram(TMC562V3_RAMPMODE|MOTOR_ADDR(TMCL.command->Motor), 0, 0, 0, TMC562V3_MODE_POSITION);
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
	uint32 value;

	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				TMC562V3.writeInt(TMC562V3_XTARGET|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 1:
				TMC562V3.writeInt(TMC562V3_XACTUAL|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 2:
				vMaxModified[TMCL.command->Motor]=TRUE;
				TMC562V3.writeInt(TMC562V3_VMAX|MOTOR_ADDR(TMCL.command->Motor), abs(TMCL.command->Value.Int32));
			break;

			case 4:
				vMax[TMCL.command->Motor]=abs(TMCL.command->Value.Int32);
				if(TMC562V3.readInt(TMC562V3_RAMPMODE|MOTOR_ADDR(TMCL.command->Motor))==TMC562V3_MODE_POSITION)	 TMC562V3.writeInt(TMC562V3_VMAX|MOTOR_ADDR(TMCL.command->Motor), abs(TMCL.command->Value.Int32));
			break;

			case 5:
				TMC562V3.writeInt(TMC562V3_AMAX|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 6:
				value=TMC562V3.readInt(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor));
				TMC562V3.writeDatagram(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor), 0, value >> 16, TMCL.command->Value.Byte[0], value & 0xff);
			break;

			case 7:
				value=TMC562V3.readInt(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor));
				TMC562V3.writeDatagram(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor), 0, value >> 16, value >> 8, TMCL.command->Value.Byte[0]);
			break;

			case 12: // configure right stop bits
				value = TMC562V3.readInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor));			// get SWMODE register settings
				value &= ~(TMC562V3_SW_STOPR_ENABLE | TMC562V3_SW_STOPR_POLARITY);
				value |= (TMCL.command->Value.Int32) 		? TMC562V3_SW_STOPR_ENABLE 		: 0;	// set STOP_ENABLE
				value |= (TMCL.command->Value.Int32 == 2) 	? TMC562V3_SW_STOPR_POLARITY 	: 0;	// set STOP_POLARITY
				TMC562V3.writeInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor), value);
			break;

			case 13: // configure left stop bits
				value = TMC562V3.readInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor));			// get SWMODE register settings
				value &= ~(TMC562V3_SW_STOPL_ENABLE | TMC562V3_SW_STOPL_POLARITY);					// clear STOP bits
				value |= (TMCL.command->Value.Int32) 		? TMC562V3_SW_STOPL_ENABLE		: 0;	// set STOP_ENABLE
				value |= (TMCL.command->Value.Int32 == 2) 	? TMC562V3_SW_STOPL_POLARITY 	: 0;	// set STOP_POLARITY
				TMC562V3.writeInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor), value);
			break;

			case 14:
				TMC562V3.writeInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 15:
				TMC562V3.writeInt(TMC562V3_A1|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 16:
				TMC562V3.writeInt(TMC562V3_V1|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 17:
				TMC562V3.writeInt(TMC562V3_DMAX|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 18:
				TMC562V3.writeInt(TMC562V3_D1|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 19:
				TMC562V3.writeInt(TMC562V3_VSTART|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 20:
				TMC562V3.writeInt(TMC562V3_VSTOP|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 21:
				TMC562V3.writeInt(TMC562V3_TZEROWAIT|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 22:
				TMC562V3.writeInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 23:
				TMC562V3.writeInt(TMC562V3_VHIGH|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 24:
				TMC562V3.writeInt(TMC562V3_VDCMIN|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
			break;

			case 28:
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x01<<18);
				if(TMCL.command->Value.Int32) value |= (0x01<<18);
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 140:
				switch(TMCL.command->Value.Int32)
				{
					case 1:	 	TMCL.command->Value.Int32 = 8; break;
					case 2:	 	TMCL.command->Value.Int32 = 7; break;
					case 4:	 	TMCL.command->Value.Int32 = 6; break;
					case 8:	 	TMCL.command->Value.Int32 = 5; break;
					case 16:	TMCL.command->Value.Int32 = 4; break;
					case 32:	TMCL.command->Value.Int32 = 3; break;
					case 64:	TMCL.command->Value.Int32 = 2; break;
					case 128:	TMCL.command->Value.Int32 = 1; break;
					case 256:	TMCL.command->Value.Int32 = 0; break;
					default: 	TMCL.command->Value.Int32 = -1; break;
				}

				if(TMCL.command->Value.Int32 != -1)
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
					value &= ~(0x0F<<24);
					value |= (TMCL.command->Value.Int32 & 0xF) << 24;
					TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
				}
				else TMCL.reply->Status = REPLY_INVALID_VALUE;


			break;

			case 162:
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x03<<15);
				value |= (TMCL.command->Value.Int32 & 0x3) << 15;
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 163:
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x01<<14);
				if(TMCL.command->Value.Int32) value |= (0x01<<14);
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 164:
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x01<<12);
				if(TMCL.command->Value.Int32) value |= (0x01<<12);
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 165:
				if(TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) & (1<<14))
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
					value &= ~(0x0F<<7);
					value |= (TMCL.command->Value.Int32 & 0x0F) << 7;
					TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
				}
				else
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));

					if(TMCL.command->Value.Int32 & (1<<3)) value |= (0x01<<11);
					else value &= ~(0x01<<11);

					value &= ~(0x07<<4);
					value |=  (TMCL.command->Value.Int32 & 0x0F) << 4;

					TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
				}
			break;

			case 166:
				if(TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) & (1<<14))
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
					value &= ~(0x07<<4);
					value |= (TMCL.command->Value.Int32 & 0x07) << 4;
					TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
				}
				else
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
					value &= ~(0x0F<<7);
					value |= (TMCL.command->Value.Int32 & 0x0F) << 7;
					TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
				}
			break;

			case 167:
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x0F<<0);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 0;
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 168:
				value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x01<<15);
				if(TMCL.command->Value.Int32) value |= (0x01<<15);
				TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 169:
				value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x03<<13);
				value |= (TMCL.command->Value.Int32 & 0x03) << 13;
				TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 170:
				value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x0F<<8);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 8;
				TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 171:
				value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x03<<5);
				value |= (TMCL.command->Value.Int32 & 0x03) << 5;
				TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 172:
				value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x0F<<0);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 0;
				TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 173:
				value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x01<<24);
				if(TMCL.command->Value.Int32) value |= (0x01<<24);
				TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 174:
				value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x07F<<16);
				value |= (TMCL.command->Value.Int32 & 0x07F) << 16;
				TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 179:
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x01<<17);
				if(TMCL.command->Value.Int32) value |= (0x01<<17);
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 181:
				TMC562V3.writeInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor),TMCL.command->Value.Int32);

				value = TMC562V3.readInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor));
				value &= ~(1<<10);
				TMC562V3.writeInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor), value);
				value |= (TMCL.command->Value.Int32) ? (1<<10) : 0;
				TMC562V3.writeInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor), value);


			break;

			case 182:
				TMC562V3.writeInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor),TMCL.command->Value.Int32);
			break;

			case 184:
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x01<<13);
				if(TMCL.command->Value.Int32) value |= (0x01<<13);
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 185:
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x0F<<20);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 20;
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			break;

			case 209:
				TMC562V3.writeInt(TMC562V3_XENC|MOTOR_ADDR(TMCL.command->Motor),TMCL.command->Value.Int32);
			break;

			case 210:
				TMC562V3.writeInt(TMC562V3_ENC_CONST|MOTOR_ADDR(TMCL.command->Motor),TMCL.command->Value.Int32);
			break;

			case 211:	// encoder enable
				switch(TMCL.command->Motor)
				{
					case 0:
						value = TMC562V3.readInt(TMC562V3_GCONF);
						value = (TMCL.command->Value.Int32) ? value&~(1<<3) : value|(1<<3);		// poscmp_enable 	-> ENCODER1 A,B
						value = (TMCL.command->Value.Int32) ? value|(1<<4) 	: value&~(1<<4);	// enc1_refsel 		-> ENCODER1 N to REFL1
						TMC562V3.writeInt(TMC562V3_GCONF, value);
					break;

					case 1:		// enable ENCODER2 - disable REF
						value = TMC562V3.readInt(TMC562V3_GCONF);
						value = (TMCL.command->Value.Int32) ? value|(1<<5) 	: value&~(5<<5);	// enc2_enable 		-> ENCODER2 A,B to REFR1,2
						value = (TMCL.command->Value.Int32) ? value&~(1<<6) : value|(1<<6);		// enc2_refse2 		-> ENCODER1 N to REFL2
						TMC562V3.writeInt(TMC562V3_GCONF, value);
					break;
				}
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_WRONG_TYPE;
}

static void GetAxisParameter(void)
{
	uint32 value;

	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_XTARGET|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 1:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_XACTUAL|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 2:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VMAX|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 3:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VACTUAL|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 4:
				TMCL.reply->Value.Int32=vMax[TMCL.command->Motor];
			break;

			case 5:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_AMAX|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 6:
				value=TMC562V3.readInt(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor));
				TMCL.reply->Value.Int32=(value>>8) & 0xff;
			break;

			case 7:
				value=TMC562V3.readInt(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor));
				TMCL.reply->Value.Int32=value & 0xff;
			break;

			case 8:
				TMCL.reply->Value.Int32=(TMC562V3.readInt(TMC562V3_RAMPSTAT|MOTOR_ADDR(TMCL.command->Motor)) & TMC562V3_RS_POSREACHED) ? 1:0;
			break;

			case 10:
				TMCL.reply->Value.Int32=(TMC562V3.readInt(TMC562V3_RAMPSTAT|MOTOR_ADDR(TMCL.command->Motor)) & TMC562V3_RS_STOPR) ? 0:1;
			break;

			case 11:
				TMCL.reply->Value.Int32=(TMC562V3.readInt(TMC562V3_RAMPSTAT|MOTOR_ADDR(TMCL.command->Motor)) & TMC562V3_RS_STOPL) ? 0:1;
			break;

			case 12:
				TMCL.reply->Value.Int32=(TMC562V3.readInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor)) & TMC562V3_SW_STOPR_ENABLE) ? 1:0;
			break;

			case 13:
				TMCL.reply->Value.Int32=(TMC562V3.readInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor)) & TMC562V3_SW_STOPL_ENABLE) ? 1:0;
			break;

			case 14:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 15:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_A1|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 16:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_V1|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 17:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_DMAX|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 18:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_D1|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 19:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VSTART|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 20:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VSTOP|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 21:
					TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_TZEROWAIT|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 22:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 23:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VHIGH|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 24:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VDCMIN|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 28:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 18) & 0x01;
			break;

			case 29:
				TMCL.reply->Value.Int32 = (TMCL.command->Motor) ? TMC562V3.velocityMotor2 : TMC562V3.velocityMotor1;
			break;

			case 140:
				TMCL.reply->Value.Int32 = 256>>((TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 24) & 0x0F);
			break;

			case 162:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 15) & 0x03;
			break;

			case 163:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 14) & 0x01;
			break;

			case 164:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 12) & 0x01;
			break;

			case 165:
				if(TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) & (1<<14))
				{
					TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 7) & 0x0F;
				}
				else
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
					TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 4) & 0x07;
					if(value & (1<<11)) TMCL.reply->Value.Int32 |= 1<<3;
				}
			break;

			case 166:
				if(TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) & (1<<14))
				{
					TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 4) & 0x07;
				}
				else
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
					TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 7) & 0x0F;
					if(value & (1<<11)) TMCL.reply->Value.Int32 |= 1<<3;
				}
			break;

			case 167:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 0) & 0x0F;
			break;

			case 168:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 15) & 0x01;
			break;

			case 169:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 13) & 0x03;
			break;

			case 170:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 8) & 0x0F;
			break;

			case 171:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 5) & 0x03;
			break;

			case 172:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 0) & 0x0F;
			break;

			case 173:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 24) & 0x01;
			break;

			case 174:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 16) & 0xFF;
				TMCL.reply->Value.Int32 |= (TMCL.reply->Value.Int32 & (1<<7)) ? 0xFFFFFF00 : 0;
			break;

			case 179:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 17) & 0x01;
			break;

			case 180:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_DRVSTATUS|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 16) & 0x0FF;
			break;

			case 182:
				TMCL.reply->Value.Int32 = TMC562V3.readInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 184:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 13) & 0x01;
			break;

			case 185:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 20) & 0x0F;
			break;

			case 206:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_DRVSTATUS|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 0) & 0x03FF;
			break;

			case 209:
				TMCL.reply->Value.Int32 = TMC562V3.readInt(TMC562V3_XENC|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 210:
				TMCL.reply->Value.Int32 = TMC562V3.readInt(TMC562V3_ENC_CONST|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 211:	// encoder enable
				switch(TMCL.command->Motor)
				{
					case 0:
						value = TMC562V3.readInt(TMC562V3_GCONF);
						value &= (1<<3) | (1<<4);
						TMCL.reply->Value.Int32 = (value == (1<<4)) ? 1 : 0;
					break;

					case 1:
						value = TMC562V3.readInt(TMC562V3_GCONF);
						value &= (1<<5) | (1<<6);
						TMCL.reply->Value.Int32 = (value == ((1<<5) | (0<<6))) ? 1 : 0;
					break;
				}
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void getMeasuredSpeed(void)
{
	switch(TMCL.command->Motor)
	{
		case 0:
			TMCL.reply->Value.Int32 = TMC562V3.velocityMotor1;
		break;

		case 1:
			TMCL.reply->Value.Int32 = TMC562V3.velocityMotor2;
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void writeRegister(void)
{
  TMC562V3.writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32	= TMC562V3.readInt(TMCL.command->Type);
}

static void periodicJob(uint32 tick)
{
	TMC562V3.periodicJob(tick);
}

static void userFunction(void)
{
	switch(TMCL.command->Type)
	{
		case 1:		// read interrupt pin INT
			TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.INT_ENCA))	? 1 : 0;
		break;

		case 2:		// read position compare pin PP
			TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.PP_ENCB)) 	? 1 : 0;
		break;

		default:
			TMCL.reply->Status=REPLY_WRONG_TYPE;
		break;
	}
}

static void init(void)
{
	Pins.DRV_ENN						= &HAL.IOs->pins->DIO0;
	Pins.INT_ENCA						= &HAL.IOs->pins->DIO5;
	Pins.PP_ENCB						= &HAL.IOs->pins->DIO6;

	HAL.IOs->config->toOutput(Pins.DRV_ENN);
	HAL.IOs->config->toInput(Pins.INT_ENCA);
	HAL.IOs->config->toInput(Pins.PP_ENCB);

	TMC562V3.SPIChannel					= &HAL.SPI->ch1;
	TMC562V3.SPIChannel->CSN			= &HAL.IOs->pins->SPI1_CSN;
	TMC562V3.config						= EvalBoards.ch1.config;

	EvalBoards.ch1.config->isBusy		= 0;
	EvalBoards.ch1.config->reset		= reset;
	EvalBoards.ch1.config->restore		= TMC562V3.restore;
	EvalBoards.ch1.motorStop			= MotorStop;
	EvalBoards.ch1.getAxisParameter		= GetAxisParameter;
	EvalBoards.ch1.moveToPosition		= MoveToPosition;
	EvalBoards.ch1.rotateLeft			= RotateLeft;
	EvalBoards.ch1.rotateRight			= RotateRight;
	EvalBoards.ch1.setAxisParameter		= SetAxisParameter;
	EvalBoards.ch1.writeRegister		= writeRegister;
	EvalBoards.ch1.readRegister			= readRegister;
	EvalBoards.ch1.periodicJob			= periodicJob;
	EvalBoards.ch1.init					= init;
	EvalBoards.ch1.deInit				= deInit;
	EvalBoards.ch1.getMeasuredSpeed		= getMeasuredSpeed;
	EvalBoards.ch1.enableDriver			= enableDriver;
	EvalBoards.ch1.userFunction			= userFunction;
	EvalBoards.ch1.numberOfMotors		= 2;
	EvalBoards.ch1.VMMin				= VM_MIN;
	EvalBoards.ch1.VMMax				= VM_MAX;
	EvalBoards.numberOfMotors			= 2;
	enableDriver(2);
};

static void deInit(void)
{
	enableDriver(0);
	HAL.IOs->config->reset(Pins.DRV_ENN);
	HAL.IOs->config->reset(Pins.INT_ENCA);
	HAL.IOs->config->reset(Pins.PP_ENCB);
};

static uint8 reset()
{
	if(!VitalSignsMonitor.brownOut)
	{
		if(TMC562V3.readInt(TMC562V3_VACTUAL|MOTOR_ADDR(0))) return 0;
		if(TMC562V3.readInt(TMC562V3_VACTUAL|MOTOR_ADDR(1))) return 0;
	}
	TMC562V3.reset();
	return 1;
}

static void enableDriver(uint8 enable)
{
	if(enable == 2) enable = EvalBoards.driverEnable;

	if(enable ==  0)											HAL.IOs->config->setHigh(Pins.DRV_ENN);
	else if((enable == 1) && (EvalBoards.driverEnable == 1))	HAL.IOs->config->setLow(Pins.DRV_ENN);
}
