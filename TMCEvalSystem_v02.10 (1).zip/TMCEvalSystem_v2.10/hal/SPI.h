#ifndef __SPI_STX_H
	#define __SPI_STX_H

	//SPI-Ger�te
	#define SPI_DEV_MOTION_CONTROLLER 	0
	#define SPI_DEV_MOTOR_DRIVER_0    	1
	#define SPI_DEV_MOTOR_DRIVER_1    	2
	#define SPI_DEV_MOTOR_DRIVER_2    	3
	#define SPI_DEV_BAD_DEVICE    		-1

	#include "derivative.h"

	typedef struct
	{
		#ifdef Startrampe
			SPI_TypeDef		*periphery;	// pointer to ST SPI configuration structure
		#else
			SPI_MemMapPtr 	periphery;	// pointer to freescale SPI memory base pointer
		#endif

		IOPinTypeDef	*CSN;
		unsigned char (*readWrite) 	(unsigned char data, unsigned char lastTransfer);
		void (*reset) (void);
	} SPIChannelTypeDef;

	typedef struct
	{
		SPIChannelTypeDef ch1;
		SPIChannelTypeDef ch2;
		void (*init) (void);
	} SPITypeDef;

	SPITypeDef SPI;
#endif
