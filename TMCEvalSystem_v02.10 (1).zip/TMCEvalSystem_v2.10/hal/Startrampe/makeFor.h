#ifndef Startrampe
	#define Startrampe
#endif
