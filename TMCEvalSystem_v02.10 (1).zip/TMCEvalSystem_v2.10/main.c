#include "main.h"
#include "hal/derivative.h"
#include "hal/HAL.h"
#include "tmc/idDetection.h"
#include "tmc/TMCL.h"
#include "tmc/vitalSignsMonitor.h"
#include "tmc/boardAssignment.h"
#include "boards/board.h"
#include "boards/TMC5130.h"

const char *VersionString	= MODULE_ID"V0210";

#if defined(Landungsbruecke)
	const uint8 Protection[] __attribute__ ((section(".cfmconfig")))=
	{
	  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,  //Backdoor key
	  0xff, 0xff, 0xff, 0xff,                          //Flash protection (FPPROT)
	  0x7e,                                            //Flash security   (FSEC) => nach Image-Generierung manuell auf 0x40 setzen im Image
	  0xf9,                                            //Flash option     (FOPT) (NMI ausgeschaltet, EzPort ausgeschaltet, Normal power)
	  0xff,                                            //reserved
	  0xff                                             //reserved
	};

	__attribute__ ((section(".bldata"))) uint32 BLMagic;
#endif

static void initialScan(IdAssignmentTypeDef *ids)
{
	while(IdDetection.detect(ids) != ID_STATE_DONE)
	{
		VitalSignsMonitor.checkVitalSigns(SystemTick.tick);
		TMCL.process();
	}
}

static void shallForceBoot()
{
	HAL.IOs->config->toOutput(&HAL.IOs->pins->ID_CLK);
	HAL.IOs->config->toInput(&HAL.IOs->pins->ID_CH0);

	HAL.IOs->config->setHigh(&HAL.IOs->pins->ID_CLK);
	if(!HAL.IOs->config->isHigh(&HAL.IOs->pins->ID_CH0))	return;

	HAL.IOs->config->setLow(&HAL.IOs->pins->ID_CLK);
	if(HAL.IOs->config->isHigh(&HAL.IOs->pins->ID_CH0))		return;



	HAL.IOs->config->toOutput(&HAL.IOs->pins->ID_CH0);
	HAL.IOs->config->toInput(&HAL.IOs->pins->ID_CLK);

	HAL.IOs->config->setHigh(&HAL.IOs->pins->ID_CH0);
	if(!HAL.IOs->config->isHigh(&HAL.IOs->pins->ID_CLK))	return;

	HAL.IOs->config->setLow(&HAL.IOs->pins->ID_CH0);
	if(HAL.IOs->config->isHigh(&HAL.IOs->pins->ID_CLK)) 	return;

	TMCL.command->Type 			= 0x81;
	TMCL.command->Motor 		= 0x92;
	TMCL.command->Value.Byte[3] = 0xa3;
	TMCL.command->Value.Byte[2] = 0xb4;
	TMCL.command->Value.Byte[1] = 0xc5;
	TMCL.command->Value.Byte[0] = 0xd6;

	Boot();
}

static void init()
{
	IdAssignmentTypeDef ids;

	HAL.init();
	IdDetection.init();
	TMCL.init();
	TMCDriver.init();
	TMCMotionController.init();

	Wireless.init();

	VitalSignsMonitor.busy 	= 1;
	EvalBoards.driverEnable = 1;
	EvalBoards.ch1.id 		= 0;
	EvalBoards.ch2.id 		= 0;
	initialScan(&ids);
	initialScan(&ids);

	if(!ids.ch1.id && !ids.ch2.id) shallForceBoot();

	BoardAssignment.assign(&ids);

	VitalSignsMonitor.busy 	= 0;
}

int main(void)
{
	init();
	EvalBoards.ch1.debugVar = 0;
	while(1)
	{
		VitalSignsMonitor.checkVitalSigns(SystemTick.tick);
		EvalBoards.ch1.periodicJob(SystemTick.tick);
		EvalBoards.ch2.periodicJob(SystemTick.tick);
		TMCL.process();
	}

	return 0;
}
