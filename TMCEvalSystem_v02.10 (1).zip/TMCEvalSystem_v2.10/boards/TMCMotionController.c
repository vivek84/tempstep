#include "board.h"

static void init();

#define VM_MIN 0
#define VM_MAX -1

EvalBoardMotionControllerTypeDef TMCMotionController =
{
	.init 	= init,
	.config	=
	{
		.isBusy 			= 0,
		.ptr 				= 0,
		.shadowRegister 	= {}
	}
};

static void init()
{
	EvalBoards.ch1.config					= &TMCMotionController.config;
	EvalBoards.ch1.config->isBusy 			= 0;
	EvalBoards.ch1.config->ptr	 			= 0;
	EvalBoards.ch1.config->reset			= TMCDummy.reset;
	EvalBoards.ch1.config->resetCallBack	= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.config->restore			= TMCDummy.restore;
	EvalBoards.ch1.config->restoreCallBack	= TMCDummy.TMCLDelegation;

	EvalBoards.ch1.numberOfMotors	= 0;
	EvalBoards.ch1.init				= init;
	EvalBoards.ch1.deInit			= TMCDummy.deInit;
	EvalBoards.ch1.periodicJob		= TMCDummy.periodicJob;
	EvalBoards.ch1.rotateLeft		= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.motorStop		= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.moveToPosition	= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.rotateRight		= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.getAxisParameter	= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.readRegister		= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.writeRegister	= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.setAxisParameter	= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.storeAxisParameter	= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.restoreAxisParameter	= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.userFunction		= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.getMeasuredSpeed	= TMCDummy.TMCLDelegation;
	EvalBoards.ch1.checkErrors		= TMCDummy.periodicJob;
	EvalBoards.ch1.enableDriver		= TMCDummy.enableDriver;
	EvalBoards.ch1.VMMin			= VM_MIN;
	EvalBoards.ch1.VMMax			= VM_MAX;
	EvalBoards.ch1.errors			= 0;
}
