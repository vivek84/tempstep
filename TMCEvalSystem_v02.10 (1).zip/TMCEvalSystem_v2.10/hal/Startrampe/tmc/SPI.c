#include "../../HAL.h"
#include "../../SPI.h"

static void init(void);
static unsigned char readWrite(SPIChannelTypeDef *SPIChannel, unsigned char data, unsigned char lastTransfer);
static unsigned char readWrite_ch1(unsigned char data, unsigned char lastTransfer);
static unsigned char readWrite_ch2(unsigned char data, unsigned char lastTransfer);
static void reset_ch1();
static void reset_ch2();

static IOPinTypeDef IODummy = {	.bitWeight = 3	};

SPITypeDef SPI=
{
	.ch1	=
	{
		.periphery	= SPI3,
		.CSN		= &IODummy,
		.readWrite	= readWrite_ch1,
		.reset		= reset_ch1
	},

	.ch2	=
	{
		.periphery 	= SPI2,
		.CSN		= &IODummy,
		.readWrite	= readWrite_ch2,
		.reset		= reset_ch2
	},
	.init	= init
};


static void init(void)
{
  SPI_InitTypeDef SPIInit;

  //-------- SPI2 initialisieren und mit den Pins verbinden ---------
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);

  //SPI initialisieren
  SPIInit.SPI_Direction=SPI_Direction_2Lines_FullDuplex;
  SPIInit.SPI_Mode=SPI_Mode_Master;
  SPIInit.SPI_DataSize=SPI_DataSize_8b;
  SPIInit.SPI_CPOL=SPI_CPOL_High;
  SPIInit.SPI_CPHA=SPI_CPHA_2Edge;
  SPIInit.SPI_NSS=SPI_NSS_Soft;
  SPIInit.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_8;
  SPIInit.SPI_FirstBit=SPI_FirstBit_MSB;
  SPIInit.SPI_CRCPolynomial=0;
  SPI_Init(SPI2, &SPIInit);
  SPI_Cmd(SPI2, ENABLE);

  GPIO_PinAFConfig(GPIOB, GPIO_PinSource13, GPIO_AF_SPI2);
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource14, GPIO_AF_SPI2);
  GPIO_PinAFConfig(GPIOB, GPIO_PinSource15, GPIO_AF_SPI2);

  //-------- SPI3 initialisieren und mit den Pins verbinden ---------
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3, ENABLE);

  //SPI initialisieren
  SPIInit.SPI_Direction=SPI_Direction_2Lines_FullDuplex;
  SPIInit.SPI_Mode=SPI_Mode_Master;
  SPIInit.SPI_DataSize=SPI_DataSize_8b;
  SPIInit.SPI_CPOL=SPI_CPOL_High;
  SPIInit.SPI_CPHA=SPI_CPHA_2Edge;
  SPIInit.SPI_NSS=SPI_NSS_Soft;
  SPIInit.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_32;
  SPIInit.SPI_FirstBit=SPI_FirstBit_MSB;
  SPIInit.SPI_CRCPolynomial=0;
  SPI_Init(SPI3, &SPIInit);
  SPI_Cmd(SPI3, ENABLE);

  GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_SPI3);
  GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_SPI3);
  GPIO_PinAFConfig(GPIOC, GPIO_PinSource12, GPIO_AF_SPI3);

  reset_ch1();
  reset_ch2();
}

static void reset_ch1()
{
	SPI.ch1.CSN			= &IODummy;
	SPI.ch1.periphery	= SPI3;
	SPI.ch1.readWrite	= readWrite_ch1;
}

static void reset_ch2()
{
	SPI.ch2.CSN			= &IODummy;
	SPI.ch2.periphery	= SPI2;
	SPI.ch2.readWrite	= readWrite_ch2;
}

static unsigned char readWrite_ch1(unsigned char data, unsigned char lastTransfer)
{
	 return readWrite(&SPI.ch1, data, lastTransfer);
}

static unsigned char readWrite_ch2(unsigned char data, unsigned char lastTransfer)
{
	 return readWrite(&SPI.ch2, data,lastTransfer);
}

static unsigned char readWrite(SPIChannelTypeDef *SPIChannel, unsigned char data, unsigned char lastTransfer)
{
	if(SPIChannel->CSN->bitWeight == 3) return 0;

	HAL.IOs->config->setLow(SPIChannel->CSN);

	while(SPI_I2S_GetFlagStatus(SPIChannel->periphery, SPI_I2S_FLAG_TXE)==RESET);
	SPI_I2S_SendData(SPIChannel->periphery, data);
	while(SPI_I2S_GetFlagStatus(SPIChannel->periphery, SPI_I2S_FLAG_RXNE)==RESET);
	if(lastTransfer) HAL.IOs->config->setHigh(SPIChannel->CSN);
	return SPI_I2S_ReceiveData(SPIChannel->periphery);
}
