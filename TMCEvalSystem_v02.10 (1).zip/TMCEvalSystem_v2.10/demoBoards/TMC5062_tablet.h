#ifndef TMC5062_TABLE_H_
	#define TMC5062_TABLE_H_

	#include "demoBoards/demoBoards.h"
	DemoBoardsTypeDef TMC5062Demo;
#endif
