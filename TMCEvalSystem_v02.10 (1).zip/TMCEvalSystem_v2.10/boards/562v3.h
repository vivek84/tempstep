#ifndef __562V3_H
	#define __562V3_H

	#include "board.h"

	#define TMC562V3_GCONF        0x00
	#define TMC562V3_GSTAT        0x01
	#define TMC562V3_IFCNT        0x02
	#define TMC562V3_SLAVECONF    0x03
	#define TMC562V3_INP_OUT      0x04
	#define TMC562V3_X_COMPARE    0x05

	#define TMC562V3_PWMCONF_1	  0x10
	#define TMC562V3_PWM_STATUS	  0x11

	#define TMC562V3_PWMCONF_2	  0x18
	#define TMC562V3_PWM_STATUS_2 0x19

	#define TMC562V3_RAMPMODE_1   0x20
	#define TMC562V3_XACTUAL_1    0x21
	#define TMC562V3_VACTUAL_1    0x22
	#define TMC562V3_VSTART_1     0x23
	#define TMC562V3_A1_1         0x24
	#define TMC562V3_V1_1         0x25
	#define TMC562V3_AMAX_1       0x26
	#define TMC562V3_VMAX_1       0x27
	#define TMC562V3_DMAX_1       0x28
	#define TMC562V3_D1_1         0x2A
	#define TMC562V3_VSTOP_1      0x2B
	#define TMC562V3_TZEROWAIT_1  0x2C
	#define TMC562V3_XTARGET_1    0x2D
	#define TMC562V3_IHOLD_IRUN_1 0x30
	#define TMC562V3_VCOOLTHRS_1  0x31
	#define TMC562V3_VHIGH_1      0x32
	#define TMC562V3_VDCMIN_1     0x33
	#define TMC562V3_SWMODE_1     0x34
	#define TMC562V3_RAMPSTAT_1   0x35
	#define TMC562V3_XLATCH_1     0x36
	#define TMC562V3_ENCMODE_1    0x38
	#define TMC562V3_XENC_1       0x39
	#define TMC562V3_ENC_CONST_1  0x3A
	#define TMC562V3_ENC_STATUS_1 0x3B
	#define TMC562V3_ENC_LATCH_1  0x3C

	#define TMC562V3_RAMPMODE_2   0x40
	#define TMC562V3_XACTUAL_2    0x41
	#define TMC562V3_VACTUAL_2    0x42
	#define TMC562V3_VSTART_2     0x43
	#define TMC562V3_A1_2         0x44
	#define TMC562V3_V1_2         0x45
	#define TMC562V3_AMAX_2       0x46
	#define TMC562V3_VMAX_2       0x47
	#define TMC562V3_DMAX_2       0x48
	#define TMC562V3_D1_2         0x4A
	#define TMC562V3_VSTOP_2      0x4B
	#define TMC562V3_TZEROWAIT_2  0x4C
	#define TMC562V3_XTARGET_2    0x4D
	#define TMC562V3_IHOLD_IRUN_2 0x50
	#define TMC562V3_VCOOLTHRS_2  0x51
	#define TMC562V3_VHIGH_2      0x52
	#define TMC562V3_VDCMIN_2     0x53
	#define TMC562V3_SWMODE_2     0x54
	#define TMC562V3_RAMPSTAT_2   0x55
	#define TMC562V3_XLATCH_2     0x56
	#define TMC562V3_ENCMODE_2    0x58
	#define TMC562V3_XENC_2       0x59
	#define TMC562V3_ENC_CONST_2  0x5A
	#define TMC562V3_ENC_STATUS_2 0x5B
	#define TMC562V3_ENC_LATCH_2  0x5C

	#define TMC562V3_MSLUT0       0x60
	#define TMC562V3_MSLUT1       0x61
	#define TMC562V3_MSLUT2       0x62
	#define TMC562V3_MSLUT3       0x63
	#define TMC562V3_MSLUT4       0x64
	#define TMC562V3_MSLUT5       0x65
	#define TMC562V3_MSLUT6       0x66
	#define TMC562V3_MSLUT7       0x67
	#define TMC562V3_MSLUTSEL     0x68
	#define TMC562V3_MSLUTSTART   0x69


	#define TMC562V3_MSCNT_1      0x6A
	#define TMC562V3_MSCURACT_1   0x6B
	#define TMC562V3_CHOPCONF_1   0x6C
	#define TMC562V3_COOLCONF_1   0x6D
	#define TMC562V3_DCCTRL_1     0x6E
	#define TMC562V3_DRVSTATUS_1  0x6F

	#define TMC562V3_MSCNT_2      0x7A
	#define TMC562V3_MSCURACT_2   0x7B
	#define TMC562V3_CHOPCONF_2   0x7C
	#define TMC562V3_COOLCONF_2   0x7D
	#define TMC562V3_DCCTRL_2     0x7E
	#define TMC562V3_DRVSTATUS_2  0x7F

	#define TMC562V3_PWMCONF_1	  0x10
	#define TMC562V3_PWM_STATUS	  0x11

	#define TMC562V3_RAMPMODE     0x00
	#define TMC562V3_XACTUAL      0x01
	#define TMC562V3_VACTUAL      0x02
	#define TMC562V3_VSTART       0x03
	#define TMC562V3_A1           0x04
	#define TMC562V3_V1           0x05
	#define TMC562V3_AMAX         0x06
	#define TMC562V3_VMAX         0x07
	#define TMC562V3_DMAX         0x08
	#define TMC562V3_D1           0x0A
	#define TMC562V3_VSTOP        0x0B
	#define TMC562V3_TZEROWAIT    0x0C
	#define TMC562V3_XTARGET      0x0D
	#define TMC562V3_IHOLD_IRUN   0x10
	#define TMC562V3_VCOOLTHRS    0x11
	#define TMC562V3_VHIGH        0x12
	#define TMC562V3_VDCMIN       0x13
	#define TMC562V3_SWMODE       0x14
	#define TMC562V3_RAMPSTAT     0x15
	#define TMC562V3_XLATCH       0x16
	#define TMC562V3_ENCMODE      0x18
	#define TMC562V3_XENC         0x19
	#define TMC562V3_ENC_CONST    0x1A
	#define TMC562V3_ENC_STATUS   0x1B
	#define TMC562V3_ENC_LATCH    0x1C
	#define TMC562V3_CHOPCONF     0x6C
	#define TMC562V3_COOLCONF     0x6D
	#define TMC562V3_DRVSTATUS    0x6F

	//Motorbits und Write-Bit
	#define TMC562V3_MOTOR0       0x20
	#define TMC562V3_MOTOR1       0x40
	#define TMC562V3_WRITE        0x80

	//Rampenmodi (Register TMC562_RAMPMODE)
	#define TMC562V3_MODE_POSITION   0
	#define TMC562V3_MODE_VELPOS     1
	#define TMC562V3_MODE_VELNEG     2
	#define TMC562V3_MODE_HOLD       3

	//Endschaltermodusbits (Register TMC562_SWMODE)
	#define TMC562V3_SW_STOPL_ENABLE   0x0001
	#define TMC562V3_SW_STOPR_ENABLE   0x0002
	#define TMC562V3_SW_STOPL_POLARITY 0x0004
	#define TMC562V3_SW_STOPR_POLARITY 0x0008
	#define TMC562V3_SW_SWAP_LR        0x0010
	#define TMC562V3_SW_LATCH_L_ACT    0x0020
	#define TMC562V3_SW_LATCH_L_INACT  0x0040
	#define TMC562V3_SW_LATCH_R_ACT    0x0080
	#define TMC562V3_SW_LATCH_R_INACT  0x0100
	#define TMC562V3_SW_LATCH_ENC      0x0200
	#define TMC562V3_SW_SG_STOP        0x0400
	#define TMC562V3_SW_SOFTSTOP       0x0800


	//Statusbitss (Register TMC562_RAMPSTAT)
	#define TMC562V3_RS_STOPL          0x0001
	#define TMC562V3_RS_STOPR          0x0002
	#define TMC562V3_RS_LATCHL         0x0004
	#define TMC562V3_RS_LATCHR         0x0008
	#define TMC562V3_RS_EV_STOPL       0x0010
	#define TMC562V3_RS_EV_STOPR       0x0020
	#define TMC562V3_RS_EV_STOP_SG     0x0040
	#define TMC562V3_RS_EV_POSREACHED  0x0080
	#define TMC562V3_RS_VELREACHED     0x0100
	#define TMC562V3_RS_POSREACHED     0x0200
	#define TMC562V3_RS_VZERO          0x0400
	#define TMC562V3_RS_ZEROWAIT       0x0800
	#define TMC562V3_RS_SECONDMOVE     0x1000
	#define TMC562V3_RS_SG             0x2000

	#define MOTOR_ADDR(m) (0x20 << m )
	#define MOTOR_ADDR_DRV(m)  (m << 4)

	typedef struct
	{
		SPIChannelTypeDef *SPIChannel;
		int velocityMotor1;
		int velocityMotor2;
		const int32 registerResetState[128];
		const uint8 registerAccess[128];
		void (*periodicJob)(uint32 tick);
		void (*writeDatagram)(uint8 Address, uint8 x1, uint8 x2, uint8 x3, uint8 x4);
		void (*writeInt)(uint8 Address, int Value);
		int (*readInt)(uint8 Address);
		ConfigurationTypeDef *config;
		uint8 (*reset)();
		uint8 (*restore)();
	} TMC562V3TypeDef;

	TMC562V3TypeDef TMC562V3;

#endif
