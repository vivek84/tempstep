#ifndef _H_VITAL_SIGNS_MONITOR
	#define _H_VITAL_SIGNS_MONITOR

	#define VM_MIN_INTERACE_BOARD		70
	#define VM_MAX_INTERACE_BOARD		700

	#define VSM_CHX						(1<<0)
	#define VSM_CH1						(1<<1)
	#define VSM_CH2						(1<<2)

	#define VSM_ERRORS_VM 				(1<<0)
	#define VSM_ERRORS_CH1				(1<<1)
	#define VSM_ERRORS_CH2				(1<<2)
	#define VSM_BUSY					(1<<3)
	#define VSM_BUSY_CH1				(1<<4)
	#define VSM_BUSY_CH2				(1<<5)
	#define VSM_ERRORS_BROWNOUT			(1<<6)
	#define VSM_ERRORS_BROWNOUT_CH1		(1<<7)
	#define VSM_ERRORS_BROWNOUT_CH2		(1<<8)
	#define VSM_ERRORS_OVERVOLTAGE 		(1<<9)
	#define VSM_ERRORS_OVERVOLTAGE_CH1 	(1<<10)
	#define VSM_ERRORS_OVERVOLTAGE_CH2 	(1<<11)

	#define VSM_HARD_RATE_NORMAL 		500
	#define VSM_HARD_RATE_FAST			50

	typedef struct
	{
		int8		debugMode;
		int8		busy;
		uint8		brownOut;
		uint8		overVoltage;
		int32		errorMask;
		int32		errors;
		uint32	heartRate;
		uint32	VM;
		void (*checkVitalSigns) (uint32);
	} VitalSignsMonitorTypeDef;

	VitalSignsMonitorTypeDef VitalSignsMonitor;
#endif
