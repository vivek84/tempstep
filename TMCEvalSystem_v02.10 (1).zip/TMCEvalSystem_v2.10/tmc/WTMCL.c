#include <stdlib.h>
#include "stm32f2xx.h"

#include "boards/board.h"
#include "WTMCL.h"
#include "TMCL.h"
#include "../hal/HAL.h"
#include "demoBoards/TMC5062_tablet.h"
#include "../tmc/boardAssignment.h"

static void init();
static void process(unsigned int tick);
static void rx();
static void tx();
static void periodicJob(unsigned int tick);
static void delegationDummy();
static void checkVitalSigns();
static void processPackage();
static void processSystemPackage();

static WTMCLCTRLTypeDef CTRL =
{
	.noVitalSignTXedSince		= 0,
	.noVitalSignRXedSince		= 0,
	.resetSince					= 0,
	.isVirgin					= 0,
	.checksumErrors				= 0,
	.WTMCLPulse					= 0,
	.RXTX						= &Wireless
};

WTMCLTypeDef WTMCL =
{
	.init 						= init,
	.process					= process,
	.tx							= tx,
	.rx							= rx,
 	.periodicJob_delegate		= delegationDummy,
 	.processPackage_delegate	= delegationDummy,
 	.in							= &CTRL.in,
 	.out						= &CTRL.out,
};

static void init()
{

	CTRL.resetSince 			= 0;
	if(!CTRL.isVirgin) HAL.IOs->config->toOutput(&HAL.IOs->pins->WIRELESS_NRST);
	if(!CTRL.isVirgin) HAL.IOs->config->setLow(&HAL.IOs->pins->WIRELESS_NRST);

	CTRL.RXTX->clearBuffers();

	CTRL.in.error				= WTMCL_PACK_ERR_INCOMPLETE;
	CTRL.out.error				= WTMCL_PACK_ERR_INCOMPLETE;
	CTRL.noVitalSignTXedSince	= 0;
	CTRL.noVitalSignRXedSince	= 0;

	TMC5062Demo.init();
}

static void process(unsigned int tick)
{
	rx();
	processPackage();
	periodicJob(tick);
	WTMCL.processPackage_delegate();
}

static void rx()
{
	char
		in;
	int
		checkSum = 0;

	CTRL.in.error 	= WTMCL_PACK_ERR_INCOMPLETE;

	if(CTRL.isVirgin && CTRL.RXTX->bytesAvailable()) CTRL.isVirgin = 0;

	if(CTRL.RXTX->bytesAvailable() < 7) return;

	CTRL.in.error 				= 0;
	CTRL.noVitalSignRXedSince	= 0;

	CTRL.RXTX->rx(&in);
	checkSum					+= in;
	CTRL.in.type 				= in;

	CTRL.RXTX->rx(&in);
	checkSum					+= in;
	CTRL.in.number 				= in;

	CTRL.RXTX->rx(&in);
	checkSum					+= in;
	CTRL.in.value 				= in<<24;

	CTRL.RXTX->rx(&in);
	checkSum					+= in;
	CTRL.in.value 				|= in<<16;

	CTRL.RXTX->rx(&in);
	checkSum					+= in;
	CTRL.in.value 				|= in<<8;

	CTRL.RXTX->rx(&in);
	checkSum					+= in;
	CTRL.in.value 				|= in;

	CTRL.RXTX->rx(&in);
	CTRL.in.checkSum 			= in;

	if(CTRL.in.checkSum != (checkSum & 0xFF))
	{
		CTRL.in.error |= WTMCL_PACK_ERR_CHECKSUM;
		CTRL.checksumErrors++;
	}
	else CTRL.checksumErrors = (CTRL.checksumErrors > 0) ? CTRL.checksumErrors-1 : 0;

}

static void tx()
{
	char
		out			= 0;

	int
		checkSum 	= 0;


	if(CTRL.out.error & WTMCL_PACK_ERR_INCOMPLETE) return;

	out 		= CTRL.out.type;
	CTRL.RXTX->tx(out);
	checkSum	+= out;

	out 		= CTRL.out.number;
	CTRL.RXTX->tx(out);
	checkSum	+= out;

	out 		= (CTRL.out.value >> 24)	& 0xFF;
	CTRL.RXTX->tx(out);
	checkSum	+= out;

	out 		= (CTRL.out.value >> 16)	& 0xFF;
	CTRL.RXTX->tx(out);
	checkSum	+= out;

	out 		= (CTRL.out.value >> 8)		& 0xFF;
	CTRL.RXTX->tx(out);
	checkSum	+= out;

	out 		= (CTRL.out.value >> 0)		& 0xFF;
	CTRL.RXTX->tx(out);
	checkSum	+= out;

	CTRL.RXTX->tx(checkSum&0xFF);


	CTRL.out.error				= WTMCL_PACK_ERR_INCOMPLETE;
	CTRL.noVitalSignTXedSince	= 0;
}

static void periodicJob(unsigned int tick)
{
	static unsigned oldTick = 0;

	if(abs(tick-oldTick) < WTMCL_TICK) return;
	oldTick = tick;

	WTMCL.periodicJob_delegate();
	checkVitalSigns();
}

static void checkVitalSigns()
{
	if(!(HAL.IOs->pins->WIRELESS_NRST.port->ODR & HAL.IOs->pins->WIRELESS_NRST.bitWeight))
	{
		if(CTRL.resetSince++ >= WTMCL_RESET_FOR_CYC)
		{
			HAL.IOs->config->setHigh(&HAL.IOs->pins->WIRELESS_NRST);
			CTRL.isVirgin = 1;
			CTRL.RXTX->tx('-');
			CTRL.RXTX->tx('-');
			CTRL.RXTX->tx('-');
		}
		return;
	}

	if(CTRL.noVitalSignRXedSince++ >= WTMCL_VITAL_SIGN_RX_EACH_CYC)
	{
		init();
		return;
	}

	if(CTRL.noVitalSignTXedSince++ == WTMCL_VITAL_SIGN_TX_EACH_CYC)
	{
		CTRL.out.type				= 0;
		CTRL.out.number				= 0;
		CTRL.out.value				= 0;
		CTRL.out.checkSum			= 0;
		CTRL.out.error				= 0;

		CTRL.noVitalSignTXedSince 	= 0;

		tx();
	}

	if(CTRL.checksumErrors == WTMCL_MAX_CHECKSUM_ERRORS)
	{
		CTRL.out.type		= 0;
		CTRL.out.number 	= WTMCL_SYS_CMD_SYNC;
		CTRL.out.value 		= 0;

		CTRL.checksumErrors = 0;
		tx();
	}
}

static void processPackage()
{
	if((CTRL.in.error & WTMCL_PACK_ERR_CHECKSUM))		return;
	if((CTRL.in.error & WTMCL_PACK_ERR_DISCARD))		return;
	processSystemPackage();
	WTMCL.processPackage_delegate();
}

static void processSystemPackage()
{
	char
		i;

	if(CTRL.in.type) 	return;
	if(CTRL.in.error) 	return;

	switch(CTRL.in.number)
	{
		case WTMCL_SYS_CMD_DIE:
			WTMCL.init();
		break;

		case WTMCL_SYS_CMD_SYNC:
			if(!CTRL.in.value)
			{
				CTRL.RXTX->tx(0);
				for(i=0; i<10; i++)
				{
					CTRL.out.type	= 0;
					CTRL.out.number = WTMCL_SYS_CMD_SYNC;
					CTRL.out.value 	= 1;
					tx();
				}
			}
		break;
	}
	CTRL.in.error |= WTMCL_PACK_ERR_DISCARD;
}

static void delegationDummy()
{

}
