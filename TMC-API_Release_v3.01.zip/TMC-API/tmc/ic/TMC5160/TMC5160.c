/*
 * TMC5160.c
 *
 *  Created on: 17.03.2017
 *      Author: ED based on BS
 */

#include "TMC5160.h"

// => Shared variables todo: decide if these variables go here (API) or in Evalboard/Module
extern int tmc5160_VMax;
extern u8 tmc5160_VMaxModified;
extern int tmc5160_AMax;
extern u8 tmc5160_AMaxModified;
// <= Shared variables

// => SPI wrapper
extern int tmc5160_spi_readInt(uint8 address);
extern void tmc5160_spi_writeInt(uint8 address, int32 value);
//extern u16 tmc5160_spi_readRegister16BitValue(uint8 address, uint8 channel);
//extern void tmc5160_spi_writeRegister16BitValue(uint8 address, uint8 channel, uint16 value);
// <= SPI wrapper

#define VEL_FACTOR 0.953674316406         //fClk/2 / 2^23   (fClk=16MHz)
#define ACC_FACTOR 116.415321827          //fClk^2 / (512*256) / 2^24   (fClk=16MHz)

// todo: decide if the shadow register is done here (API) or in Evalboard/Module (1)
s32 tmc5160_shadowRegister[128];
static uint8 tmc5160_registerAccess[128]=
{
		// access
		// none :	0
		// r 	:	1
		// w 	: 	2
		// rw 	: 	3
		// r/w 	: 	7

		//	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F
			3, 1, 1, 2, 7, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//00..0f
			2, 2, 1, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//10..1f

			3, 3, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 0, 0,    	//20..2f
			0, 0, 0, 2, 3, 1, 0, 0, 3, 3, 2, 1, 1, 0, 0, 0,    	//30..3f
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//40..2f
			0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//50..3f

			2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 3, 2, 2, 1,    	//60..6f
			2, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0		//70..7f
};

/*******************************************************************
   Function: tmc5160_writeInt()
   Parameter: Axis: Axis Number
              Address: Register Address
              Value: integer to be written

   Returns: ---

   Purpose: Write a 32-bit value into a TMC5160_-Register.
 ********************************************************************/
void tmc5160_writeInt(uint8 Address, int32 Value)
{
	tmc5160_spi_writeInt(Address, Value);

	// todo: decide if the shadow register is done here (API) or in Evalboard/Module (2)
	tmc5160_shadowRegister[Address & 0x7f] = Value;
}

/*******************************************************************
   Function: tmc5160_readInt()
   Parameter: Axis: Axis Number
              Address: Register Address

   Returns: Register value

   Purpose: Read a 32-bit value from a TMC5160_-Register.
 ********************************************************************/
int32 tmc5160_readInt(uint8 Address)
{
	int32 Value;

	Address &= 0x7f;

	// todo: decide if the shadow register is done here (API) or in Evalboard/Module (3)
	if(!(tmc5160_registerAccess[Address] & 1) && !(tmc5160_registerAccess[Address] & 4))
		return tmc5160_shadowRegister[Address];	// register not readable -> software copy

	Value = tmc5160_spi_readInt(Address);

    // VACTUAL register has only 24 bits => correct sign bits
    if((Address==0x22 || Address==0x42)	&& (Value & BIT23)) Value |= 0xff000000;

	return Value;
}

/*******************************************************************
   Function: tmc5160_init()
   Parameter: ---

   Returns: ---

   Purpose: Initializes registers of TMC5160_
 ********************************************************************/
void tmc5160_init(void)
{
	//Standard values for chopper
	tmc5160_writeInt(TMC5160_PWMCONF, 0x500C8);

	//Reset position
	tmc5160_writeInt(TMC5160_RAMPMODE, TMC5160_MODE_POSITION);
	tmc5160_writeInt(TMC5160_XTARGET, 0);
	tmc5160_writeInt(TMC5160_XACTUAL, 0);

	//Standard values for speed and acceleration
	tmc5160_writeInt(TMC5160_VSTART, 1 / VEL_FACTOR);
	tmc5160_writeInt(TMC5160_A1, 25600 / ACC_FACTOR);
	tmc5160_writeInt(TMC5160_V1, 25600 / VEL_FACTOR);
	tmc5160_writeInt(TMC5160_AMAX, 51200 / ACC_FACTOR);
	tmc5160_writeInt(TMC5160_VMAX, 51200 / VEL_FACTOR);
	tmc5160_writeInt(TMC5160_DMAX, 51200 / ACC_FACTOR);
	tmc5160_writeInt(TMC5160_D1, 25600 / ACC_FACTOR);
	tmc5160_writeInt(TMC5160_VSTOP, 10 / VEL_FACTOR);
};

/*******************************************************************
   Function: tmc5160_rotate()
   Parameter: velocity: Rotation speed

   Returns: ---

   Purpose: Rotate TMC5160 Motor
 ********************************************************************/
void tmc5160_rotate(int32 velocity)
{
	if(tmc5160_AMaxModified)
	{
		tmc5160_writeInt(TMC5160_AMAX, tmc5160_AMax);
		tmc5160_AMaxModified=FALSE;
	}
	tmc5160_VMaxModified=TRUE;
	if(velocity >= 0)
	{
		tmc5160_writeInt(TMC5160_RAMPMODE, TMC5160_MODE_VELPOS);
	}
	else
	{
		tmc5160_writeInt(TMC5160_RAMPMODE, TMC5160_MODE_VELNEG);
		velocity = - velocity;
	}
	tmc5160_writeInt(TMC5160_VMAX, velocity);
}

/*******************************************************************
   Function: tmc5160_motorStop()
   Parameter: ---

   Returns: ---

   Purpose: Stop TMC5160 Motor
 ********************************************************************/
void tmc5160_motorStop()
{
	tmc5160_VMaxModified=TRUE;
	tmc5160_writeInt(TMC5160_VMAX, 0);
	tmc5160_writeInt(TMC5160_RAMPMODE, TMC5160_MODE_VELPOS);
}

/*******************************************************************
   Function: tmc5160_hardStop()
   Parameter: ---
   Returns: ---

   Purpose: Stop a motor immediately
 ********************************************************************/
void tmc5160_hardStop()
{
	tmc5160_VMaxModified=TRUE;
	tmc5160_AMaxModified=TRUE;
	tmc5160_writeInt(TMC5160_VMAX, 0);
	tmc5160_writeInt(TMC5160_AMAX, 65535);
	tmc5160_writeInt(TMC5160_RAMPMODE, TMC5160_MODE_VELPOS);
}

/*******************************************************************
   Function: tmc5160_moveToAbsolutePosition()
   Parameter: position: target position
              velocity: rotation speed

   Returns: ---

   Purpose: Move TMC5160 Motor to a certain position
 ********************************************************************/
void tmc5160_moveToAbsolutePosition(int32 position, int32 velocity)
{
	if(tmc5160_AMaxModified)
	{
		tmc5160_writeInt(TMC5160_AMAX, tmc5160_AMax);
		tmc5160_AMaxModified = FALSE;
	}
	if(tmc5160_VMaxModified)
	{
		tmc5160_writeInt(TMC5160_VMAX, velocity);
		tmc5160_VMaxModified = FALSE;
	}
	tmc5160_writeInt(TMC5160_XTARGET, position);
	tmc5160_writeInt(TMC5160_RAMPMODE, TMC5160_MODE_POSITION);
}

/*******************************************************************
   Function: tmc5160_moveToRelativePosition()
   Parameter: position: target position
              velocity: rotation speed

   Returns: ---

   Purpose: Increase or decrease TMC5160 position a certain value
 ********************************************************************/
void tmc5160_moveToRelativePosition(int32 position, int32 velocity, int32 reference)
{
	if(tmc5160_AMaxModified)
	{
		tmc5160_writeInt(TMC5160_AMAX, tmc5160_AMax);
		tmc5160_AMaxModified = FALSE;
	}
	if(tmc5160_VMaxModified)
	{
		tmc5160_writeInt(TMC5160_VMAX, velocity);
		tmc5160_VMaxModified = FALSE;
	}
	tmc5160_writeInt(TMC5160_XTARGET, reference+position);
	tmc5160_writeInt(TMC5160_RAMPMODE, TMC5160_MODE_POSITION);
}

/*******************************************************************
  Set and get functions for each setting of the IHOLD_IRUN register
********************************************************************/
void tmc5160_setIHold(uint8 current)
{
	u32 Value=tmc5160_readInt(TMC5160_IHOLD_IRUN) & 0xFFFE0;
	tmc5160_writeInt(TMC5160_IHOLD_IRUN, Value | ((current & 0x1F) << 0));
}

void tmc5160_setIRun(uint8 current)
{
	u32 Value=tmc5160_readInt(TMC5160_IHOLD_IRUN) & 0xFE0FF;
	tmc5160_writeInt(TMC5160_IHOLD_IRUN, Value | ((current & 0x1F) << 8));
}

void tmc5160_setIHoldDelay(uint8 delay)
{
	u32 Value=tmc5160_readInt(TMC5160_IHOLD_IRUN) & 0xFFFF;
	tmc5160_writeInt(TMC5160_IHOLD_IRUN, Value | ((delay & 0xF) << 16));
}

uint8 tmc5160_getIHold()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 0) & 0x1F;
}

uint8 tmc5160_getIRun()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 8) & 0x1F;
}

uint8 tmc5160_getIHoldDelay()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 16) & 0xF;
}

/*******************************************************************
  Set and get functions for each setting of the CHOPCONF register
********************************************************************/
void tmc5160_setStealthChop(uint8 Enable)
{
	u32 Value=tmc5160_readInt(TMC5160_GCONF) & 0x3FFFB;
	tmc5160_writeInt(TMC5160_GCONF, Value | ((Enable & 0x01) << 2));
}

uint8 tmc5160_getStealthChop()
{
  return (tmc5160_readInt(TMC5160_GCONF) >> 2) & 0x1;
}

void tmc5160_setChopperMStepRes(uint8 MRes)
{
	u32 Value;

	Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xf0ffffff;
	tmc5160_writeInt(TMC5160_CHOPCONF, Value | ((MRes & 0x0f) << 24));
}

uint8 tmc5160_getChopperMStepRes()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 24) & 0x0f;
}

void tmc5160_setChopperMStepInterpolation(uint8 Enable)
{
	u32 Value;

	Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xefffffff;
	tmc5160_writeInt(TMC5160_CHOPCONF, Value | ((Enable & 0x01) << 28));
}

uint8 tmc5160_getChopperMStepInterpolation()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 28) & 0x01;
}

void tmc5160_setChopperVSenseMode(uint8 Mode)
{
	u32 Value;

	Value=tmc5160_readInt(TMC5160_CHOPCONF);

	if(Mode)
		Value|=BIT17;
	else
		Value&= ~BIT17;

	tmc5160_writeInt(TMC5160_CHOPCONF, Value);
}

uint8 tmc5160_getChopperVSenseMode()
{
  return tmc5160_readInt(TMC5160_CHOPCONF) & BIT17 ? 1:0;
}

void tmc5160_setChopperTOff(uint8 TOff)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xfffffff0;
  tmc5160_writeInt(TMC5160_CHOPCONF, Value | (TOff & 0x0f));
}

void tmc5160_setChopperHysteresisStart(uint8 HysteresisStart)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xffffff8f;
  tmc5160_writeInt(TMC5160_CHOPCONF, Value | ((HysteresisStart & 0x07) << 4));
}

void tmc5160_setChopperHysteresisEnd(uint8 HysteresisEnd)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xfffff87f;
  tmc5160_writeInt(TMC5160_CHOPCONF, Value | ((HysteresisEnd & 0x0f) << 7));
}

void tmc5160_setChopperBlankTime(uint8 BlankTime)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xfffe7fff;
  tmc5160_writeInt(TMC5160_CHOPCONF, Value | ((BlankTime & 0x03) << 15));
}

void tmc5160_setChopperSync(uint8 Sync)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xff0fffff;
  tmc5160_writeInt(TMC5160_CHOPCONF, Value | ((Sync & 0x0f) << 20));
}

void tmc5160_setChopperDisableShortToGround(uint8 Disable)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF);
  if(Disable)
    Value|=BIT30;
  else
    Value&= ~BIT30;

  tmc5160_writeInt(TMC5160_CHOPCONF, Value);
}

void tmc5160_setChopperVHighChm(uint8 VHighChm)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF);
  if(VHighChm)
    Value|=BIT19;
  else
    Value&= ~BIT19;

  tmc5160_writeInt(TMC5160_CHOPCONF, Value);
}

void tmc5160_setChopperVHighFs(uint8 VHighFs)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF);
  if(VHighFs)
    Value|=BIT18;
  else
    Value&= ~BIT18;

  tmc5160_writeInt(TMC5160_CHOPCONF, Value);
}

void tmc5160_setChopperConstantTOffMode(uint8 ConstantTOff)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF);
  if(ConstantTOff)
    Value|=BIT14;
  else
    Value&= ~BIT14;

  tmc5160_writeInt(TMC5160_CHOPCONF, Value);
}

void tmc5160_setChopperRandomTOff(uint8 RandomTOff)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF);
  if(RandomTOff)
    Value|=BIT13;
  else
    Value&= ~BIT13;

  tmc5160_writeInt(TMC5160_CHOPCONF, Value);
}

void tmc5160_setChopperDisableFastDecayComp(uint8 Disable)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF);
  if(Disable)
    Value|=BIT12;
  else
    Value&= ~BIT12;

  tmc5160_writeInt(TMC5160_CHOPCONF, Value);
}

void tmc5160_setChopperFastDecayTime(uint8 Time)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xffffff8f;

  if(Time & BIT3)
    Value|=BIT11;
  else
    Value&= ~BIT11;

  tmc5160_writeInt(TMC5160_CHOPCONF, Value | ((Time & 0x07) << 4));
}

void tmc5160_setChopperSineWaveOffset(uint8 Offset)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_CHOPCONF) & 0xfffff87f;
  tmc5160_writeInt(TMC5160_CHOPCONF, Value | ((Offset & 0x0f) << 7));
}

uint8 tmc5160_getChopperTOff()
{
  return tmc5160_readInt(TMC5160_CHOPCONF) & 0x0000000f;
}

uint8 tmc5160_getChopperHysteresisStart()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 4) & 0x07;
}

uint8 tmc5160_getChopperHysteresisEnd()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 7) & 0x0f;
}

uint8 tmc5160_getChopperBlankTime()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 15) & 0x03;
}

uint8 tmc5160_getChopperSync()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 20) & 0x0f;
}

uint8 tmc5160_getChopperDisableShortToGround()
{
  return tmc5160_readInt(TMC5160_CHOPCONF) & BIT30 ? 1:0;
}

uint8 tmc5160_getChopperVHighChm()
{
  return tmc5160_readInt(TMC5160_CHOPCONF) & BIT19 ? 1:0;
}

uint8 tmc5160_getChopperVHighFs()
{
  return tmc5160_readInt(TMC5160_CHOPCONF) & BIT18 ? 1:0;
}

uint8 tmc5160_getChopperConstantTOffMode()
{
  return tmc5160_readInt(TMC5160_CHOPCONF) & BIT14 ? 1:0;
}

uint8 tmc5160_getChopperRandomTOff()
{
  return tmc5160_readInt(TMC5160_CHOPCONF) & BIT13 ? 1:0;
}

uint8 tmc5160_getChopperDisableFastDecayComp()
{
  return tmc5160_readInt(TMC5160_CHOPCONF) & BIT12 ? 1:0;
}

uint8 tmc5160_getChopperFastDecayTime()
{
  u32 Value;
  uint8 Time;

  Value=tmc5160_readInt(TMC5160_CHOPCONF);
  Time=(Value >> 4) & 0x07;
  if(Value & BIT11) Time|=BIT3;

  return Time;
}

uint8 tmc5160_getChopperSineWaveOffset()
{
  return (tmc5160_readInt(TMC5160_CHOPCONF) >> 7) & 0x0f;
}

/*******************************************************************
  Set and get functions for each setting of the COOLCONF register
********************************************************************/
void tmc5160_setSmartEnergyUpStep(uint8 UpStep)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_COOLCONF) & 0xffffff9f;
  tmc5160_writeInt(TMC5160_COOLCONF, Value | ((UpStep & 0x03) << 5));
}

void tmc5160_setSmartEnergyDownStep(uint8 DownStep)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_COOLCONF) & 0xffff9fff;
  tmc5160_writeInt(TMC5160_COOLCONF, Value | ((DownStep & 0x03) << 13));
}

void tmc5160_setSmartEnergyStallLevelMax(uint8 Max)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_COOLCONF) & 0xfffff0ff;
  tmc5160_writeInt(TMC5160_COOLCONF, Value | ((Max & 0x0f) << 8));
}

void tmc5160_setSmartEnergyStallLevelMin(uint8 Min)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_COOLCONF) & 0xfffffff0;
  tmc5160_writeInt(TMC5160_COOLCONF, Value | (Min & 0x0f));
}

void tmc5160_setSmartEnergyStallThreshold(int8 Threshold)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_COOLCONF) & 0xff00ffff;
  tmc5160_writeInt(TMC5160_COOLCONF, Value | ((Threshold & 0xff) << 16));
}

void tmc5160_setSmartEnergyIMin(uint8 IMin)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_COOLCONF);
  if(IMin)
    Value|=BIT15;
  else
    Value&= ~BIT15;

  tmc5160_writeInt(TMC5160_COOLCONF, Value);
}

void tmc5160_setSmartEnergyFilter(uint8 Filter)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_COOLCONF);
  if(Filter)
    Value|=BIT24;
  else
    Value&= ~BIT24;

  tmc5160_writeInt(TMC5160_COOLCONF, Value);
}


uint8 tmc5160_getSmartEnergyUpStep()
{
  return (tmc5160_readInt(TMC5160_COOLCONF) >> 5) & 0x03;
}

uint8 tmc5160_getSmartEnergyDownStep()
{
  return (tmc5160_readInt(TMC5160_COOLCONF) >> 13) & 0x03;
}

uint8 tmc5160_getSmartEnergyStallLevelMax()
{
  return (tmc5160_readInt(TMC5160_COOLCONF) >> 8) & 0x0f;
}

uint8 tmc5160_getSmartEnergyStallLevelMin()
{
  return tmc5160_readInt(TMC5160_COOLCONF) & 0x0f;
}

int32 tmc5160_getSmartEnergyStallThreshold()
{
  int32 Value;

  Value=(tmc5160_readInt(TMC5160_COOLCONF) >> 16) & 0xff;
  if(Value & BIT7) Value|=0xffffff00;

  return Value;
}

uint8 tmc5160_getSmartEnergyIMin()
{
  if(tmc5160_readInt(TMC5160_COOLCONF) & BIT15)
    return 1;
  else
    return 0;
}

uint8 tmc5160_getSmartEnergyFilter()
{
  if(tmc5160_readInt(TMC5160_COOLCONF) & BIT24)
    return 1;
  else
    return 0;
}

/*******************************************************************
  Set and get functions for each setting of the PWMCONF register
********************************************************************/
void tmc5160_setPWMFreewheelMode(uint8 Mode)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF) & 0xffcfffff;
  Mode&=0x03;
  Value|=Mode << 20;
  tmc5160_writeInt(TMC5160_PWMCONF, Value);
}

void tmc5160_setPWMSymmetric(uint8 Symmetric)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF);
  if(Symmetric)
    Value|=BIT19;
  else
    Value&= ~BIT19;
  tmc5160_writeInt(TMC5160_PWMCONF, Value);
}

void tmc5160_setPWMAutoscale(uint8 Autoscale)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF);
  if(Autoscale)
    Value|=BIT18;
  else
    Value&= ~BIT18;
  tmc5160_writeInt(TMC5160_PWMCONF, Value);
}

void tmc5160_setPWMFrequency(uint8 Frequency)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF) & 0xfffcffff;
  Frequency&=0x03;
  Value|=Frequency << 16;
  tmc5160_writeInt(TMC5160_PWMCONF, Value);
}

void tmc5160_setPWMGrad(uint8 PWMGrad)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF) & 0xffff00ff;
  Value|=PWMGrad << 8;
  tmc5160_writeInt(TMC5160_PWMCONF, Value);
}

void tmc5160_setPWMAmpl(uint8 PWMAmpl)
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF) & 0xffffff00;
  Value|=PWMAmpl;
  tmc5160_writeInt(TMC5160_PWMCONF, Value);
}


uint8 tmc5160_getPWMFreewheelMode()
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF);
  Value>>=20;

  return Value & 0x03;
}

uint8 tmc5160_getPWMSymmetric()
{
  if(tmc5160_readInt(TMC5160_PWMCONF) & BIT19)
    return TRUE;
  else
    return FALSE;
}

uint8 tmc5160_getPWMAutoscale()
{
  if(tmc5160_readInt(TMC5160_PWMCONF) & BIT18)
    return TRUE;
  else
    return FALSE;
}

uint8 tmc5160_getPWMFrequency()
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF);
  Value>>=16;

  return Value & 0x03;
}

uint8 tmc5160_getPWMGrad()
{
  u32 Value;

  Value=tmc5160_readInt(TMC5160_PWMCONF);
  Value>>=8;

  return Value & 0xff;
}

uint8 tmc5160_getPWMAmpl()
{
   return tmc5160_readInt(TMC5160_PWMCONF) & 0xff;
}
