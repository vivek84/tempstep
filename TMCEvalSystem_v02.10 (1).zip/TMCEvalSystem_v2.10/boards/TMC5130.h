#ifndef __TMC5130_H
	#define __TMC5130_H

	#include "board.h"
	EvalBoardTypeDef TMC5130;

#endif
