/*
 * TMC562.c
 *
 *  Created on: 26.01.2017
 *      Author: BS
 *    Based on: TMC562-MKL.h (26.01.2012 OK)
 */

#include "TMC562.h"

// => SPI wrapper
extern int tmc562_spi_readInt(uint8 address);
extern void tmc562_spi_writeInt(uint8 address, int32 value);
//extern u16 tmc562_spi_readRegister16BitValue(uint8 address, uint8 channel);
//extern void tmc562_spi_writeRegister16BitValue(uint8 address, uint8 channel, uint16 value);
// <= SPI wrapper


#define VEL_FACTOR 0.953674316406         //fClk/2 / 2^23   (fClk=16MHz)
#define ACC_FACTOR 116.415321827          //fClk^2 / (512*256) / 2^24   (fClk=8MHz)

//Table that shows whether each TMC562 register can be read (1) or not(0)
static const uint8 TMC562RegisterReadable[128]={
1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    //00..0f
0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,    //10..1f
1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,    //20..2f
0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0,    //30..3f
1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,    //40..4f
0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0,    //50..5f
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1,    //60..6f
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1,    //70..7f
};

static int32 TMC562SoftwareCopy[128];	//Software copy for all TMC562 registers (not only readable ones)


/*******************************************************************
   Function: tmc562_writeDatagram()
   Parameter: Address: Register address (0x00..0x7f)
              x1, x2, x3, x4: Each byte of the register

   Returns: ---

   Purpose: Write a TMC562 register, giving the value of each byte.
   	   	  The software copy of the register will be as well updated.
********************************************************************/
void tmc562_writeDatagram(uint8 Address, uint8 x1, uint8 x2, uint8 x3, uint8 x4)
{
  int32 Value;

  Value=x1;
  Value<<=8;
  Value|=x2;
  Value<<=8;
  Value|=x3;
  Value<<=8;
  Value|=x4;

  //Write register in TMC562
  tmc562_spi_writeInt(Address, Value);

  //Update software copy
  TMC562SoftwareCopy[Address & 0x7f]=Value;
}


/*******************************************************************
   Function: tmc562_writeInt()
   Parameter: Address: Register address (0x00..0x7f)
              Value: value to be written

   Returns: ---

   Purpose: Write a TMC562 register. The software copy of the
   	   	  register will be as well updated.
********************************************************************/
void tmc562_writeInt(uint8 Address, int32 Value)
{
  //Write register in TMC562
  tmc562_spi_writeInt(Address, Value);

  //Update software copy
  TMC562SoftwareCopy[Address & 0x7f]=Value;
}


/*******************************************************************
   Function: tmc562_readInt()
   Parameter: Address: Register address (0x00..0x7f)

   Returns: read value

   Purpose: Read the value of a TMC562 register. If not readable,
   	   	  the value from the software copy will be returned.
********************************************************************/
int32 tmc562_readInt(uint8 Address)
{
  int32 Value;

  Address&=0x7f;
  if(TMC562RegisterReadable[Address])
  {
	//Register is readable -> read from TMC562
    //Two accesses are required
    tmc562_spi_readInt(Address);

    //For the second read access, address 0 (GCONF) will be used, so that
    //e.g. a non-read event bit won't be erased by mistake.
    Value = tmc562_spi_readInt(0);

    //Register VACTUAL has only 24 bits => set sign-bit
    if(Address==0x22 || Address==0x42)
    {
      if(Value & BIT23) Value|=0xff000000;
    }

    return Value;
  }
  else
  {
	//Register not readable => return software copy
    return TMC562SoftwareCopy[Address];
  }
}


/*******************************************************************
  Set and get functions for each setting of the CHOPCONF register
********************************************************************/
void tmc562_setChopperTOff(uint8 Motor, uint8 TOff)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0xfffffff0;
  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value | (TOff & 0x0f));
}

void tmc562_setChopperHysteresisStart(uint8 Motor, uint8 HysteresisStart)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0xffffff8f;
  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value | ((HysteresisStart & 0x07) << 4));
}

void tmc562_setChopperHysteresisEnd(uint8 Motor, uint8 HysteresisEnd)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0xfffff87f;
  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value | ((HysteresisEnd & 0x0f) << 7));
}

void tmc562_setChopperBlankTime(uint8 Motor, uint8 BlankTime)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0xfffe7fff;
  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value | ((BlankTime & 0x03) << 15));
}

void tmc562_setChopperSync(uint8 Motor, uint8 Sync)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0xff0fffff;
  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value | ((Sync & 0x0f) << 20));
}

void tmc562_setChopperMStepRes(uint8 Motor, uint8 MRes)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0xf0ffffff;
  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value | ((MRes & 0x0f) << 24));
}

void tmc562_setChopperDisableShortToGround(uint8 Motor, uint8 Disable)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor));
  if(Disable)
    Value|=BIT30;
  else
    Value&= ~BIT30;

  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value);
}

void tmc562_setChopperVHighChm(uint8 Motor, uint8 VHighChm)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor));
  if(VHighChm)
    Value|=BIT19;
  else
    Value&= ~BIT19;

  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value);
}

void tmc562_setChopperVHighFs(uint8 Motor, uint8 VHighFs)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor));
  if(VHighFs)
    Value|=BIT18;
  else
    Value&= ~BIT18;

  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value);
}

void tmc562_setChopperConstantTOffMode(uint8 Motor, uint8 ConstantTOff)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor));
  if(ConstantTOff)
    Value|=BIT14;
  else
    Value&= ~BIT14;

  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value);
}

void tmc562_setChopperRandomTOff(uint8 Motor, uint8 RandomTOff)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor));
  if(RandomTOff)
    Value|=BIT13;
  else
    Value&= ~BIT13;

  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value);
}

void tmc562_setChopperDisableFastDecayComp(uint8 Motor, uint8 Disable)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor));
  if(Disable)
    Value|=BIT12;
  else
    Value&= ~BIT12;

  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value);
}

void tmc562_setChopperFastDecayTime(uint8 Motor, uint8 Time)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0xffffff8f;

  if(Time & BIT3)
    Value|=BIT11;
  else
    Value&= ~BIT11;

  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value | ((Time & 0x07) << 4));
}

void tmc562_setChopperSineWaveOffset(uint8 Motor, uint8 Offset)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0xfffff87f;
  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value | ((Offset & 0x0f) << 7));
}

void tmc562_setChopperVSenseMode(uint8 Motor, uint8 Mode)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor));

  if(Mode)
    Value|=BIT17;
  else
    Value&= ~BIT17;

  tmc562_writeInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor), Value);
}

uint8 tmc562_getChopperTOff(uint8 Motor)
{
  return tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & 0x0000000f;
}

uint8 tmc562_getChopperHysteresisStart(uint8 Motor)
{
  return (tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) >> 4) & 0x07;
}

uint8 tmc562_getChopperHysteresisEnd(uint8 Motor)
{
  return (tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) >> 7) & 0x0f;
}

uint8 tmc562_getChopperBlankTime(uint8 Motor)
{
  return (tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) >> 15) & 0x03;
}

uint8 tmc562_getChopperSync(uint8 Motor)
{
  return (tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) >> 20) & 0x0f;
}

uint8 tmc562_getChopperMStepRes(uint8 Motor)
{
  return (tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) >> 24) & 0x0f;
}

uint8 tmc562_getChopperDisableShortToGround(uint8 Motor)
{
  return tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & BIT30 ? 1:0;
}

uint8 tmc562_getChopperVHighChm(uint8 Motor)
{
  return tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & BIT19 ? 1:0;
}

uint8 tmc562_getChopperVHighFs(uint8 Motor)
{
  return tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & BIT18 ? 1:0;
}

uint8 tmc562_getChopperConstantTOffMode(uint8 Motor)
{
  return tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & BIT14 ? 1:0;
}

uint8 tmc562_getChopperRandomTOff(uint8 Motor)
{
  return tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & BIT13 ? 1:0;
}

uint8 tmc562_getChopperDisableFastDecayComp(uint8 Motor)
{
  return tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & BIT12 ? 1:0;
}

uint8 tmc562_getChopperFastDecayTime(uint8 Motor)
{
  uint32 Value;
  uint8 Time;

  Value=tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor));
  Time=(Value >> 4) & 0x07;
  if(Value & BIT11) Time|=BIT3;

  return Time;
}

uint8 tmc562_getChopperSineWaveOffset(uint8 Motor)
{
  return (tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) >> 7) & 0x0f;
}

uint8 tmc562_getChopperVSenseMode(uint8 Motor)
{
  return tmc562_readInt(TMC562_CHOPCONF|MOTOR_ADDR_DRV(Motor)) & BIT17 ? 1:0;
}


/*******************************************************************
  Set and get functions for each setting of the COOLCONF register
********************************************************************/
void tmc562_setSmartEnergyUpStep(uint8 Motor, uint8 UpStep)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) & 0xffffff9f;
  tmc562_writeInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor), Value | ((UpStep & 0x03) << 5));
}

void tmc562_setSmartEnergyDownStep(uint8 Motor, uint8 DownStep)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) & 0xffff9fff;
  tmc562_writeInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor), Value | ((DownStep & 0x03) << 13));
}

void tmc562_setSmartEnergyStallLevelMax(uint8 Motor, uint8 Max)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) & 0xfffff0ff;
  tmc562_writeInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor), Value | ((Max & 0x0f) << 8));
}

void tmc562_setSmartEnergyStallLevelMin(uint8 Motor, uint8 Min)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) & 0xfffffff0;
  tmc562_writeInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor), Value | (Min & 0x0f));
}

void tmc562_setSmartEnergyStallThreshold(uint8 Motor, int8 Threshold)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) & 0xff00ffff;
  tmc562_writeInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor), Value | ((Threshold & 0xff) << 16));
}

void tmc562_setSmartEnergyIMin(uint8 Motor, uint8 IMin)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor));
  if(IMin)
    Value|=BIT15;
  else
    Value&= ~BIT15;

  tmc562_writeInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor), Value);
}

void tmc562_setSmartEnergyFilter(uint8 Motor, uint8 Filter)
{
  uint32 Value;

  Value=tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor));
  if(Filter)
    Value|=BIT24;
  else
    Value&= ~BIT24;

  tmc562_writeInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor), Value);
}


uint8 tmc562_getSmartEnergyUpStep(uint8 Motor)
{
  return (tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) >> 5) & 0x03;
}

uint8 tmc562_getSmartEnergyDownStep(uint8 Motor)
{
  return (tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) >> 13) & 0x03;
}

uint8 tmc562_getSmartEnergyStallLevelMax(uint8 Motor)
{
  return (tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) >> 8) & 0x0f;
}

uint8 tmc562_getSmartEnergyStallLevelMin(uint8 Motor)
{
  return tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) & 0x0f;
}

int32 tmc562_getSmartEnergyStallThreshold(uint8 Motor)
{
  int32 Value;

  Value=(tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) >> 16) & 0xff;
  if(Value & BIT7) Value|=0xffffff00;

  return Value;
}

uint8 tmc562_getSmartEnergyIMin(uint8 Motor)
{
  if(tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) & BIT15)
    return 1;
  else
    return 0;
}

uint8 tmc562_getSmartEnergyFilter(uint8 Motor)
{
  if(tmc562_readInt(TMC562_COOLCONF|MOTOR_ADDR_DRV(Motor)) & BIT24)
    return 1;
  else
    return 0;
}

/*******************************************************************
  Set and get functions for each setting of the PWMCONF register
********************************************************************/
void tmc562_setPwmAmpl(uint8 Motor, uint8 PwmAmpl)
{
  uint32 Value;

  Value=tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1);
  tmc562_writeInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1,
    (Value & 0xffffff00) | PwmAmpl);
}

void tmc562_setPwmGrad(uint8 Motor, uint8 PwmGrad)
{
  uint32 Value;

  Value=tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1);
  tmc562_writeInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1,
    (Value & 0xffff00ff) | (PwmGrad << 8));
}

void tmc562_setPwmFreq(uint8 Motor, uint8 PwmFreq)
{
  uint32 Value;

  Value=tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1);
  tmc562_writeInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1,
    (Value & 0xfffcffff) | ((PwmFreq &0x03) << 16));
}

void tmc562_setPwmAutoscale(uint8 Motor, uint8 Autoscale)
{
  uint32 Value;

  Value=tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1) & 0xfffbffff;
  if(Autoscale) Value|=BIT18;
  tmc562_writeInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1, Value);
}

void tmc562_setPwmFreewheel(uint8 Motor, uint8 Freewheel)
{
  uint32 Value;

  Value=tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1);
  tmc562_writeInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1,
    (Value & 0xff3fffff) | ((Freewheel &0x03) << 20));
}


uint8 tmc562_getPwmAmpl(uint8 Motor)
{
  return tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1) & 0xff;
}

uint8 tmc562_getPwmGrad(uint8 Motor)
{
  return (tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1) >> 8) & 0xff;
}

uint8 tmc562_getPwmFreq(uint8 Motor)
{
  return (tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1) >> 16) & 0x03;
}

uint8 tmc562_getPwmAutoscale(uint8 Motor)
{
  return (tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1) >> 18) & 0x01;
}

uint8 tmc562_getPwmFreewheel(uint8 Motor)
{
  return (tmc562_readInt((Motor==1) ? TMC562_PWMCONF_2 : TMC562_PWMCONF_1) >> 20) & 0x03;
}

uint8 tmc562_getPwmStatus(uint8 Motor)
{
  return tmc562_readInt((Motor==1) ? TMC562_PWMSTATUS_2 : TMC562_PWMSTATUS_1) & 0xff;
}


/*******************************************************************
   Function: tmc562_initMotorDrivers()
   Parameter: ---

   Returns: ---

   Purpose: initialize TMC562
********************************************************************/
void tmc562_initMotorDrivers(void)
{
  //2-phase configuration Motor 1
  tmc562_writeDatagram(TMC562_CHOPCONF_1, 0x00, 0x01, 0x01, 0x35);
  tmc562_writeDatagram(TMC562_IHOLD_IRUN_1, 0x00, 0x07, 0x14, 0x00);

  //2-phase configuration Motor 2
  tmc562_writeDatagram(TMC562_CHOPCONF_2, 0x00, 0x01, 0x01, 0x35);
  tmc562_writeDatagram(TMC562_IHOLD_IRUN_2, 0x00, 0x07, 0x14, 0x00);

  //no parallel turn off/on of the driver
  tmc562_writeInt(0x00, tmc562_readInt(0x00) & ~BIT0);

  //turn on PP and INT outputs (so that they don't float)
  tmc562_writeInt(0x00, tmc562_readInt(0x00) | BIT3);

  //Reset positions
  tmc562_writeInt(TMC562_RAMPMODE_1, TMC562_MODE_POSITION);
  tmc562_writeInt(TMC562_XTARGET_1, 0);
  tmc562_writeInt(TMC562_XACTUAL_1, 0);
  tmc562_writeInt(TMC562_RAMPMODE_2, TMC562_MODE_POSITION);
  tmc562_writeInt(TMC562_XTARGET_2, 0);
  tmc562_writeInt(TMC562_XACTUAL_2, 0);

  //Standard values for speed and acceleration
  tmc562_writeInt(TMC562_VSTART_1, 1);
  tmc562_writeInt(TMC562_A1_1, 220);
  tmc562_writeInt(TMC562_V1_1, 26843);
  tmc562_writeInt(TMC562_AMAX_1, 439);    //51200pps/s (for 16MHz)
  tmc562_writeInt(TMC562_VMAX_1, 53687);  //51200pps   (for 16MHz)
  tmc562_writeInt(TMC562_DMAX_1, 439);
  tmc562_writeInt(TMC562_D1_1, 220);
  tmc562_writeInt(TMC562_VSTOP_1, 10);

  tmc562_writeInt(TMC562_VSTART_2, 1);
  tmc562_writeInt(TMC562_A1_2, 220);
  tmc562_writeInt(TMC562_V1_2, 26843);
  tmc562_writeInt(TMC562_AMAX_2, 439);
  tmc562_writeInt(TMC562_VMAX_2, 53687);
  tmc562_writeInt(TMC562_DMAX_2, 439);
  tmc562_writeInt(TMC562_D1_2, 220);
  tmc562_writeInt(TMC562_VSTOP_2, 10);
}


/*******************************************************************
   Function: tmc562_hardStop()
   Parameter: Motor: motor number (0..N_O_MOTORS)
   Returns: ---

   Purpose: Stop a motor immediately
********************************************************************/
void tmc562_hardStop(uint8 Motor)
{
  tmc562_writeInt(TMC562_VMAX|MOTOR_ADDR(Motor), 0);
  tmc562_writeDatagram(TMC562_RAMPMODE|MOTOR_ADDR(Motor), 0, 0, 0, TMC562_MODE_VELPOS);
}
