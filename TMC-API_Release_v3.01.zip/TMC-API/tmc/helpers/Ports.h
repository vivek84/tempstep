/*
 * Ports.h
 *
 *  Created on: 04.08.2014
 *      Author: ed
 */

#ifndef PORTS_H_
#define PORTS_H_

	#define PORT_0		0x00000001u
	#define PORT_1		0x00000002u
	#define PORT_2		0x00000004u
	#define PORT_3		0x00000008u

	#define PORT_4		0x00000010u
	#define PORT_5		0x00000020u
	#define PORT_6		0x00000040u
	#define PORT_7		0x00000080u

	#define PORT_8		0x00000100u
	#define PORT_9		0x00000200u
	#define PORT_10		0x00000400u
	#define PORT_11		0x00000800u

	#define PORT_12		0x00001000u
	#define PORT_13		0x00002000u
	#define PORT_14		0x00004000u
	#define PORT_15		0x00008000u

	#define PORT_16		0x00010000u
	#define PORT_17		0x00020000u
	#define PORT_18		0x00040000u
	#define PORT_19		0x00080000u

	#define PORT_20		0x00100000u
	#define PORT_21     0x00200000u
	#define PORT_22     0x00400000u
	#define PORT_23     0x00800000u

	#define PORT_24		0x01000000u
	#define PORT_25		0x02000000u
	#define PORT_26		0x04000000u
	#define PORT_27		0x08000000u

	#define PORT_28		0x10000000u
	#define PORT_29		0x20000000u
	#define PORT_30		0x40000000u
	#define PORT_31		0x80000000u

#endif /* PORTS_H_ */
