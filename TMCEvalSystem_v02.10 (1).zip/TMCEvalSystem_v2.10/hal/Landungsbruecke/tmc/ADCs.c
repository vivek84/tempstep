#include "../../HAL.h"
#include "../../ADCs.h"

/* analog channels definition for use with ADC/GPIO macros */
#define DAD0          (uint8)0
#define DAD1          (uint8)1
#define DAD2          (uint8)2
#define DAD3          (uint8)3
#define AD04          (uint8)4
#define AD05          (uint8)5
#define AD06          (uint8)6
#define AD07          (uint8)7
#define AD08          (uint8)8
#define AD09          (uint8)9
#define AD10          (uint8)10
#define AD11          (uint8)11
#define AD12          (uint8)12
#define AD13          (uint8)13
#define AD14          (uint8)14
#define AD15          (uint8)15
#define AD16          (uint8)16
#define AD17          (uint8)17
#define AD18          (uint8)18
#define AD19          (uint8)19
#define AD20          (uint8)20
#define AD21          (uint8)21
#define AD22          (uint8)22
#define AD23          (uint8)23
#define AD24          (uint8)24
#define AD25          (uint8)25
#define AD26          (uint8)26
#define AD27          (uint8)27
#define AD28          (uint8)28
#define AD29          (uint8)29
#define AD30          (uint8)30
#define AD31          (uint8)31

static void init(void);
static void triggerMeasurement(uint32 tick);
static void deInit(void);

volatile uint16 adc0_result[] = {1,2,3};  				// data buffer 3 x 1 samples
volatile uint16 adc1_result[] = {1,2,3};				// data buffer 3 x 1 samples
volatile uint8  adc0_mux[]     = {DAD1, AD12, AD13};	// mux0 scan line, ADC0_DP1(Pin 14) and ADC0_SE12(Pin 55) and ADC0_SE13(Pin 56)
volatile uint8  adc1_mux[]     = {DAD0, DAD1, DAD3};    // mux1 scan line, ADC1_DP0(Pin 20) and ADC1_DP1(Pin 16) and ADC1_DP3(Pin 18)

ADCTypeDef ADCs =
{
	.AIN0				= &adc1_result[1],
	.AIN1				= &adc1_result[2],
	.AIN2				= &adc1_result[0],
	.DIO4				= &adc0_result[1],
	.DIO5				= &adc0_result[2],
	.VM					= &adc0_result[0],
	.triggerMeasurement	= triggerMeasurement,
	.init				= init,
	.deInit				= deInit
};


static void init(void)
{
	// === ADC initialization ===
	// enable clock for ADC0/ADC1
	SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;
	SIM_SCGC3 |= SIM_SCGC3_ADC1_MASK;
	// enable clock for DMA

	HAL.IOs->pins->DIO4.configuration.GPIO_Mode = GPIO_Mode_IN;
	HAL.IOs->pins->DIO5.configuration.GPIO_Mode = GPIO_Mode_IN;

	HAL.IOs->config->set(&HAL.IOs->pins->DIO4);
	HAL.IOs->config->set(&HAL.IOs->pins->DIO5);

	// CFG1: set ADC clocks
	ADC0_CFG1 = ADC_CFG1_MODE(0x03) | ADC_CFG1_ADICLK(1);
	ADC1_CFG1 = ADC_CFG1_MODE(0x03) | ADC_CFG1_ADICLK(1);

	// CFG2: configuration for high speed conversions and selects the long sample time duration
	ADC0_CFG2 = ADC_CFG2_ADLSTS(0);		// use default longest sample time
	ADC1_CFG2 = ADC_CFG2_ADLSTS(0);		// use default longest sample time

	// SC2: conversion
	ADC0_SC2 = ADC_SC2_DMAEN_MASK; 	// enable DMA
	ADC1_SC2 = ADC_SC2_DMAEN_MASK; 	// enable DMA;

//				average over 32 samples				| 	continous
	ADC0_SC3 = 	ADC_SC3_AVGE_MASK | ADC_SC3_AVGS(3) | 	ADC_SC3_ADCO_MASK;
	ADC1_SC3 = 	ADC_SC3_AVGE_MASK | ADC_SC3_AVGS(3) | 	ADC_SC3_ADCO_MASK;

	uint16 cal;

	ADC0_SC3 |= ADC_SC3_CAL_MASK;
	while(ADC0_SC3 & ADC_SC3_CAL_MASK);

	cal = 0;
	cal += ADC0_CLP0;
	cal += ADC0_CLP1;
	cal += ADC0_CLP2;
	cal += ADC0_CLP3;
	cal += ADC0_CLP4;
	cal += ADC0_CLPS;
	cal >>=1;
	cal |=1<<15;

	ADC0_PG = cal;

	ADC1_SC3 |= ADC_SC3_CAL_MASK;
	while(ADC1_SC3 & ADC_SC3_CAL_MASK);

	cal = 0;
	cal += ADC1_CLP0;
	cal += ADC1_CLP1;
	cal += ADC1_CLP2;
	cal += ADC1_CLP3;
	cal += ADC1_CLP4;
	cal += ADC1_CLPS;
	cal >>=1;
	cal |=1<<15;

	ADC1_PG = cal;

	// SC1: trigger modes
	ADC0_SC1A = ADC_SC1_ADCH(DAD1);
	ADC1_SC1A = ADC_SC1_ADCH(DAD0);

	// === DMA initialization ===

	// enable clock for DMA
	SIM_SCGC7 |= SIM_SCGC7_DMA_MASK;

	// enable clock for DMA mux
	SIM_SCGC6 |= SIM_SCGC6_DMAMUX_MASK;

	// === setup DMA channels for ADC0 ===

	// DMA channel 0, use for write ADC mux channel, from SRAM to ADC
	DMAMUX_CHCFG0 			= DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(0x36);//54			// DMA source DMA Mux channel 1(Source Number 54)
	DMA_TCD0_SADDR          = (uint32)&adc0_mux[0]; 					                   		// new mux setting
	DMA_TCD0_SOFF           = 0x01;                                            					// source address increment, adding "1"
	DMA_TCD0_SLAST          = (uint32)-3;                                    					// source address decrement after major loop complete
	DMA_TCD0_DADDR          = (uint32)&ADC0_SC1A;                           					// destination address ADC0 mux selector, ADC0 control register
	DMA_TCD0_DOFF           = 0x00;         													// destination address increment, adding "0"
	DMA_TCD0_DLASTSGA       = 0x00;                                    							// destination address shift, go to back to [0]
	DMA_TCD0_NBYTES_MLNO    = 0x01;                                     						// number of bytes minor loop, ADC0 setting 8-bit -> 1-byte transfer
	DMA_TCD0_BITER_ELINKNO  = 0x03;                                           					// major loop step, 2 ADC channel are scanning
	DMA_TCD0_CITER_ELINKNO  = 0x03;                                           					// major loop step, 2 ADC channel are scanning
	DMA_TCD0_ATTR           = DMA_ATTR_SSIZE(0) | DMA_ATTR_DSIZE(0);							// source a destination size, 8bit
	DMA_TCD0_CSR            = 0x0000;                                         					//

	// DMA channel 1, use for read ADC result data, from ADC to SRAM
	DMAMUX_CHCFG1           = DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(0x28);   			//DMA source ADC0(Source Number 40)
	DMA_TCD1_SADDR          = (uint32)&ADC0_RA;													// source address ADC0 result register
	DMA_TCD1_SOFF           = 0x00;                                     						// source address increment, adding "0"
	DMA_TCD1_SLAST          = 0x00;                                            					// source address decrement after major loop complete
	DMA_TCD1_DADDR          = (uint32)&adc0_result[0];                     						// destination address, ADC0 result buffer
	DMA_TCD1_DOFF           = 0x02;                                         					// destination address increment in bytes, increment for next buffer adress, adding "+2"
	DMA_TCD1_DLASTSGA       = (uint32)-6;                                    					// Destination address decrement after major loop complete 2 x 1 x 2Bytes
	DMA_TCD1_NBYTES_MLNO    = 0x02;                                           					// no of bytes minor loop, 16bit data(short)
	DMA_TCD1_BITER_ELINKYES = (DMA_BITER_ELINKNO_ELINK_MASK|0x0000|0x03);	// enable channel link, Channel 0, Major loop step 1 x 2 = 2
	DMA_TCD1_CITER_ELINKYES  = (DMA_CITER_ELINKNO_ELINK_MASK|0x03);            					// enable channel link, Major loop step 1 x 2 = 2
	DMA_TCD1_ATTR           = DMA_ATTR_SSIZE(1)|DMA_ATTR_DSIZE(1);             					// source a destination size, 16bit
	DMA_TCD1_CSR            = (DMA_CSR_MAJORLINKCH(0)|DMA_CSR_MAJORELINK_MASK)|					// major loop finished start request for Channel 0
							DMA_CSR_INTMAJOR_MASK;											// Irq. enable, full transfer, half complete transfer
	DMA_ERQ                |= DMA_ERQ_ERQ1_MASK;                               					// HW request enable

	// === setup DMA channels for ADC1 ===

	// DMA channel 2, use for write ADC mux channel, from SRAM to ADC
	DMAMUX_CHCFG2 			= DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(0x38);				// DMA source DMA Mux channel 2 (Source Number 56)
	DMA_TCD2_SADDR          = (uint32)&adc1_mux[0];                    							// new mux setting
	DMA_TCD2_SOFF           = 0x01;                                            					// source address increment, adding "1"
	DMA_TCD2_SLAST          = (uint32)-3;                                    					// source address decrement after major loop complete
	DMA_TCD2_DADDR          = (uint32)&ADC1_SC1A;                           					// destination address ADC1 mux selector
	DMA_TCD2_DOFF           = 0x00;         													// destination address increment, adding "0"
	DMA_TCD2_DLASTSGA       = 0x00;                                    							// destination address shift, go to back to [0]
	DMA_TCD2_NBYTES_MLNO    = 0x01;                                     						// no of bytes minor loop
	DMA_TCD2_BITER_ELINKNO  = 0x03;                              								// major loop step, 2 ADC channel are scanning
	DMA_TCD2_CITER_ELINKNO  = 0x03;                                            					// major loop step, 2 ADC channel are scanning
	DMA_TCD2_ATTR           = DMA_ATTR_SSIZE(0) | DMA_ATTR_DSIZE(0);							// source a destination size, 8bit
	DMA_TCD2_CSR            = 0x0000;                                         					//

	// DMA channel 3, use for read ADC result data, from ADC to SRAM
	DMAMUX_CHCFG3           = DMAMUX_CHCFG_ENBL_MASK | DMAMUX_CHCFG_SOURCE(0x29);   			//DMA source ADC1 (Source Number 41)
	DMA_TCD3_SADDR          = (uint32)&ADC1_RA;													// source address ADC1 result register
	DMA_TCD3_SOFF           = 0x00;                                     						// source address increment, adding "0"
	DMA_TCD3_SLAST          = 0x00;                                            					// source address decrement after major loop complete
	DMA_TCD3_DADDR          = (uint32)&adc1_result[0];                     						// destination address, ADC1 result buffer
	DMA_TCD3_DOFF           = 0x02;                                         					// destination address increment, adding "+2"
	DMA_TCD3_DLASTSGA       = (uint32)-6;                                    					// Destination address decrement after major loop complete 2 x 1 x 2Bytes
	DMA_TCD3_NBYTES_MLNO    = 0x02;                                           					// no of bytes minor loop, 16bit ADC result
	DMA_TCD3_BITER_ELINKNO  = (DMA_BITER_ELINKNO_ELINK_MASK|DMA_BITER_ELINKYES_LINKCH(2)|0x03); // enable channel link, Channel 2, Major loop step 1 x  = 2
	DMA_TCD3_CITER_ELINKNO  = (DMA_CITER_ELINKNO_ELINK_MASK|0x03);            					// enable channel link, Major loop step 1 x 2 = 2
	DMA_TCD3_ATTR           = DMA_ATTR_SSIZE(1)|DMA_ATTR_DSIZE(1);             					// source a destination size, 16bit
	DMA_TCD3_CSR            = (DMA_CSR_MAJORLINKCH(2)|DMA_CSR_MAJORELINK_MASK)|					// major loop finished start request for Channel 2
							DMA_CSR_INTMAJOR_MASK;											// Irq. enable, full transfer, half complete transfer
	DMA_ERQ                |= DMA_ERQ_ERQ3_MASK;

	EnableInterrupts;
}

static void deInit()
{
	// disable clock for ADC0/ADC1
	SIM_SCGC6 &= ~(SIM_SCGC6_ADC0_MASK);
	SIM_SCGC3 &= ~(SIM_SCGC3_ADC1_MASK);

	// disable clock for DMA
	SIM_SCGC7 &= ~(SIM_SCGC7_DMA_MASK);

	// disable clock for DMA mux
	SIM_SCGC6 &= ~(SIM_SCGC6_DMAMUX_MASK);
}

static void triggerMeasurement(uint32 tick)
{
	static uint32 lastTick;
	if(abs(tick-lastTick) > 50)
	{
		ADC0_SC1A 	= DAD1;
		ADC1_SC1A 	= DAD0;
		lastTick 	= tick;
	}
}
