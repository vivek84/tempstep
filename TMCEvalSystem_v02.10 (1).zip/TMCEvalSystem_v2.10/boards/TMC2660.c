#include "262.h"
#include "TMC2660.h"
#include "../tmc/stepDir.h"

#define	ERRORS_I_STS			(1<<0)	// stand still current too high
#define	ERRORS_I_TIMEOUT_STS	(1<<1)	// current limited in stand still to prevent driver from demage

#define VM_MIN			50	// VM[V/10] min
#define VM_MAX			293	// VM[V/10] max +10%

#define I_STAND_STILL 5
#define T_STAND_STILL 1000

static void RotateLeft(void);
static void RotateRight(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void deInit(void);
static void init(void);
static void rotate();
static uint8 reset();
static void enableDriver(uint8 disable0Enable1global2);
static void periodicJob(uint32 tick);
static void userFunction();
static void writeRegister(void);
static void readRegister(void);
static void getMeasuredSpeed(void);
static void coolStepActivationChanged(uint32 value);

static uint32 compatibilityMode = 1;

StepDirectionChannelType stepDirDummmy;

static StepDirectionChannelType *StepDirCh[] = {&stepDirDummmy};

EvalBoardTypeDef TMC2660 = {init};

typedef struct
{
	IOPinTypeDef *CSN;
	IOPinTypeDef *STEP;
	IOPinTypeDef *DIR;
	IOPinTypeDef *ENN;
	IOPinTypeDef *SG_TST;
	IOPinTypeDef *TEMP_BRIDGE;
} PinsTypeDef;

static PinsTypeDef Pins;

static void userFunction()
{
	switch(TMCL.command->Type)
	{

		case 0:	// disable continuos read/write mode
			// In continuos read/write mode settings will be continously written to TMC2660 and all replies are requested rotatory.
			// It's the default mode to prevent TMC2660 from loosing setting on brownout and being alway up to date with all chip states.
			TMC262.continuosModeEnable = (TMCL.command->Value.Int32) ? 0 : 1;
		break;

		case 1:	// disable compatibility mode
			// per default compability mode is enabled,
			// saying firmware works with orl TMC262-Eval Tool
			// e.g. stallGuard value is only

			compatibilityMode = (TMCL.command->Value.Int32) ? 0 : 1;
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void rotate()
{
	if(TMCL.command->Motor==0)
	{
		if(TMCL.command->Type==0)
		{
			TMC262.isStandStillCurrentLimit	= 0;
			TMC262.isStandStillOverCurrent	= 0;
			StepDirCh[0]->rampMode 			= SD_RAMP_MODE_VELOCITY;
			StepDirCh[0]->targetVelocity 	= TMCL.command->Value.Int32;
		}
		else TMCL.reply->Status=REPLY_WRONG_TYPE;
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void RotateRight(void)
{
	rotate();
}

static void RotateLeft(void)
{
	TMCL.command->Value.Int32 = -TMCL.command->Value.Int32;
	rotate();
}

static void MotorStop(void)
{
	TMCL.command->Value.Int32 = 0;
	rotate();
}

static void MoveToPosition(void)
{
	if(TMCL.command->Motor==0)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				StepDirCh[0]->targetPosition	= TMCL.command->Value.Int32;
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
			break;

			case MVP_REL:
				StepDirCh[0]->targetPosition	= StepDirCh[0]->actualPosition+TMCL.command->Value.Int32;
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
			break;

			default:
				TMCL.reply->Status			= REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
	if(TMCL.command->Motor==0)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				StepDirCh[0]->targetPosition			= TMCL.command->Value.Int32;
			break;

			case 1:
				StepDirCh[0]->actualPosition			= TMCL.command->Value.Int32;
			break;

			case 2:
				StepDirCh[0]->targetVelocity			= TMCL.command->Value.Int32;
			break;

			case 3:
				StepDirCh[0]->actualVelocity			= TMCL.command->Value.Int32;
			break;

			case 4:
				StepDirCh[0]->maxPositioningSpeed		= abs(TMCL.command->Value.Int32);
			break;

			case 5:
				StepDirCh[0]->actualAcceleration		= TMCL.command->Value.Int32;
			break;

			case 6:
				TMC262.runCurrentScale					= TMCL.command->Value.Int32;
				TMC262.setField(TMC262_SGCSCONF, TMC262_SET_CS(-1), TMC262_SET_CS(TMCL.command->Value.Int32));
			break;

			case 7:
				TMC262.standStillCurrentScale = TMCL.command->Value.Int32;
			break;

			case 140:
				switch(TMCL.command->Value.Int32)
				{
					case 1:	 	TMCL.command->Value.Int32 = 8; break;
					case 2:	 	TMCL.command->Value.Int32 = 7; break;
					case 4:	 	TMCL.command->Value.Int32 = 6; break;
					case 8:	 	TMCL.command->Value.Int32 = 5; break;
					case 16:	TMCL.command->Value.Int32 = 4; break;
					case 32:	TMCL.command->Value.Int32 = 3; break;
					case 64:	TMCL.command->Value.Int32 = 2; break;
					case 128:	TMCL.command->Value.Int32 = 1; break;
					case 256:	TMCL.command->Value.Int32 = 0; break;
					default: 	TMCL.command->Value.Int32 = -1; break;
				}

				if(TMCL.command->Value.Int32 != -1)
				{
					TMC262.setField(TMC262_DRVCTRL, TMC262_SET_MRES(-1), TMC262_SET_MRES(TMCL.command->Value.Int32));
				}
				else TMCL.reply->Status = REPLY_INVALID_VALUE;

				TMC262.setField(TMC262_DRVCTRL, TMC262_SET_MRES(-1), TMC262_SET_MRES(TMCL.command->Value.Int32));
			break;

			case 160:
				TMC262.setField(TMC262_DRVCTRL, TMC262_SET_INTERPOL(-1), TMC262_SET_INTERPOL(TMCL.command->Value.Int32));
			break;

			case 161:
				TMC262.setField(TMC262_DRVCTRL, TMC262_SET_DEDGE(-1), TMC262_SET_DEDGE(TMCL.command->Value.Int32));
			break;

			case 162:
				TMC262.setField(TMC262_CHOPCONF, TMC262_SET_TBL(-1), TMC262_SET_TBL(TMCL.command->Value.Int32));
			break;

			case 163:
				TMC262.setField(TMC262_CHOPCONF, TMC262_SET_CHM(-1), TMC262_SET_CHM(TMCL.command->Value.Int32));
			break;

			case 164:
				TMC262.setField(TMC262_CHOPCONF, TMC262_SET_HDEC(-1), TMC262_SET_HDEC(TMCL.command->Value.Int32));
			break;

			case 165:
				TMC262.setField(TMC262_CHOPCONF, TMC262_SET_HEND(-1), TMC262_SET_HEND(TMCL.command->Value.Int32));
			break;

			case 166:
				TMC262.setField(TMC262_CHOPCONF, TMC262_SET_HSTRT(-1), TMC262_SET_HSTRT(TMCL.command->Value.Int32));
			break;

			case 167:
				TMC262.setField(TMC262_CHOPCONF, TMC262_SET_TOFF(-1), TMC262_SET_TOFF(TMCL.command->Value.Int32));
			break;

			case 168:
				TMC262.setField(TMC262_SMARTEN, TMC262_SET_SEIMIN(-1), TMC262_SET_SEIMIN(TMCL.command->Value.Int32));
			break;

			case 169:
				TMC262.setField(TMC262_SMARTEN, TMC262_SET_SEDN(-1), TMC262_SET_SEDN(TMCL.command->Value.Int32));
			break;

			case 170:
				TMC262.setField(TMC262_SMARTEN, TMC262_SET_SEMAX(-1), TMC262_SET_SEMAX(TMCL.command->Value.Int32));
			break;

			case 171:
				TMC262.setField(TMC262_SMARTEN, TMC262_SET_SEUP(-1), TMC262_SET_SEUP(TMCL.command->Value.Int32));
			break;

			case 172:
				StepDir.ch1->coolStepActiveValue = TMCL.command->Value.Int32;
			break;

			case 173:
				TMC262.setField(TMC262_SGCSCONF, TMC262_SET_SFILT(-1), TMC262_SET_SFILT(TMCL.command->Value.Int32));
			break;

			case 174:
				TMC262.setField(TMC262_SGCSCONF, TMC262_SET_SGT(-1), TMC262_SET_SGT(TMCL.command->Value.Int32));
			break;

			case 175:
				TMC262.setField(TMC262_DRVCONF, TMC262_SET_SLPH(-1), TMC262_SET_SLPH(TMCL.command->Value.Int32));
			break;

			case 176:
				TMC262.setField(TMC262_DRVCONF, TMC262_SET_SLPL(-1), TMC262_SET_SLPL(TMCL.command->Value.Int32));
			break;

			case 177:
				TMC262.setField(TMC262_DRVCONF, TMC262_SET_DISS2G(-1), TMC262_SET_DISS2G(TMCL.command->Value.Int32));
			break;

			case 178:
				TMC262.setField(TMC262_DRVCONF, TMC262_SET_TS2G(-1), TMC262_SET_TS2G(TMCL.command->Value.Int32));
			break;

			case 179:
				TMC262.setField(TMC262_DRVCONF, TMC262_SET_VSENSE(-1), TMC262_SET_VSENSE(TMCL.command->Value.Int32));
			break;

			case 181:
				StepDirCh[0]->stopOnStallVelocityTreshold		= TMCL.command->Value.Int32;
				StepDirCh[0]->stallFlagIn 						= 0;
			break;

			case 182:
				StepDirCh[0]->coolStepVelocityTreshold = TMCL.command->Value.Int32;
			break;

			case 183:
				TMC262.setField(TMC262_DRVCONF, TMC262_SET_SDOFF(-1), TMC262_SET_SDOFF(TMCL.command->Value.Int32));
			break;

			case 184:
				TMC262.setField(TMC262_CHOPCONF, TMC262_SET_RNDTF(-1), TMC262_SET_RNDTF(TMCL.command->Value.Int32));
			break;

			case 185:
				TMC262.setField(TMC262_DRVCONF, TMC262_SET_TST(-1), TMC262_SET_TST(TMCL.command->Value.Int32));
			break;

			case 214:
				TMC262.standStillTimeout = TMCL.command->Value.Int32;
			break;

			default:
				TMCL.reply->Status	=	REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void GetAxisParameter(void)
{
	if(TMCL.command->Motor==0)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				TMCL.reply->Value.Int32		= StepDirCh[0]->targetPosition;
			break;

			case 1:
				TMCL.reply->Value.Int32		= StepDirCh[0]->actualPosition;
			break;

			case 2:
				TMCL.reply->Value.Int32		= StepDirCh[0]->targetVelocity;
			break;

			case 3:
				TMCL.reply->Value.Int32		= StepDirCh[0]->actualVelocity;
			break;

			case 4:
				TMCL.reply->Value.Int32		= StepDirCh[0]->maxPositioningSpeed;
			break;

			case 5:
				TMCL.reply->Value.Int32		= StepDirCh[0]->actualAcceleration;
			break;

			case 6:
				TMCL.reply->Value.Int32		= TMC262.runCurrentScale;
			break;

			case 7:
				TMCL.reply->Value.Int32		= TMC262.standStillCurrentScale;
			break;

			case 8:
				TMCL.reply->Value.Int32		= StepDirCh[0]->targetReached;
			break;

			case 29:
				TMCL.reply->Value.Int32 = StepDirCh[0]->actualVelocity;
			break;

			case 140:
				 // flipped to satisfy TMCL compatibility
				TMCL.reply->Value.Int32		= 8-TMC262_GET_MRES(TMC262.readInt(TMC262_DRVCTRL | TMC262_WRITE));
			break;

			case 160:
				TMCL.reply->Value.Int32		= TMC262_GET_INTERPOL(TMC262.readInt(TMC262_DRVCTRL | TMC262_WRITE));
			break;

			case 161:
				TMCL.reply->Value.Int32		= TMC262_GET_DEDGE(TMC262.readInt(TMC262_DRVCTRL | TMC262_WRITE));
			break;

			case 162:
				TMCL.reply->Value.Int32		= TMC262_GET_TBL(TMC262.readInt(TMC262_CHOPCONF | TMC262_WRITE));
			break;

			case 163:
				TMCL.reply->Value.Int32		= TMC262_GET_CHM(TMC262.readInt(TMC262_CHOPCONF | TMC262_WRITE));
			break;

			case 164:
				TMCL.reply->Value.Int32		= TMC262_GET_HDEC(TMC262.readInt(TMC262_CHOPCONF | TMC262_WRITE));
			break;

			case 165:
				TMCL.reply->Value.Int32		= TMC262_GET_HEND(TMC262.readInt(TMC262_CHOPCONF | TMC262_WRITE));
			break;

			case 166:
				TMCL.reply->Value.Int32		= TMC262_GET_HSTRT(TMC262.readInt(TMC262_CHOPCONF | TMC262_WRITE));
			break;

			case 167:
				TMCL.reply->Value.Int32		= TMC262_GET_TOFF(TMC262.readInt(TMC262_CHOPCONF | TMC262_WRITE));
			break;

			case 168:
				TMCL.reply->Value.Int32		= TMC262_GET_SEIMIN(TMC262.readInt(TMC262_SMARTEN | TMC262_WRITE));
			break;

			case 169:
				TMCL.reply->Value.Int32		= TMC262_GET_SEDN(TMC262.readInt(TMC262_SMARTEN | TMC262_WRITE));
			break;

			case 170:
				TMCL.reply->Value.Int32		= TMC262_GET_SEMAX(TMC262.readInt(TMC262_SMARTEN | TMC262_WRITE));
			break;

			case 171:
				TMCL.reply->Value.Int32		= TMC262_GET_SEUP(TMC262.readInt(TMC262_SMARTEN | TMC262_WRITE));
			break;

			case 172:
				TMCL.reply->Value.Int32		= StepDir.ch1->coolStepActiveValue;
			break;

			case 173:
				TMCL.reply->Value.Int32		= TMC262_GET_SFILT(TMC262.readInt(TMC262_SGCSCONF | TMC262_WRITE));
			break;

			case 174:
				TMCL.reply->Value.Int32		= TMC262_GET_SGT(TMC262.readInt(TMC262_SGCSCONF | TMC262_WRITE));

				if (TMCL.reply->Value.Int32 & 0x40) TMCL.reply->Value.Int32	|= (-1<<7);
			break;

			case 175:
				TMCL.reply->Value.Int32		= TMC262_GET_SLPH(TMC262.readInt(TMC262_DRVCONF | TMC262_WRITE));
			break;

			case 176:
				TMCL.reply->Value.Int32		= TMC262_GET_SLPL(TMC262.readInt(TMC262_DRVCONF | TMC262_WRITE));
			break;

			case 177:
				TMCL.reply->Value.Int32		= TMC262_GET_DISS2G(TMC262.readInt(TMC262_DRVCONF | TMC262_WRITE));
			break;

			case 178:
				TMCL.reply->Value.Int32		= TMC262_GET_TS2G(TMC262.readInt(TMC262_DRVCONF | TMC262_WRITE));
			break;

			case 179:
				TMCL.reply->Value.Int32		= TMC262_GET_VSENSE(TMC262.readInt(TMC262_DRVCONF | TMC262_WRITE));
			break;

			case 180:
				TMCL.reply->Value.Int32 	= TMC262_GET_SE(TMC262.readInt(TMC262_RESPONSE2));
			break;

			case 181:
				TMCL.reply->Value.Int32		= StepDirCh[0]->stopOnStallVelocityTreshold;
			break;

			case 182:
				TMCL.reply->Value.Int32		= StepDirCh[0]->coolStepVelocityTreshold;
			break;

			case 183:
				TMCL.reply->Value.Int32		= TMC262_GET_SDOFF(TMC262.readInt(TMC262_DRVCONF | TMC262_WRITE));
			break;

			case 184:
				TMCL.reply->Value.Int32		= TMC262_GET_RNDTF(TMC262.readInt(TMC262_CHOPCONF | TMC262_WRITE));
			break;

			case 185:
				TMCL.reply->Value.Int32		= TMC262_GET_TST(TMC262.readInt(TMC262_DRVCONF | TMC262_WRITE));
			break;

			case 206:
				TMCL.reply->Value.Int32		= (compatibilityMode) ? TMC262_GET_SGU(TMC262.readInt(TMC262_RESPONSE2)) : TMC262_GET_SG(TMC262.readInt(TMC262_RESPONSE1));
			break;

			case 207:
			break;

			case 208:
				TMCL.reply->Value.Int32		= TMC262.readInt(TMC262_RESPONSE_LATEST) & 0xFF;
			break;

			case 214:
				TMCL.reply->Value.Int32		= TMC262.standStillTimeout;
			break;

			default:
				TMCL.reply->Status			= REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void writeRegister(void)
{
	TMC262.writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32	= TMC262.readInt(TMCL.command->Type);
}

static void getMeasuredSpeed(void)
{
	switch(TMCL.command->Motor)
	{
		case 0:
			TMCL.reply->Value.Int32 	= StepDir.ch1->actualVelocity;
		break;

		default:
			TMCL.reply->Status 			= REPLY_WRONG_TYPE;
		break;
	}
}

static void coolStepActivationChanged(uint32 value)
{
	TMC262.setField(TMC262_SMARTEN, TMC262_SET_SEMIN(-1), TMC262_SET_SEMIN(value));
}

static void init(void)
{
	compatibilityMode 	= 1;

	Pins.ENN			= &HAL.IOs->pins->DIO0;
	Pins.SG_TST			= &HAL.IOs->pins->DIO1;
	Pins.STEP			= &HAL.IOs->pins->DIO6;
	Pins.DIR			= &HAL.IOs->pins->DIO7;
	Pins.CSN			= &HAL.IOs->pins->SPI2_CSN0;

	HAL.IOs->config->toOutput(Pins.STEP);
	HAL.IOs->config->toOutput(Pins.DIR);
	HAL.IOs->config->toOutput(Pins.ENN);
	HAL.IOs->config->toInput(Pins.SG_TST);
	HAL.IOs->config->toOutput(Pins.CSN);

#if defined(Startrampe)
	Pins.TEMP_BRIDGE	= &HAL.IOs->pins->AIN0;
	HAL.IOs->config->reset(Pins.TEMP_BRIDGE);
#endif

	TMC262.SPIChannel						= &HAL.SPI->ch2;
	TMC262.SPIChannel->CSN					= Pins.CSN;
	TMC262.config							= EvalBoards.ch2.config;
	EvalBoards.ch2.config->restore			= TMC262.restore;
	EvalBoards.ch2.config->reset			= reset;
	EvalBoards.ch2.config->isBusy 			= 0;
	EvalBoards.ch2.config->ptr	 			= 0;


	TMC262.standStillCurrentScale			= I_STAND_STILL;
	TMC262.standStillTimeout				= T_STAND_STILL;

	StepDir.init();
	StepDirCh[0] 							= StepDir.ch1;
	StepDirCh[0]->stepOut 					= Pins.STEP;
	StepDirCh[0]->dirOut 					= Pins.DIR;
	StepDirCh[0]->stallSignalIn				= Pins.SG_TST;
	StepDirCh[0]->coolStepActivationChanged = coolStepActivationChanged;
	StepDirCh[0]->coolStepInActiveValue 	= 0;



	EvalBoards.ch2.motorStop				= MotorStop;
	EvalBoards.ch2.getAxisParameter			= GetAxisParameter;
	EvalBoards.ch2.moveToPosition			= MoveToPosition;
	EvalBoards.ch2.rotateLeft				= RotateLeft;
	EvalBoards.ch2.rotateRight				= RotateRight;
	EvalBoards.ch2.setAxisParameter			= SetAxisParameter;
	EvalBoards.ch2.deInit					= deInit;
	EvalBoards.ch2.enableDriver				= enableDriver;
	EvalBoards.ch2.periodicJob				= periodicJob;
	EvalBoards.ch2.userFunction				= userFunction;
	EvalBoards.ch2.readRegister				= readRegister;
	EvalBoards.ch2.writeRegister			= writeRegister;
	EvalBoards.ch2.getMeasuredSpeed			= getMeasuredSpeed;
	EvalBoards.ch2.numberOfMotors			= 1;
	EvalBoards.ch2.VMMin					= VM_MIN;
	EvalBoards.ch2.VMMax					= VM_MAX;
	EvalBoards.numberOfMotors				= 1;
	enableDriver(2);
}

static void deInit(void)
{
	HAL.IOs->config->setHigh(Pins.ENN);

	HAL.IOs->config->reset(Pins.CSN);
	HAL.IOs->config->reset(Pins.DIR);
	HAL.IOs->config->reset(Pins.ENN);
	HAL.IOs->config->reset(Pins.SG_TST);
	HAL.IOs->config->reset(Pins.STEP);
	StepDir.deInit();
}

static void periodicJob(uint32 tick)
{
	TMC262.periodicJob(tick);

	EvalBoards.ch2.errors = (TMC262.isStandStillOverCurrent) 	? (EvalBoards.ch2.errors | ERRORS_I_STS) 			: (EvalBoards.ch2.errors & ~ERRORS_I_STS);
	EvalBoards.ch2.errors = (TMC262.isStandStillCurrentLimit) 	? (EvalBoards.ch2.errors | ERRORS_I_TIMEOUT_STS) 	: (EvalBoards.ch2.errors & ~ERRORS_I_TIMEOUT_STS);


//  Uncomment keep motors halted when no supply is detected to not to loose steps n this case.
//	vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	//	if(VitalSignsMonitor.brownOut)								StepDir.ch1->haltMask 	|= TMC2660_SD_HALT_BROWNOUT;
	//	else if(StepDir.ch1->haltMask & TMC2660_SD_HALT_BROWNOUT)	StepDir.ch1->haltMask 	&= 	~TMC2660_SD_HALT_BROWNOUT;
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


}

static uint8 reset()
{
	if(StepDirCh[0]->actualVelocity && !VitalSignsMonitor.brownOut) return 0;
	TMC262.reset();
	StepDirCh[0]->stallFlagIn 	= 0;
	compatibilityMode 			= 1;
	enableDriver(2);
	return 1;
}

static void enableDriver(uint8 enable)
{
	if(enable == 2) enable = EvalBoards.driverEnable;

	if(enable ==  0)											HAL.IOs->config->setHigh(Pins.ENN);
	else if((enable == 1) && (EvalBoards.driverEnable == 1))	HAL.IOs->config->setLow(Pins.ENN);
}

