#ifndef __TMC2130_H
	#define __TMC2130_H

	#include "board.h"
	EvalBoardTypeDef TMC2130;

#endif
