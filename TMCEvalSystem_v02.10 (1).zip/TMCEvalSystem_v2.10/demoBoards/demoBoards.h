#ifndef DEMOBOARDS_H_
	#define DEMOBOARDS_H_

	typedef struct
	{
		void (*init)(void);
	} DemoBoardsTypeDef;

#endif
