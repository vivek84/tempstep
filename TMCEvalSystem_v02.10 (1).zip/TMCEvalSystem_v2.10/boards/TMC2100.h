#ifndef __TMC2100_H
	#define __TMC2100_H

	#include "board.h"
	EvalBoardTypeDef TMC2100;

#endif
