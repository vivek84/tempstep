#include "squirrel.h"

static void writeDatagram(unsigned char address, unsigned char x1, unsigned char x2, unsigned char x3, unsigned char x4);
static void writeInt(unsigned int address, int value);
static int readInt(unsigned char address);
static void periodicJob(uint32 tick);
static unsigned char cover(unsigned char data, unsigned char lastTransfer);
static uint8 moveToNextFullstep();
static uint8 calibrateClosedLoop(uint8 worker0master1);

TMCSquirrelTypeDef TMCSquirrel =
{
	.SPIChannel 			= &SPI.ch1,
	.velocity				= 0,
	.periodicJob			= periodicJob,
	.writeDatagram			= writeDatagram,
	.writeInt				= writeInt,
	.readInt				= readInt,
	.cover					= cover,
	.moveToNextFullstep		= moveToNextFullstep,
	.calibrateClosedLoop	= calibrateClosedLoop,
	.moveRelativeBy 		= TMCSQUIRREL_X_TARGET,
	.rampMode 				= 0,
	.status					= 0,
	.registerAccess			=
	{
	// access
	// none :	0
	// r 	:	1
	// w 	: 	2
	// rw 	: 	3
	// r/w 	: 	7
	//	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F
		3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1, 1,    	//00..0f
		3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,		//10..1f
		3, 3, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,   	//20..2f
		3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,    	//30..3f
		3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,    	//40..4f
		3, 3, 3, 2, 3, 2, 2, 2, 2, 3, 3, 3, 2, 3, 2, 2,    	//50..5f
		2, 2, 2, 2, 2, 1, 1, 2, 2, 2, 1, 1, 2, 2, 1, 1,   	//60..6f
		2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 3, 2, 2, 1,   	//70..7f
	}
};

static void writeDatagram(unsigned char address, unsigned char x1, unsigned char x2, unsigned char x3, unsigned char x4)
{
  int value;

  TMCSquirrel.status = TMCSquirrel.SPIChannel->readWrite(address|0x80, FALSE);
  TMCSquirrel.SPIChannel->readWrite(x1, FALSE);
  TMCSquirrel.SPIChannel->readWrite(x2, FALSE);
  TMCSquirrel.SPIChannel->readWrite(x3, FALSE);
  TMCSquirrel.SPIChannel->readWrite(x4, TRUE);

  value	=	x1;
  value	<<=	8;
  value	|=	x2;
  value	<<=	8;
  value	|=	x3;
  value	<<=	8;
  value	|=	x4;


  TMCSquirrel.config->shadowRegister[address & 0x7f]=value;
}

static void writeInt(unsigned int address, int value)
{
	writeDatagram(address, 0xFF & (value>>24), 0xFF & (value>>16), 0xFF & (value>>8), 0xFF & (value>>0));
}

static int readInt(unsigned char address)
{
	int value;

	address &= 0x7f;

	if(TMCSquirrel.registerAccess[address]&1)
	{
		TMCSquirrel.SPIChannel->readWrite(address, FALSE);
		TMCSquirrel.SPIChannel->readWrite(0, FALSE);
		TMCSquirrel.SPIChannel->readWrite(0, FALSE);
		TMCSquirrel.SPIChannel->readWrite(0, FALSE);
		TMCSquirrel.SPIChannel->readWrite(0, TRUE);

		TMCSquirrel.status = TMCSquirrel.SPIChannel->readWrite(address, FALSE);
		value	=	TMCSquirrel.SPIChannel->readWrite(0, FALSE);
		value	<<=	8;
		value	|=	TMCSquirrel.SPIChannel->readWrite(0, FALSE);
		value	<<=	8;
		value	|=	TMCSquirrel.SPIChannel->readWrite(0, FALSE);
		value	<<=	8;
		value	|=	TMCSquirrel.SPIChannel->readWrite(0, TRUE);

		return value;
	}
	else	return TMCSquirrel.config->shadowRegister[address];
}

static void periodicJob(uint32 tick)
{
	static uint32 lstCLCTick;

	if(abs(lstCLCTick-tick))
	{
		calibrateClosedLoop(0);
		lstCLCTick = tick;
	}
	UNUSED(tick);
}

static unsigned char cover(unsigned char data,unsigned char lastTransfer)
{
	static uint64
		coverIn		= 0,			// read from squirrel
		coverOut	= 0;			// write 2 squirrel

	static unsigned char
		coverLength	= 0,			// data 2 be written
		out			= 0;			// return value of this function


// try to compute cover done
	//	int spiStatusSelection = TMCSquirrel.readInt(TMCSQUIRREL_SPI_STATUS_SELECTION);
	//	TMCSquirrel.writeInt(TMCSQUIRREL_SPI_STATUS_SELECTION, 1<<25);
	//  get cover done from spi status
	//	TMCSquirrel.status = 0;
	//	while(!TMCSquirrel.status) TMCSquirrel.readInt(TMCSQUIRREL_GENERAL_CONF);
	//	TMCSquirrel.writeInt(TMCSQUIRREL_SPI_STATUS_SELECTION, spiStatusSelection);
// insted of wait
	uint32 lastTick;

	/* In covering case data will be read/written in blocks. The cover function emulates a SPI readWrite function.
	 * So for every call a one byte will be send and one byte read will be returned. This means that outgoing as well as
	 * incoming data needs 2 be buffered.
	 *
	 */

	// buffering outgoing data until lastTransfer flag is high
		coverOut	<<=	8;			// shift left by one byte to make room for a new
		coverOut	|=	data;		// add new byte 2 be written
		coverLength++;				// count outgoing bytes

	// return read and buffered byte to be returned
		out			= coverIn>>56;	// output last received byte
		coverIn		<<= 8;			// shift by one byte to read this next time

	if(lastTransfer)				// last byte to be sent/buffered
	{
	// WRITE TWICE
		/* Write data 2 cover register. If there are more than 4 bytes 2 be written cover high register is used also.
		 * Than wait covering to be finished.
		 * This whole writing procedure is done twice because for calls of readwrite procedure a valid value is suspected
		 * on second read call for a whole datagram. As this procedure needs one datagram to buffer all data data valid data
		 * would only be served on third call not doing this.
		 */

		lastTick = HAL.SystemTick->tick;
		while(abs(HAL.SystemTick->tick-lastTick) > 10);	// wait 50ms before next sending

		if(coverLength>4) TMCSquirrel.writeInt(TMCSQUIRREL_COVER_HIGH, 	coverOut >> 32);
		TMCSquirrel.writeInt(TMCSQUIRREL_COVER_LOW, 	coverOut & 0xFFFFFFFF);

		lastTick = HAL.SystemTick->tick;
		while(abs(HAL.SystemTick->tick-lastTick) > 50);	// wait 50ms before next sending

		TMCSquirrel.writeInt(TMCSQUIRREL_COVER_LOW, 	coverOut & 0xFFFFFFFF);				// need 2 send again for valid access 2 start covering, cover high register is still valid




		coverOut	= 0;			// clear outgoing buffer
	// READ ONCE
		coverIn		= 0;			// clear incoming buffer

		if(coverLength>4)
		{
			coverIn |= 	TMCSquirrel.readInt(TMCSQUIRREL_COVER_DRV_HIGH);	// read byte form cover register an add byte to in buffer
			coverIn <<=	32;													// shift left to make room for low cover register
		}
		coverIn |= 	TMCSquirrel.readInt(TMCSQUIRREL_COVER_DRV_LOW);			// read byte form cover register an add byte to in buffer
		coverIn <<=	(8-coverLength)*8;										// shift left to place highest received byte most left
		coverLength=0;														// clear in counter
	}

	return out;																// return buffered read byte
}

static uint8 moveToNextFullstep()
{
	int32 value;
	int32 mscnt;
	if(readInt( TMCSQUIRREL_VACTUAL)) return 0;						// motor must be stopped
	writeInt( TMCSQUIRREL_RAMPMODE,			4);						// positioning & hold mode
	writeInt( TMCSQUIRREL_VMAX, 			10000<<8);				// low velocity

	mscnt = readInt(TMCSQUIRREL_MSCNT) & 0x3FF;						// position in microstep table
	value = mscnt & 0xFF;											// if last 8 bits are 0 its a multiple of 256
	value = 128-value;												// assuming 256�steps fullsteps are 128+n*256

	if(!value) return 1;											// fullstep position reached
	value = readInt( TMCSQUIRREL_XACTUAL) + value;					// distance to next fullstep, assume 256�steps resolution
	writeInt( TMCSQUIRREL_X_TARGET, value);							// move to next fullstep
	return 0;
}

static uint8 calibrateClosedLoop(uint8 worker0master1)
{
	static uint8 	state	= 0;
	static uint32	amax	= 0;
	static uint32	dmax	= 0;

	uint32 uvalue;


	if(worker0master1 && !state) state = 1;

	switch(state)
	{
		case 1:
			amax = readInt(TMCSQUIRREL_AMAX);
			dmax = readInt(TMCSQUIRREL_DMAX);

			writeInt( TMCSQUIRREL_RAMPMODE,			4);							// positioning & hold mode
			writeInt( TMCSQUIRREL_AMAX, 			(amax>1000) ? amax : 1000);	// acceleration
			writeInt( TMCSQUIRREL_DMAX, 			(dmax>1000) ? dmax : 1000);	// deceleration
			writeInt( TMCSQUIRREL_VMAX, 			0);							// velocity
			state=2;
		break;

		case 2:
			uvalue 	= readInt(TMCSQUIRREL_ENC_IN_CONF);
			uvalue 	&= ~(1<<24);										// clear calibration bit
			uvalue 	&= ~(3<<22);										// open loop
			writeInt(TMCSQUIRREL_ENC_IN_CONF, uvalue);
			if(moveToNextFullstep()) state=3;							// move to next fullstep, motor must be stopped, poll until finished
		break;

		case 3:
			uvalue 	= readInt(TMCSQUIRREL_ENC_IN_CONF) | (1<<24);
			writeInt(TMCSQUIRREL_ENC_IN_CONF, uvalue);					// start calibration
			state 	= 4;
		break;

		case 4:
			if(worker0master1) break;
			uvalue 	= readInt(TMCSQUIRREL_ENC_IN_CONF) & ~(1<<24);
			writeInt(TMCSQUIRREL_ENC_IN_CONF, uvalue);					// clear calibration bit

			uvalue 	= readInt(TMCSQUIRREL_ENC_IN_CONF);
			uvalue 	|= (1<<22);											// closed loop
			writeInt(TMCSQUIRREL_ENC_IN_CONF, uvalue);

			state	= 5;
		break;

		case 5:
//			if(worker0master1)	//keep to make polling possible for this function
				state = 0;
			return 1;
		break;

		default: break;
	}
	return 0;
}
