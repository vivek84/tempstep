#ifndef __TMC5062_H
	#define __TMC5062_H

	#include "board.h"
	EvalBoardTypeDef TMC5062;

#endif
