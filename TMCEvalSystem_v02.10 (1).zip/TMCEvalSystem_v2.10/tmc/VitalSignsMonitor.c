#include <stdlib.h>
#include "../hal/derivative.h"
#include "../hal/bits.h"
#include "../tmc/vitalSignsMonitor.h"
#include "../hal/HAL.h"
#include "../boards/board.h"

static void checkVitalSigns(uint32 tick);
static void checkVM();
static void heartBeat(uint32 tick);

VitalSignsMonitorTypeDef VitalSignsMonitor =
{
	.brownOut 			= 0,
	.VM					= 0,
	.heartRate 			= VSM_HARD_RATE_NORMAL,
	.checkVitalSigns 	= checkVitalSigns,
	.errorMask			= 0xFFFFFFFF,
	.busy				= 0,
	.debugMode			= 0,
	.errors 			= 0
};

#if defined(Startrampe)
	#define ADC_VM_RES 4095
#elif defined(Landungsbruecke)
	#define ADC_VM_RES 65535
#endif


static void checkVitalSigns(uint32 tick)
{
	int errors = 0;
	uint32 lastTick = 0;

	if(abs(tick-lastTick)>10)
	{
		checkVM();
		lastTick = tick;
	}

	EvalBoards.ch2.checkErrors(tick);
	EvalBoards.ch1.checkErrors(tick);
	heartBeat(tick);

	errors = VitalSignsMonitor.errors & (VSM_ERRORS_OVERVOLTAGE | VSM_ERRORS_OVERVOLTAGE_CH1 | VSM_ERRORS_OVERVOLTAGE_CH2);

	if(EvalBoards.ch1.errors 						)	errors |= VSM_ERRORS_CH1;
	if(EvalBoards.ch2.errors						) 	errors |= VSM_ERRORS_CH2;

	if(VitalSignsMonitor.busy						) 	errors |= VSM_BUSY;
	if(EvalBoards.ch1.config->isBusy				) 	errors |= VSM_BUSY | VSM_BUSY_CH1;
	if(EvalBoards.ch2.config->isBusy				) 	errors |= VSM_BUSY | VSM_BUSY_CH2;

	if(VitalSignsMonitor.brownOut 					) 	errors |= VSM_ERRORS_VM | VSM_ERRORS_BROWNOUT;
	if(VitalSignsMonitor.brownOut 		& VSM_CH1	) 	errors |= VSM_ERRORS_VM | VSM_ERRORS_BROWNOUT | VSM_ERRORS_BROWNOUT_CH1;
	if(VitalSignsMonitor.brownOut 		& VSM_CH2	) 	errors |= VSM_ERRORS_VM | VSM_ERRORS_BROWNOUT | VSM_ERRORS_BROWNOUT_CH2;

	if(VitalSignsMonitor.overVoltage 				)	errors |= VSM_ERRORS_VM | VSM_ERRORS_OVERVOLTAGE;
	if(VitalSignsMonitor.overVoltage 	& VSM_CH1	)	errors |= VSM_ERRORS_VM | VSM_ERRORS_OVERVOLTAGE | VSM_ERRORS_OVERVOLTAGE_CH1;
	if(VitalSignsMonitor.overVoltage 	& VSM_CH2	)	errors |= VSM_ERRORS_VM | VSM_ERRORS_OVERVOLTAGE | VSM_ERRORS_OVERVOLTAGE_CH2;

	VitalSignsMonitor.errors = errors & VitalSignsMonitor.errorMask;

	if(VitalSignsMonitor.errors & (VSM_ERRORS_OVERVOLTAGE | VSM_ERRORS_OVERVOLTAGE_CH1 | VSM_ERRORS_OVERVOLTAGE_CH2))
	{
		EvalBoards.driverEnable 	= 0;
		EvalBoards.ch1.enableDriver(2);
		EvalBoards.ch2.enableDriver(2);
	}

	if(!VitalSignsMonitor.debugMode)
	{
		if(VitalSignsMonitor.errors & (~(VSM_BUSY | VSM_BUSY_CH1 | VSM_BUSY_CH2))) HAL.LEDs->error.on();
		else HAL.LEDs->error.off();

		if(VitalSignsMonitor.errors & (VSM_BUSY | VSM_BUSY_CH1 | VSM_BUSY_CH2)) VitalSignsMonitor.heartRate = VSM_HARD_RATE_FAST;
		else VitalSignsMonitor.heartRate = VSM_HARD_RATE_NORMAL;
	}
}

static void checkVM()
{
	uint32 VM;
	static uint8 stable = 0;

	// 71.3V @ 3V3 with 12bit resolution(4095) => VM = 713
	VM = (unsigned int) *ADCs.VM;
	VM = (VM*713)/ADC_VM_RES;

	VitalSignsMonitor.VM 			= VM;
	VitalSignsMonitor.overVoltage	= 0;
	VitalSignsMonitor.brownOut		= 0;

	if(VM > VM_MAX_INTERACE_BOARD)	VitalSignsMonitor.overVoltage 	|= VSM_CHX;
	if(VM >	EvalBoards.ch1.VMMax)	VitalSignsMonitor.overVoltage 	|= VSM_CHX | VSM_CH1;
	if(VM >	EvalBoards.ch2.VMMax)	VitalSignsMonitor.overVoltage 	|= VSM_CHX | VSM_CH2;

	if(VM <	VM_MIN_INTERACE_BOARD)	VitalSignsMonitor.brownOut 		|= VSM_CHX;
	if(VM <	EvalBoards.ch1.VMMin)	VitalSignsMonitor.brownOut 		|= VSM_CHX | VSM_CH1;
	if(VM <	EvalBoards.ch2.VMMin)	VitalSignsMonitor.brownOut 		|= VSM_CHX | VSM_CH2;

	if(VitalSignsMonitor.brownOut)	stable = 0;
	else
	{
		if(stable < 50) stable++;
		else if(stable == 50)
		{
			stable++;
			EvalBoards.ch2.config->restore();
			EvalBoards.ch1.config->restore();
		}
	}
}

static void heartBeat(uint32 tick)
{
	static unsigned int lastTick = 0;


	if(VitalSignsMonitor.heartRate == 0) return;

	if(abs(tick-lastTick)>VitalSignsMonitor.heartRate)
	{
		LED_TOGGLE();
		lastTick=tick;
	}
}
