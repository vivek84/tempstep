#ifndef __TMCC160_H
	#define __TMCC160_H

	#include "board.h"
	EvalBoardTypeDef TMCC160;

#endif
