#ifndef __TMC5031_H
	#define __TMC5031_H

	#include "board.h"
	EvalBoardTypeDef TMC5031;

#endif
