#ifndef __TMC2130_TQFP48_H
	#define __TMC2130_TQFP48_H

	#include "board.h"
	EvalBoardTypeDef TMC2130_TQFP48;

#endif
