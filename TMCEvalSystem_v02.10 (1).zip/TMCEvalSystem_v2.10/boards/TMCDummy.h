#ifndef TMCDUMMY_H_
	#define TMCDUMMY_H_


	typedef struct
	{
		void (*init)();
		void (*deInit)();
		void (*TMCLDelegation)();
		uint8 (*reset)(void);
		uint8 (*restore)(void);
		void (*enableDriver) (uint8 disable0Enable1global2);
		void (*periodicJob) (uint32 tick);
	} EvalBoardDummyTypeDef;


	EvalBoardDummyTypeDef TMCDummy;

#endif
