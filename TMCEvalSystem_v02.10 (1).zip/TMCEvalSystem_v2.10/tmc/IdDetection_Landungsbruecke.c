/*
 * idDetection.c
 *
 *  Created on: 	24.10.2013
 *  Author: 		ernst
 *
 *  Determine the ids of connected boards by calling getId(&result) where result is a struct
 *  of IdDetectionTypeDef. result will contain the current state of the id determination(stateCh[0,1]) and
 *  the assigned ids idCh[0,1]for each board.
 *
 *  The states of id determination are:
 *	#define ID_STATE_IDLE		0			// id detection state definitions
 *	#define ID_STATE_PENDING	1			// id detection pending running
 *	#define ID_STATE_DONE		2			// id detection finished
 *	#define ID_STATE_ERROR		3			// id detection failed
 *	#define ID_STATE_NO_ANSWER	4			// id detection failed because board doesn't answer
 *	#define ID_STATE_TIMEOUT	5			// id detection failed because of timeout, board id signal went
 *											   high not low again
 *
 *  Once getId was called the determination is started. While its not finished getId will
 *  return the constant ID_STATE_PENDING. While the detection happens parallel for both channels the detection
 *  of one channel may finish earlier. The result struct will always contain the actual data so if the determination
 *  state of one channel is done the id is valid.
 *
 *  If the id detection is finished for both channels getId will return ID_STATE_DONE and the results are
 *  put into the result struct. The next call of getId will start the next id determination.
 *
 */

#include "../hal/derivative.h"
#include "../hal/bits.h"
#include "../hal/HAL.h"
#include "idDetection.h"
#include "boardAssignment.h"

static void init(void);
static void deInit();
static uint8 assign(uint32 pulse);
static uint8 detect(IdAssignmentTypeDef *out);

#define PWM_PERIOD 		5535
#define HALF_PWM_PERIOD	(PWM_PERIOD >> 1)
#define FULLCOUNTER	60000
#define STEPRANGE 80/48
#define MAXCOUNTER	65536

uint32 counter = 0, counter_ch1_1 = 0, counter_ch1_2 = 0, counter_ch2_1 = 0, counter_ch2_2 = 0;
uint32 timer_ch1_1,timer_ch1_2, timer_ch2_1,timer_ch2_2, checkID1 = 0, checkID2 = 0;

volatile uint8 idState = ID_STATE_DONE;
volatile IdAssignmentTypeDef	IdDetectionState =
{
	.ch1  =
	{
		.id 	= 0,
		.state	= ID_STATE_PENDING
	},
	.ch2 =
	{
		.id 	= 0,
		.state	= ID_STATE_PENDING
	}
};


IdDetectionTypeDef IdDetection =
{
	.init 	= init,
	.deInit = deInit,
	.detect = detect
};



void PORTB_IRQHandler(void)
{
/*
 * pin changed interrupt to detect edges of id pulse for PORTB
*/
	uint32 check = FTM2_CNT;
	if(idState == ID_STATE_PENDING) 												// try 2 get id?
	{
		bool handled = FALSE;

		// ======== CH0 ==========
		if(PORTB_ISFR & PORT_ISFR_ISF(HAL.IOs->pins->ID_CH0.bitWeight))					// detect with Pin changed
		{
			if(IdDetectionState.ch1.state	== ID_STATE_PENDING)
			{
				timer_ch1_2						= check;							// capture time on puls high 2 low edge
				counter_ch1_2					= counter;
				IdDetectionState.ch1.state		= ID_STATE_DONE;					// set id detection state for this channel to done
			}
			else
			{
				timer_ch1_1 					= check;							// capture time between id clk high and id pulse high
				counter_ch1_1					= counter;
				IdDetectionState.ch1.state		= ID_STATE_PENDING;					// set id detection state for this channel to pending
				ID_CLK_LOW();
			}
			PORTB_ISFR = PORT_ISFR_ISF(HAL.IOs->pins->ID_CH0.bitWeight);			// clear interruptflag
			handled = TRUE;
		}

		// ======== CH1 ==========
		if(PORTB_ISFR & PORT_ISFR_ISF(HAL.IOs->pins->ID_CH1.bitWeight))		// detect with Pin changed
		{
			if(IdDetectionState.ch2.state	== ID_STATE_PENDING)
			{
				timer_ch2_2						= check;							// capture time on puls high 2 low edge
				counter_ch2_2					= counter;
				IdDetectionState.ch2.state		= ID_STATE_DONE;					// set id detection state for this channel to done
			}
			else
			{
				timer_ch2_1 					= check;							// capture time between id clk high and id pulse high
				counter_ch2_1					= counter;
				IdDetectionState.ch2.state		= ID_STATE_PENDING;					// set id detection state for this channel to pending
				ID_CLK_LOW();
			}
			PORTB_ISFR = PORT_ISFR_ISF(HAL.IOs->pins->ID_CH1.bitWeight);			// clear iterruptflag
			handled = TRUE;
		}

		if (!handled)
		/*else */PORTB_ISFR = -1;
	}
	else PORTB_ISFR = -1;
}

void FTM2_IRQHandler()
{
	counter++;

	if(counter == 100)
	{
		counter = 0;
		if(idState == ID_STATE_PENDING)
		{
			if(IdDetectionState.ch1.state == ID_STATE_PENDING)		// id detection for this channel still pending?
			{
				IdDetectionState.ch1.state = ID_STATE_TIMEOUT;		// set id detection state to timeout
			}
			else if(IdDetectionState.ch1.state == ID_STATE_IDLE)	// id detection for this channel still idle?
			{
				IdDetectionState.ch1.state = ID_STATE_NO_ANSWER;	// set id detection state to no answer
			}

			if(IdDetectionState.ch2.state == ID_STATE_PENDING)		// id detection for this channel still pending?
			{
				IdDetectionState.ch2.state = ID_STATE_TIMEOUT;		// set id detection state to timeout
			}
			else if(IdDetectionState.ch2.state == ID_STATE_IDLE)	// id detection for this channel still idle?
			{
				IdDetectionState.ch2.state = ID_STATE_NO_ANSWER;	// set id detection state to no answer
			}
		}
		FTM2_SC |= FTM_SC_CLKS(0);								// stop timer
	}
	// clear timer overflow flag
	FTM2_SC &= ~FTM_SC_TOF_MASK;
}

static void init(void)
{

	// enable clock for FTM2
	SIM_SCGC3 |= SIM_SCGC3_FTM2_MASK;

    FTM2_MODE |= FTM_MODE_WPDIS_MASK | FTM_MODE_FTMEN_MASK | FTM_MODE_FAULTM_MASK;	// disable write protection, FTM spezific register are available

    FTM2_SC |= FTM_SC_CLKS(1) | FTM_SC_PS(3);	// Clock source System Clock,divided by 32 Prescaler
    											//0,66 us

    FTM2_CNTIN = PWM_PERIOD;		// timer start value 65535 - 15000 => 10ms

	FTM2_CONF |= FTM_CONF_NUMTOF(0);	// The TOF bit is set for each counter overflow

	// Edge-Aligned PWM (EPWM) mode
	FTM2_C0SC |= FTM_CnSC_MSB_MASK | FTM_CnSC_ELSB_MASK;

	// enable FTM2 Timer Overflow interrupt
	FTM2_SC |= FTM_SC_TOIE_MASK;

	// set FTM2 interrupt handler
	enable_irq(INT_FTM2-16);

/*
 * initialize timer an port change interrupts
*/
	idState		= ID_STATE_DONE;

	//====================================================
	// enable external interrupt on PortB
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

	SIM_SCGC5 |= (SIM_SCGC5_PORTB_MASK);
	PORTB_ISFR = -1;	// clear status flags

	// Configure Pin

	HAL.IOs->config->toOutput(&HAL.IOs->pins->ID_CLK);

	PORT_PCR_REG(HAL.IOs->pins->ID_CH0.portBase, HAL.IOs->pins->ID_CH0.bit)  = PORT_PCR_MUX(1) | PORT_PCR_IRQC(0x0B) | PORT_PCR_PE_MASK | 0x000000;
	PORT_PCR_REG(HAL.IOs->pins->ID_CH1.portBase, HAL.IOs->pins->ID_CH1.bit)  = PORT_PCR_MUX(1) | PORT_PCR_IRQC(0x0B) | PORT_PCR_PE_MASK | 0x000000;

	PORTB_ISFR = -1;	// clear status flags
	enable_irq(INT_PORTB-16);
}


static void deInit()
{
	disable_irq(INT_FTM2-16);
	FTM2_SC |= FTM_SC_CLKS(0);
	FTM2_SC &= ~FTM_SC_TOF_MASK;

	disable_irq(INT_PORTB-16);
	PORTB_ISFR = -1;
}

static uint8 assign(uint32 pulse)
/*
 * returns id assigned to given pulse length in 0.1us
 *
 *	arguments:
 *		pulse:
 *			pulse length in 0.166us
 *		returns:
 *			assigned id or 0 on error
 */
{
	if(pulse < 5			) return 	0	;	// error
	else if(pulse < 110		) return 	1	;
	else if(pulse < 135		) return 	2	;
	else if(pulse < 165		) return 	3	;
	else if(pulse < 200		) return 	4	;
	else if(pulse < 245		) return 	5	;
	else if(pulse <	300		) return	6	;
	else if(pulse <	360		) return	7	;
	else if(pulse <	430		) return	8	;
	else if(pulse <	515		) return	9	;
	else if(pulse <	620		) return	10	;
	else if(pulse <	750		) return	11	;
	else if(pulse <	910		) return	12	;
	else if(pulse <	1100	) return	13	;
	else if(pulse <	1350	) return	14	;
	else if(pulse <	1650	) return	15	;
	else if(pulse <	2000	) return	16	;
	else if(pulse <	2450	) return	17	;
	else if(pulse <	3000	) return	18	;
	else if(pulse <	3600	) return	19	;
	else if(pulse <	4300	) return	20	;
	else if(pulse <	5150	) return	21	;
	else if(pulse <	6200	) return	22	;
	else if(pulse <	7500	) return	23	;
	else if(pulse <	9100	) return	24	;
	else if(pulse <	11000	) return	25	;
	else if(pulse <	13500	) return	26	;
	else if(pulse <	16500	) return	27	;
	else if(pulse <	20000	) return	28	;
	else if(pulse <	24500	) return	29	;
	else if(pulse <	30000	) return	30	;
	else if(pulse <	36000	) return	31	;
	else if(pulse <	43000	) return	32	;
	else if(pulse <	51500	) return	33	;
	else if(pulse <	62000	) return	34	;
	else if(pulse <	75000	) return	35	;
	else if(pulse <	91000	) return	36	;


	return 0;									// error
}

static uint8 detect(IdAssignmentTypeDef *out)
/*
 * start of id determination or request of its result
 *
 *	arguments:
 *		out:
 *			reference to IdDetectionTypeDef to gain results
 *	returns:
 *		state of id determination: pending
 */
{
	if(idState == ID_STATE_DONE)
	{
		FTM2_SC |= FTM_SC_CLKS(0);									// stop timer
		FTM2_CNTIN = PWM_PERIOD;									// clear counter
		idState 					= ID_STATE_PENDING;				// set id detection state to pending
		IdDetectionState.ch1.state 	= ID_STATE_IDLE;				// set id detection state for this channel to idle
		IdDetectionState.ch2.state	= ID_STATE_IDLE;				// set id detection state for this channel to idle
		FTM2_SC |= FTM_SC_CLKS(1);									// start timer
		ID_CLK_HIGH();												// set id clk to high
	}
	else
	{
		if
		( 		   (IdDetectionState.ch1.state != ID_STATE_IDLE)
				&& (IdDetectionState.ch2.state != ID_STATE_IDLE)
				&& (IdDetectionState.ch1.state != ID_STATE_PENDING)
				&& (IdDetectionState.ch2.state != ID_STATE_PENDING)
		)
		{

			idState = ID_STATE_DONE;								// set id detection state to done
			ID_CLK_LOW();											// set id clock 2 low
		}

		out->ch1.state 	= IdDetectionState.ch1.state;				// assign id detection state for this channel

		if(IdDetectionState.ch1.state == ID_STATE_DONE)				// if id detection for this channel is finished successfull
		{
			// Erster Z�hler Wert, gewichtet mit der Anzahl der Z�hler�berl�ufe			Zweiter Z�hlerwert
			// STEPRANGE => Aufl�sung eines einzelnen Z�hlschrittes
			// Anpassung an die Bestimmung der Id mit 10^7
			//
			//    Prescaler ( 8 )			80
			//  ----------------- * 10^7 = -----
			//	Systemtakt(48Mhz)			48

			checkID1 = ( ((timer_ch1_2 + (counter_ch1_2*FULLCOUNTER)) - (timer_ch1_1 + (counter_ch1_1*FULLCOUNTER))) * STEPRANGE );			// assign id
			out->ch1.id = assign(checkID1);							// assign id
			if(!out->ch1.id)	out->ch1.state = ID_STATE_ERROR;	// if assignment failed set id detection state for this channel 2 error
		}
		else out->ch1.id = 0;

		out->ch2.state 	= IdDetectionState.ch2.state;				// assign id detection state for this channel

		if(IdDetectionState.ch2.state == ID_STATE_DONE)				// if id detection for this channel is finished successfull
		{
			checkID2 = ( ((timer_ch2_2 + (counter_ch2_2*FULLCOUNTER)) - (timer_ch2_1 + (counter_ch2_1*FULLCOUNTER))) * STEPRANGE );			// assign id
			out->ch2.id = assign(checkID2);							// assign id
			if(!out->ch2.id)	out->ch2.state = ID_STATE_ERROR;	// if assignment failed set id detection state for this channel 2 error
		}
		else out->ch2.id = 0;

		if((IdDetectionState.ch2.state == ID_STATE_DONE) && (IdDetectionState.ch2.state == ID_STATE_DONE))
		{
			FTM2_SC |= FTM_SC_CLKS(0);								// stop timer
		}

	}
	return idState;
}






///*
// * idDetection.c
// *
// *  Created on: 	24.10.2013
// *  Author: 		ernst
// *
// *  Determine the ids of connected boards by calling getId(&result) where result is a struct
// *  of IdDetectionTypeDef. result will contain the current state of the id determination(stateCh[0,1]) and
// *  the assigned ids idCh[0,1]for each board.
// *
// *  The states of id determination are:
// *	#define ID_STATE_IDLE		0			// id detection state definitions
// *	#define ID_STATE_PENDING	1			// id detection pending running
// *	#define ID_STATE_DONE		2			// id detection finished
// *	#define ID_STATE_ERROR		3			// id detection failed
// *	#define ID_STATE_NO_ANSWER	4			// id detection failed because board doesn't answer
// *	#define ID_STATE_TIMEOUT	5			// id detection failed because of timeout, board id signal went
// *											   high not low again
// *
// *  Once getId was called the determination is started. While its not finished getId will
// *  return the constant ID_STATE_PENDING. While the detection happens parallel for both channels the detection
// *  of one channel may finish earlier. The result struct will always contain the actual data so if the determination
// *  state of one channel is done the id is valid.
// *
// *  If the id detection is finished for both channels getId will return ID_STATE_DONE and the results are
// *  put into the result struct. The next call of getId will start the next id determination.
// *
// */
//
//#include "../hal/derivative.h"
//#include "../hal/bits.h"
//#include "../hal/HAL.h"
//#include "idDetection.h"
//#include "boardAssignment.h"
//
//static void init(void);
//static uint8 assign(uint32 pulse);
//static uint8 detect(IdAssignmentTypeDef *out);
//static void deInit();
//
//#define PWM_PERIOD 		5535		//
//#define HALF_PWM_PERIOD	(PWM_PERIOD >> 1)
//#define FULLCOUNTER	60000
//#define STEPRANGE 1.6
//#define MAXCOUNTER	65536
//
//uint32 counter = 0, counter_ch1_1 = 0, counter_ch1_2 = 0, counter_ch2_1 = 0, counter_ch2_2 = 0;
//uint32 timer_ch1_1,timer_ch1_2, timer_ch2_1,timer_ch2_2, checkID1 = 0, checkID2 = 0;
//
//volatile uint8 idState = ID_STATE_DONE;
//volatile IdAssignmentTypeDef	IdDetectionState =
//{
//		.ch1  =
//		{
//			.id 	= 0,
//			.state	= ID_STATE_PENDING
//		},
//		.ch2 =
//		{
//			.id 	= 0,
//			.state	= ID_STATE_PENDING
//		}
//};
//
//
//IdDetectionTypeDef IdDetection =
//{
//	.init 	= init,
//	.detect = detect,
//	.deInit = deInit
//};
//
//void PORTB_IRQHandler(void)
//{
///*
// * pin changed interrupt to detect edges of id pulse for this channel
//*/
//
//	if(idState == ID_STATE_PENDING) 							// try 2 get id?
//	{
//		// ======== CH0 ==========
//		if(HAL.IOs->config->isHigh(&HAL.IOs->pins->ID_CH0))									// id pulse high?
//		{
//			timer_ch1_1 					= FTM2_CNT;			// capture time between id clk high and id pulse high
//			counter_ch1_1					= counter;
//			IdDetectionState.ch1.state		= ID_STATE_PENDING;	// set id detection state for this channel to pending
//			ID_CLK_LOW();
//			PORTB_ISFR = PORT_ISFR_ISF((-1 & ~HAL.IOs->pins->ID_CH1.bit));
//		}
//		else if(IdDetectionState.ch1.state	== ID_STATE_PENDING)
//		{
//			timer_ch1_2						= FTM2_CNT;			// capture time on puls high 2 low edge
//			counter_ch1_2					= counter;
//			IdDetectionState.ch1.state		= ID_STATE_DONE;	// set id detection state for this channel to done
//			PORTB_ISFR = PORT_ISFR_ISF((-1 & ~HAL.IOs->pins->ID_CH1.bit));
//		}
//
//		// ======== CH1 ==========
//		if(HAL.IOs->config->isHigh(&HAL.IOs->pins->ID_CH1))									// id pulse high?
//		{
//			timer_ch2_1 					= FTM2_CNT;			// capture time between id clk high and id pulse high
//			counter_ch2_1					= counter;
//			IdDetectionState.ch2.state		= ID_STATE_PENDING;	// set id detection state for this channel to pending
//			ID_CLK_LOW();
//			PORTB_ISFR = PORT_ISFR_ISF((-1 & ~HAL.IOs->pins->ID_CH0.bit));
//		}
//		else if(IdDetectionState.ch2.state	== ID_STATE_PENDING)
//		{
//			timer_ch2_2						= FTM2_CNT;			// capture time on puls high 2 low edge
//			counter_ch2_2					= counter;
//			IdDetectionState.ch2.state		= ID_STATE_DONE;	// set id detection state for this channel to done
//			PORTB_ISFR = PORT_ISFR_ISF((-1 & ~HAL.IOs->pins->ID_CH0.bit));
//		}
//	}
//	else PORTB_ISFR = -1;
//}
//
//void FTM2_IRQHandler()
//{
//	counter++;
//
//	if(counter == 100)
//	{
//	counter = 0;
//		if(idState == ID_STATE_PENDING)
//		{
//		if(IdDetectionState.ch1.state == ID_STATE_PENDING)		// id detection for this channel still pending?
//		{
//			IdDetectionState.ch1.state = ID_STATE_TIMEOUT;		// set id detection state to timeout
//		}
//		else if(IdDetectionState.ch1.state == ID_STATE_IDLE)	// id detection for this channel still idle?
//		{
//			IdDetectionState.ch1.state = ID_STATE_NO_ANSWER;	// set id detection state to no answer
//		}
//
//		if(IdDetectionState.ch2.state == ID_STATE_PENDING)		// id detection for this channel still pending?
//		{
//			IdDetectionState.ch2.state = ID_STATE_TIMEOUT;		// set id detection state to timeout
//		}
//		else if(IdDetectionState.ch2.state == ID_STATE_IDLE)	// id detection for this channel still idle?
//		{
//			IdDetectionState.ch2.state = ID_STATE_NO_ANSWER;	// set id detection state to no answer
//		}
//		}
//		FTM2_SC |= FTM_SC_CLKS(0);									// stop timer
//	}
//	// clear timer overflow flag
//	FTM2_SC &= ~FTM_SC_TOF_MASK;
//}
//
//static void init(void)
//{
//
//	// enable clock for FTM2
//	SIM_SCGC3 |= SIM_SCGC3_FTM2_MASK;
//
//    FTM2_MODE |= FTM_MODE_WPDIS_MASK | FTM_MODE_FTMEN_MASK | FTM_MODE_FAULTM_MASK;	// disable write protection, FTM spezific register are available
//
//    FTM2_SC |= FTM_SC_CLKS(1) | FTM_SC_PS(3);	// Clock source System Clock,divided by 32 Prescaler
//    											//0,66 us
//
//    FTM2_CNTIN = PWM_PERIOD;		// timer start value 65535 - 15000 => 10ms
//
//	FTM2_CONF |= FTM_CONF_NUMTOF(0);	// The TOF bit is set for each counter overflow
//
//	// Edge-Aligned PWM (EPWM) mode
//	FTM2_C0SC |= FTM_CnSC_MSB_MASK | FTM_CnSC_ELSB_MASK;
//
//	// enable FTM2 Timer Overflow interrupt
//	FTM2_SC |= FTM_SC_TOIE_MASK;
//
//	// set FTM2 interrupt handler
//	enable_irq(INT_FTM2-16);
//
///*
// * initialize timer an port change interrupts
//*/
//	idState		= ID_STATE_DONE;
//
//	//====================================================
//	// enable external interrupt on PortB
//	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
//
//	SIM_SCGC5 |= (SIM_SCGC5_PORTB_MASK);
//	PORTB_ISFR = -1;	// clear status flags
//
//	// Configure Pin
//	PORT_PCR_REG(HAL.IOs->pins->ID_CH0.portBase, HAL.IOs->pins->ID_CH0.bit)  = PORT_PCR_MUX(1) | PORT_PCR_IRQC(0x0B) | PORT_PCR_PE_MASK | 0x000000;
//	PORT_PCR_REG(HAL.IOs->pins->ID_CH1.portBase, HAL.IOs->pins->ID_CH1.bit)  = PORT_PCR_MUX(1) | PORT_PCR_IRQC(0x0B) | PORT_PCR_PE_MASK | 0x000000;
//	// GPIO_Mode, Interrupt on either edge, Pull enable, Pulldown
//
//	PORTB_ISFR = -1;	// clear status flags
//	enable_irq(INT_PORTB-16);
//}
//
//static void deInit()
//{
//	disable_irq(INT_FTM2-16);
//	FTM2_SC |= FTM_SC_CLKS(0);
//	FTM2_SC &= ~FTM_SC_TOF_MASK;
//
//	disable_irq(INT_PORTB-16);
//	PORTB_ISFR = -1;
//}
//
//static uint8 assign(uint32 pulse)
///*
// * returns id assigned to given pulse length in 0.1us
// *
// *	arguments:
// *		pulse:
// *			pulse length in 0.1us
// *		returns:
// *			assigned id or 0 on error
// */
//{
//	if(pulse < 5			) return 	0	;	// error
//	else if(pulse < 110		) return 	1	;
//	else if(pulse < 135		) return 	2	;
//	else if(pulse < 165		) return 	3	;
//	else if(pulse < 200		) return 	4	;
//	else if(pulse < 245		) return 	5	;
//	else if(pulse <	300		) return	6	;
//	else if(pulse <	360		) return	7	;
//	else if(pulse <	430		) return	8	;
//	else if(pulse <	515		) return	9	;
//	else if(pulse <	620		) return	10	;
//	else if(pulse <	750		) return	11	;
//	else if(pulse <	910		) return	12	;
//	else if(pulse <	1100	) return	13	;
//	else if(pulse <	1350	) return	14	;
//	else if(pulse <	1650	) return	15	;
//	else if(pulse <	2000	) return	16	;
//	else if(pulse <	2450	) return	17	;
//	else if(pulse <	3000	) return	18	;
//	else if(pulse <	3600	) return	19	;
//	else if(pulse <	4300	) return	20	;
//	else if(pulse <	5150	) return	21	;
//	else if(pulse <	6200	) return	22	;
//	else if(pulse <	7500	) return	23	;
//	else if(pulse <	9100	) return	24	;
//	else if(pulse <	11000	) return	25	;
//	else if(pulse <	13500	) return	26	;
//	else if(pulse <	16500	) return	27	;
//	else if(pulse <	20000	) return	28	;
//	else if(pulse <	24500	) return	29	;
//	else if(pulse <	30000	) return	30	;
//	else if(pulse <	36000	) return	31	;
//	else if(pulse <	43000	) return	32	;
//	else if(pulse <	51500	) return	33	;
//	else if(pulse <	62000	) return	34	;
//	else if(pulse <	75000	) return	35	;
//	else if(pulse <	91000	) return	36	;
//
//
//	return 0;									// error
//}
//
//static uint8 detect(IdAssignmentTypeDef *out)
///*
// * start of id determination or request of its result
// *
// *	arguments:
// *		out:
// *			reference to IdDetectionTypeDef to gain results
// *	returns:
// *		state of id determination: pending
// */
//{
//	if(idState == ID_STATE_DONE)
//	{
//		FTM2_SC |= FTM_SC_CLKS(0);									// stop timer
//		FTM2_CNTIN = PWM_PERIOD;							// clear counter
//		idState 					= ID_STATE_PENDING;				// set id detection state to pending
//		IdDetectionState.ch1.state 	= ID_STATE_IDLE;				// set id detection state for this channel to idle
//		IdDetectionState.ch2.state	= ID_STATE_IDLE;				// set id detection state for this channel to idle
//		FTM2_SC |= FTM_SC_CLKS(1);									// start timer
//		ID_CLK_HIGH();											// set id clk to high
//	}
//	else
//	{
//		if
//		( 		   (IdDetectionState.ch1.state != ID_STATE_IDLE)
//				&& (IdDetectionState.ch2.state != ID_STATE_IDLE)
//				&& (IdDetectionState.ch1.state != ID_STATE_PENDING)
//				&& (IdDetectionState.ch2.state != ID_STATE_PENDING)
//		)
//		{
//
//			idState = ID_STATE_DONE;								// set id detection state to done
//			ID_CLK_LOW();		// set id clock 2 low
//		}
//
//		out->ch1.state 	= IdDetectionState.ch1.state;				// assign id detection state for this channel
//
//		if(IdDetectionState.ch1.state == ID_STATE_DONE)				// if id detection for this channel is finished successfull
//		{
//			checkID1 = (((((MAXCOUNTER - timer_ch1_1))+(counter_ch1_1*FULLCOUNTER)) - (((MAXCOUNTER - timer_ch1_2))+(counter_ch1_2*FULLCOUNTER))) * STEPRANGE );			// assign id
//			out->ch1.id = assign(checkID1);			// assign id
//			if(!out->ch1.id)	out->ch1.state = ID_STATE_ERROR;	// if assignment failed set id detection state for this channel 2 error
//		}
//		else out->ch1.id = 0;
//
//		out->ch2.state 	= IdDetectionState.ch2.state;				// assign id detection state for this channel
//
//		if(IdDetectionState.ch2.state == ID_STATE_DONE)				// if id detection for this channel is finished successfull
//		{
//			checkID2 = (((((MAXCOUNTER - timer_ch2_1))+(counter_ch2_1*FULLCOUNTER))-(((MAXCOUNTER - timer_ch2_2))+(counter_ch2_2*FULLCOUNTER)))*STEPRANGE);			// assign id
//			out->ch2.id = assign(checkID2);			// assign id
//			if(!out->ch2.id)	out->ch2.state = ID_STATE_ERROR;	// if assignment failed set id detection state for this channel 2 error
//		}
//		else out->ch2.id = 0;
//
//		if((IdDetectionState.ch2.state == ID_STATE_DONE) && (IdDetectionState.ch2.state == ID_STATE_DONE))
//		{
//			FTM2_SC |= FTM_SC_CLKS(0);									// stop timer
//		}
//	}
//	return idState;
//}
