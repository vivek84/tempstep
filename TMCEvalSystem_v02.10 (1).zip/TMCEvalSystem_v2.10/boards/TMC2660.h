#ifndef __TMC2660_H
	#define __TMC2660_H

	#include "board.h"
	EvalBoardTypeDef TMC2660;

#endif
