#include <stdlib.h>

#include "../hal/derivative.h"
#include "../hal/typedefs.h"
#include "TMCL.h"
#include "idDetection.h"
#include "vitalSignsMonitor.h"
#include "main.h"

#include "../tmc/boardAssignment.h"
#include "../boards/TMCDummy.h"
#include "../boards/board.h"
#include "../tmc/stepDir.h"

static uint32 mode = 0;

static void GetVersion(void);
static void GetInput(void);
static void SoftwareReset(void);
static void ExecuteActualCommand(void);
static void InitTMCL(void);
static void ProcessTMCL(void);
static void SetGlobalParameter(void);
static void GetGlobalParameter(void);

static void boardAssignment(void);
static void boardsErrors(void);
static void boardReset(void);
static void boardsMeasuredSpeed(void);

static void delegate(void (*highPriority)(void), void (*lowPriority)(void));
static uint8 getIds(void);


static void rx(RXTXTypeDef *RXTX);
static void tx(RXTXTypeDef *RXTX);
static void setDriversEnable(void);

RXTXTypeDef	*TMCLCurrntInterface;
RXTXTypeDef	interfaces[3];

static TTMCLCommand ActualCommand;
static TTMCLReply ActualReply;

#if defined(Landungsbruecke)
	extern uint32 BLMagic;
#endif

TMCLTypeDef TMCL =
{
	.command			= &ActualCommand,
	.reply				= &ActualReply,
	.init				= InitTMCL,
	.process			= ProcessTMCL,
	.interfaces			= interfaces,
	.execute			= ExecuteActualCommand,
	.numberOfInterfaces	= 0,
	.resetRequest		= FALSE
};

static void delegate(void (*highPriority)(void), void (*lowPriority)(void))
{
	ActualReply.Status = REPLY_OK;

	highPriority();
	if(ActualReply.Status != REPLY_OK)
	{
		ActualReply.Status = REPLY_OK;
		lowPriority();
	}
}

static void ExecuteActualCommand(void)
{
	ActualReply.Opcode		= ActualCommand.Opcode;
	ActualReply.Status		= REPLY_OK;
	ActualReply.Value.Int32	= ActualCommand.Value.Int32;

	if(ActualCommand.Error == CHECKSUM)
	{
		ActualReply.Value.Int32 = 0;
		ActualReply.Status		= REPLY_CHKERR;
		return;
	}

	switch(ActualCommand.Opcode)
	{
		case TMCL_ROR:				delegate(	EvalBoards.ch1.rotateRight, 		EvalBoards.ch2.rotateRight 		);	break;
		case TMCL_ROL:				delegate(	EvalBoards.ch1.rotateLeft,			EvalBoards.ch2.rotateLeft		);	break;
		case TMCL_MST:				delegate(	EvalBoards.ch1.motorStop, 			EvalBoards.ch2.motorStop		);	break;
		case TMCL_MVP:				delegate(	EvalBoards.ch1.moveToPosition,		EvalBoards.ch2.moveToPosition	);	break;
		case TMCL_SAP:				delegate(	EvalBoards.ch1.setAxisParameter, 	EvalBoards.ch2.setAxisParameter	);	break;
		case TMCL_GAP:				delegate(	EvalBoards.ch1.getAxisParameter,	EvalBoards.ch2.getAxisParameter	);	break;

    	case TMCL_STAP:				delegate(EvalBoards.ch1.storeAxisParameter,	EvalBoards.ch2.storeAxisParameter); 	break;
    	case TMCL_RSAP:				delegate(EvalBoards.ch1.restoreAxisParameter, EvalBoards.ch2.restoreAxisParameter); break;

		case TMCL_SGP:				SetGlobalParameter();																break;
		case TMCL_GGP:				GetGlobalParameter();																break;

		case TMCL_GIO:				GetInput();																			break;

		case TMCL_UF0:				setDriversEnable();																	break;
		case TMCL_UF4:				delegate(	EvalBoards.ch1.getMeasuredSpeed, 	EvalBoards.ch2.getMeasuredSpeed	);	break;
		case TMCL_UF5:				delegate(	EvalBoards.ch1.writeRegister, 		EvalBoards.ch1.writeRegister	);	break;
		case TMCL_UF6:				delegate(	EvalBoards.ch1.readRegister, 		EvalBoards.ch1.readRegister		);	break;
		case TMCL_GetVersion:		GetVersion();																		break;

		case TMCL_GetIds:			boardAssignment();																	break;

		case 144:					EvalBoards.ch1.userFunction();														break;	// user function for motionController board
		case 145:					EvalBoards.ch2.userFunction();														break;	// user function for driver board

		case 146:					EvalBoards.ch1.writeRegister();														break; // register write access for motionController board
		case 147:					EvalBoards.ch2.writeRegister();														break;	// register write access for driver board

		case 148:					EvalBoards.ch1.readRegister();														break;	// register read access for motionController board
		case 149:					EvalBoards.ch2.readRegister();														break;	// register read access for driver board

		case 150:					boardsMeasuredSpeed();																break;	// measured speed from motionController board or driver board depending on type
		case 151:					boardsErrors();																		break;	// errors of motionController board or driver board depending on type
		case 152:					boardReset();																		break;	// reset of motionController board or driver board depending on type

		case TMCL_Boot:
			if(ActualCommand.Type			!= 0x81) 	break;
			if(ActualCommand.Motor			!= 0x92) 	break;
			if(ActualCommand.Value.Byte[3]	!= 0xa3) 	break;
			if(ActualCommand.Value.Byte[2]	!= 0xb4) 	break;
			if(ActualCommand.Value.Byte[1]	!= 0xc5) 	break;
			if(ActualCommand.Value.Byte[0]	!= 0xd6) 	break;
			Boot();
		break;

		case TMCL_SoftwareReset:	SoftwareReset();																	break;

		default:					ActualReply.Status=REPLY_INVALID_CMD;												break;
	}
}

static void InitTMCL(void)
{
	ActualCommand.Error 	= NODATA;
	interfaces[0] 			= *HAL.USB;
	interfaces[1] 			= *HAL.RS232;
	TMCL.numberOfInterfaces = 2;
}

static void ProcessTMCL(void)
{
	int	i;

	if(ActualCommand.Error != NODATA) 	tx(TMCL.currentInterface);

	if(TMCL.resetRequest) HAL.reset(TRUE);

	ActualReply.IsSpecial = 0;

	for(i=0; i< TMCL.numberOfInterfaces; i++)
	{
		rx(&TMCL.interfaces[i]);
		if(TMCL.command->Error != NODATA)
		{
			TMCL.currentInterface = &TMCL.interfaces[i];
			ExecuteActualCommand();
			return;
		}
	}
}

static void tx(RXTXTypeDef *RXTX)
{
	unsigned char
		checkSum = 0, i;

	char
		reply[9];

	if(ActualReply.IsSpecial)
	{
		for(i=0; i<9; i++)	reply[i] = 0|TMCL.reply->Sepecial[i];
	}
	else
	{
		checkSum	+= SERIAL_HOST_ADDRESS;
		checkSum	+= SERIAL_MODULE_ADDRESS;
		checkSum	+= ActualReply.Status;
		checkSum	+= ActualReply.Opcode;
		checkSum	+= ActualReply.Value.Byte[3];
		checkSum	+= ActualReply.Value.Byte[2];
		checkSum	+= ActualReply.Value.Byte[1];
		checkSum	+= ActualReply.Value.Byte[0];

		reply[0]	= SERIAL_HOST_ADDRESS;
		reply[1]	= SERIAL_MODULE_ADDRESS;
		reply[2]	= ActualReply.Status;
		reply[3]	= ActualReply.Opcode;
		reply[4]	= ActualReply.Value.Byte[3];
		reply[5]	= ActualReply.Value.Byte[2];
		reply[6]	= ActualReply.Value.Byte[1];
		reply[7]	= ActualReply.Value.Byte[0];
		reply[8]	= checkSum;
	}
	RXTX->txN(reply, 9);
}

static void rx(RXTXTypeDef *RXTX)
{
	unsigned char
		checkSum = 0,
		i;

	char
		cmd[9];

	ActualCommand.Error		= NODATA;

	if(!RXTX->rxN(cmd,9)) return;


	for(i=0; i<8; i++) checkSum += cmd[i];

	if(checkSum != cmd[8])
	{
		return;
		ActualCommand.Error	= CHECKSUM;
	}

	ActualCommand.Opcode		= cmd[1];
	ActualCommand.Type			= cmd[2];
	ActualCommand.Motor			= cmd[3];
	ActualCommand.Value.Byte[3]	= cmd[4];
	ActualCommand.Value.Byte[2]	= cmd[5];
	ActualCommand.Value.Byte[1]	= cmd[6];
	ActualCommand.Value.Byte[0]	= cmd[7];
	ActualCommand.Error			= NONE;
}

static void GetVersion(void)
{
  uint32 i;

	if(ActualCommand.Type==0)
	{
		ActualReply.IsSpecial	= 1;
		ActualReply.Sepecial[0]	= SERIAL_HOST_ADDRESS;

		for(i=0; i<8; i++)  ActualReply.Sepecial[i+1] = VersionString[i];
	}
	else if(ActualCommand.Type==1)
	{
		ActualReply.Value.Byte[3]	= 0;
		ActualReply.Value.Byte[2]	= 0;

		i = ((uint8) VersionString[5] - (uint8) 0x30);
		i *= 10;
		i += (uint8) VersionString[6] - (uint8) 0x30;
		ActualReply.Value.Byte[1]	=i;

		i = ((uint8) VersionString[7] - (uint8) 0x30);
		i *= 10;
		i += (uint8) VersionString[8] - (uint8) 0x30;
		ActualReply.Value.Byte[0]	=i;

	}
}

static uint8 getIds(void)
{
	IdAssignmentTypeDef 	ids;
	uint8 state = IdDetection.detect(&ids);

	if(state == ID_STATE_DONE)
	{
		ActualReply.Status		= REPLY_OK;

        if(ids.ch1.state !=  ID_STATE_DONE) ids.ch1.id = 0;
        if(ids.ch2.state !=  ID_STATE_DONE) ids.ch2.id = 0;

		ActualReply.Value.Int32	= (uint32)
		(
			  (ids.ch1.id 				)
			| (ids.ch1.state 	<< 8	)
			| (ids.ch2.id 		<< 16	)
			| (ids.ch2.state 	<< 24	)
		);

		BoardAssignment.assign(&ids);
	}
	else ActualReply.Status		= REPLY_DELAYED;
	return state;
}

void Boot(void)
{
	uint32 delay;

	EvalBoards.driverEnable = 0;
	EvalBoards.ch1.enableDriver(2);
	EvalBoards.ch2.enableDriver(2);
	EvalBoards.ch1.deInit();
	EvalBoards.ch2.deInit();

	HAL.USB->deInit();
	delay	= SystemTick.tick;
	while(abs(SystemTick.tick-delay)<500) RESET_WATCHDOG();
	HAL.Timer->deInit();
	HAL.RS232->deInit();
	HAL.Wireless->deInit();
	HAL.ADCs->deInit();
	StepDir.deInit();
	IdDetection.deInit();

	HAL.NVIC_DeInit();

#if defined(Startrampe)
	__disable_irq();
	TIM_DeInit(TIM1);
	TIM_DeInit(TIM2);
	TIM_DeInit(TIM5);
	DMA_Cmd(DMA2_Stream0, DISABLE);
	DMA_DeInit(DMA2_Stream0);
	ADC_DeInit();
	EXTI_DeInit();
	SysTick->CTRL=0;
#elif defined(Landungsbruecke)
    BLMagic=0x12345678;
#endif

	HAL.reset(FALSE);
}

static void GetInput(void)
{
	switch(ActualCommand.Type)
	{
		case 0: ActualReply.Value.Int32 = *ADCs.AIN0; 				break;
		case 1: ActualReply.Value.Int32 = *ADCs.AIN1; 				break;
		case 2: ActualReply.Value.Int32 = *ADCs.AIN2; 				break;
		case 3: ActualReply.Value.Int32 = *ADCs.DIO4; 				break;
		case 4: ActualReply.Value.Int32 = *ADCs.DIO5; 				break;
		case 5: ActualReply.Value.Int32 = VitalSignsMonitor.VM; 	break;
	}
}

static void boardAssignment(void)
{
	IdAssignmentTypeDef ids_buff, ids;

	uint8 testOnly = 0;

	ids.ch1.id 		= (TMCL.command->Value.Int32 >> 0)	& 0xFF;
	ids.ch1.state 	= (TMCL.command->Value.Int32 >> 8)	& 0xFF;
	ids.ch2.id 		= (TMCL.command->Value.Int32 >> 16)	& 0xFF;
	ids.ch2.state	= (TMCL.command->Value.Int32 >> 24)	& 0xFF;

	switch(TMCL.command->Type)
	{
		case 0:	// auto detect and assign
			getIds();
			return;
		break;

		case 1:	// id for channel 2 not changed, reset maybe
			ids.ch2.id 		= EvalBoards.ch2.id;
			ids.ch2.state 	= 0;
		break;

		case 2:	// id for channel 1 not changed, reset maybe
			ids.ch1.id 		= EvalBoards.ch1.id;
			ids.ch1.state 	= 0;
		break;

		case 3: // id for both channels

		break;

		case 4:	// test if ids are in firmware
			testOnly = 1;
			if(TMCL.reply->Value.Int32 == 0)
			{
				ids.ch1.id = EvalBoards.ch1.id;
				ids.ch2.id = EvalBoards.ch2.id;
			}
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
			return;
		break;
	}

	ids_buff.ch1.id 		= ids.ch1.id;
	ids_buff.ch1.state 		= 2;
	ids_buff.ch2.id 		= ids.ch2.id;
	ids_buff.ch2.state		= 2;


	if(!testOnly) TMCL.reply->Value.Int32 = BoardAssignment.assign(&ids_buff);
	else TMCL.reply->Value.Int32 = BoardAssignment.supported(&ids_buff);

	if(ids.ch1.state) EvalBoards.ch1.config->reset();
	if(ids.ch2.state) EvalBoards.ch2.config->reset();
}

static void boardsErrors(void)
{
	switch(TMCL.command->Type)
	{
		case 0:		TMCL.reply->Value.Int32 = EvalBoards.ch1.errors;				break;
		case 1:		TMCL.reply->Value.Int32 = EvalBoards.ch2.errors;				break;
		default:	TMCL.reply->Status = REPLY_WRONG_TYPE;	break;
	}
}

static void boardReset(void)
{
	switch(TMCL.command->Type)
	{
		case 0:		if(!EvalBoards.ch1.config->reset()) TMCL.reply->Status = REPLY_WRITE_PROTECTED;	break;
		case 1:		if(!EvalBoards.ch2.config->reset()) TMCL.reply->Status = REPLY_WRITE_PROTECTED;	break;
		case 2:
			if(!EvalBoards.ch1.config->reset()) TMCL.reply->Status = REPLY_WRITE_PROTECTED;
			if(!EvalBoards.ch2.config->reset()) TMCL.reply->Status = REPLY_WRITE_PROTECTED;
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void boardsMeasuredSpeed(void)
{
	switch(TMCL.command->Type)
	{
		case 0:		EvalBoards.ch1.getMeasuredSpeed();		break;
		case 1:		EvalBoards.ch2.getMeasuredSpeed();		break;
		default:	TMCL.reply->Status = REPLY_WRONG_TYPE;	break;
	}
}

static void setDriversEnable()
{
	if((TMCL.command->Value.Int32 != 1) && (TMCL.command->Value.Int32 != 0))
	{
		TMCL.reply->Status = REPLY_WRONG_TYPE;
		return;
	}

	VitalSignsMonitor.errors &= ~(VSM_ERRORS_OVERVOLTAGE | VSM_ERRORS_OVERVOLTAGE_CH1 | VSM_ERRORS_OVERVOLTAGE_CH2);

	EvalBoards.driverEnable = (TMCL.command->Value.Int32) ? 1 : 0;
	EvalBoards.ch1.enableDriver(2);
	EvalBoards.ch2.enableDriver(2);
}

static void SetGlobalParameter(void)
{
	switch(TMCL.command->Type)
	{
		case 1:
			VitalSignsMonitor.errorMask = TMCL.command->Value.Int32;
		break;

		case 2:
			setDriversEnable();
		break;

		case 3:
			switch(TMCL.command->Value.Int32)
			{
				case 0:	// normal operation
					mode = 0;
					VitalSignsMonitor.debugMode = 0;
				break;

				case 1: // FRREE ERROR LED
					mode = 1;
					VitalSignsMonitor.debugMode = 1;
					HAL.LEDs->error.off();
				break;

				default:
					TMCL.reply->Status = REPLY_WRONG_TYPE;
				break;
			}
		break;

		case 4:
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void GetGlobalParameter(void)
{
	IdAssignmentTypeDef ids;

	switch(TMCL.command->Type)
	{
		case 1:
			TMCL.reply->Value.Int32 = VitalSignsMonitor.errors;
		break;

		case 2:
			TMCL.reply->Value.Int32 = EvalBoards.driverEnable;
		break;

		case 3:
			TMCL.reply->Value.Int32 = mode;
		break;

		case 4:
			ids.ch1.id = EvalBoards.ch1.id;
			ids.ch2.id = EvalBoards.ch2.id;
			TMCL.reply->Value.Int32 = BoardAssignment.supported(&ids);
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void SoftwareReset(void)
{
  if(ActualCommand.Value.Int32==1234) TMCL.resetRequest=TRUE;
}

