#ifndef WTMCL_H_

	#define WTMCL_H_
	#define WTMCL_PACK_ERR_NONE				0
	#define WTMCL_PACK_ERR_TYPE				1
	#define WTMCL_PACK_ERR_NUMBER			2
	#define WTMCL_PACK_ERR_VALUE			4
	#define WTMCL_PACK_ERR_CHECKSUM			8
	#define WTMCL_PACK_ERR_INCOMPLETE		16
	#define WTMCL_PACK_ERR_DISCARD			32

	#define WTMCL_SYS_CMD_ALIVE				0
	#define WTMCL_SYS_CMD_DIE				1
	#define WTMCL_SYS_CMD_SYNC				2


	#define WTMCL_TICK						100
	#define WTMCL_VITAL_SIGN_RX_EACH_CYC	40
	#define WTMCL_VITAL_SIGN_TX_EACH_CYC	2
	#define WTMCL_MAX_CHECKSUM_ERRORS		10
	#define WTMCL_RESET_FOR_CYC				2

	#include "../hal/RXTX.h"

	typedef struct
	{
	  char 	type;
	  char 	number;
	  int	value;
	  char	checkSum;
	  char	error;
	} WTMCLPackageTypeDef;

	typedef struct
	{
		WTMCLPackageTypeDef *in;
		WTMCLPackageTypeDef *out;
	 	void (*process) (unsigned int tick);
	 	void (*tx) (void);
	 	void (*rx) (void);
	 	void (*init) (void);
	 	void (*periodicJob_delegate) (void);
	 	void (*processPackage_delegate) (void);
	  char	error;
	} WTMCLTypeDef;

	typedef struct
	{
		char noVitalSignTXedSince;
		char noVitalSignRXedSince;
		char resetSince;
		char isVirgin;
		char checksumErrors;
		char WTMCLPulse;
		WTMCLPackageTypeDef in;
		WTMCLPackageTypeDef out;
		RXTXTypeDef *RXTX;
	} WTMCLCTRLTypeDef;

	WTMCLTypeDef WTMCL;
#endif
