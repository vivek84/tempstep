#ifndef __TMC4361_H
	#define __TMC4361_H

	#include "board.h"
	EvalBoardTypeDef TMC4361;

#endif
