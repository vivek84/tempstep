tested with TMCL-IDE 3.0.2.1 on:
 - TMCM-1140
 - TMCM-1161
 - TMCM-6110


EX0008-Read_Analog_Value.tmc only tested on TMCM-1161