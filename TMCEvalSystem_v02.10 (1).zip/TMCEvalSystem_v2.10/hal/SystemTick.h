#ifndef __SysTick_EVAL_
	#define __SysTick_EVAL_

	typedef struct
	{
		volatile unsigned int	tick;
		void (*init)();
	} SystemTickTypeDef;

	SystemTickTypeDef SystemTick;
#endif
