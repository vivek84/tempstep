#ifndef TMCMOTIONCONTROLLER_H_
	#define TMCMOTIONCONTROLLER_H_

	#include "board.h"

	typedef struct
	{
		void (*init)();
		ConfigurationTypeDef config;
	} EvalBoardMotionControllerTypeDef;

	EvalBoardMotionControllerTypeDef TMCMotionController;
#endif
