#ifndef __TMC2041_H
	#define __TMC2041_H

	#include "board.h"
	EvalBoardTypeDef TMC2041;

#endif
