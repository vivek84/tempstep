#ifndef __RS232_H_
	#define __RS232_H_

	#include "RXTX.h"
	RXTXTypeDef RS232;
#endif
