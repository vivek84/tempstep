#include "board.h"

static void init();

#define VM_MIN 0
#define VM_MAX -1

EvalBoardDriverTypeDef TMCDriver =
{
	.init 	= init,
	.config	=
	{
		.isBusy 			= 0,
		.ptr 				= 0,
		.shadowRegister 	= {}
	}
};

static void init()
{
	EvalBoards.ch2.config					= &TMCDriver.config;
	EvalBoards.ch2.config->isBusy 			= 0;
	EvalBoards.ch2.config->ptr	 			= 0;
	EvalBoards.ch2.config->reset			= TMCDummy.reset;
	EvalBoards.ch2.config->resetCallBack	= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.config->restore			= TMCDummy.restore;
	EvalBoards.ch2.config->restoreCallBack	= TMCDummy.TMCLDelegation;

	EvalBoards.ch2.numberOfMotors			= 0;
	EvalBoards.ch2.init						= init;
	EvalBoards.ch2.deInit					= TMCDummy.deInit;
	EvalBoards.ch2.periodicJob				= TMCDummy.periodicJob;
	EvalBoards.ch2.rotateLeft				= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.motorStop				= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.moveToPosition			= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.rotateRight				= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.getAxisParameter			= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.readRegister				= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.writeRegister			= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.setAxisParameter			= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.storeAxisParameter		= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.restoreAxisParameter		= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.userFunction				= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.getMeasuredSpeed			= TMCDummy.TMCLDelegation;
	EvalBoards.ch2.checkErrors				= TMCDummy.periodicJob;
	EvalBoards.ch2.enableDriver				= TMCDummy.enableDriver;
	EvalBoards.ch2.VMMin					= VM_MIN;
	EvalBoards.ch2.VMMax					= VM_MAX;
	EvalBoards.ch2.errors					= 0;
}
