/*
 * TMC22xx.c
 *
 *  Created on: 06.02.2017
 *      Author: OK
 */

#include "TMC22xx.h"

#define CRC8_GEN 0x07


//Helper functions that need to be implemented depending on the used CPU.
//The functions in this file need a buffered UART communication (typically
//implemented using UART interupts). This is highly dependent on the CPU
//which is used.
//For one wire UART communication, the TX pin of the CPU has to be in
//open drain mode and the RX pin needs a pull-up resistor.
static void UARTClearBuffers(void)
{
	//Clear all UART buffers
}

static void UARTWrite(uint8 Byte)
{
	//Write a byte to UART
}

static uint8 UARTRead(unit8 *Byte)
{
	//Try to read a byte from UART.
	//Return FALSE (0) if there is no byte available that can be read.
	//Return TRUE (1) if a byte has been read.
}


//Helper functions for CRC calculation
static uint8 nextCRCSingle(uint8 Crc, uint8 Data, uint8 Gen, uint8 Bit)
{
  uint8 Compare;

  Compare=Data<<(7-Bit);
  Compare&=0x80;

  if((Crc & 0x80) ^ (Compare))
    return (Crc << 1) ^ Gen;
  else
    return (Crc << 1);
}

static uint8 nextCRC(uint8 Crc, uint8 Data, uint8 Gen)
{
  uint8 Temp;
  int i;

  Temp=Crc;
  for(i=0; i<=7; i++)
  {
    Temp=nextCRCSingle(Temp, Data, Gen, i);
  }

  return Temp;
}


//Write to a TMC22xx register.
void tmc22xx_writeRegister(uint8 address, int32 value)
{
  uint8 crcRegister;

  crcRegister=0;
  crcRegister=nextCRC(crcRegister, 0x05, CRC8_GEN);    //Sync
  crcRegister=nextCRC(crcRegister, 0x00, CRC8_GEN);    //Slave Address (0)
  crcRegister=nextCRC(crcRegister, address|0x80, CRC8_GEN);  //Register address (with write bit set)
  crcRegister=nextCRC(crcRegister, value >> 24,  CRC8_GEN);  //Register data
  crcRegister=nextCRC(crcRegister, value >> 16,  CRC8_GEN);  //Register data
  crcRegister=nextCRC(crcRegister, value >>  8,  CRC8_GEN);  //Register data
  crcRegister=nextCRC(crcRegister, value & 0xff, CRC8_GEN);  //Register data

  UARTClearBuffers();
  UARTSend(0x05);
  UARTSend(0x00);
  UARTSend(address|0x80);
  UARTSend(value >> 24);
  UARTSend(value >> 16);
  UARTSend(value >> 8);
  UARTSend(value & 0xff);
  UARTSend(crcRegister);
}

//Read from a TMC22xx register.
void tmc22xx_readRegister(uint8 address, int32 *value)
{
  uint8 crcRegister;
  uint8 data;

  crcRegister=0;
  crcRegister=nextCRC(crcRegister, 0x05, CRC8_GEN);    //Sync
  crcRegister=nextCRC(crcRegister, 0x00, CRC8_GEN);    //Slave Address (0)
  crcRegister=nextCRC(crcRegister, address & 0x7f, CRC8_GEN); //Register address (without the write bit set)

  //Send read command
  UARTClearBuffers();
  UARTSend(0x05);              //Sync
  UARTSend(0x00);              //Slave Address (0 assumed)
  UARTSend(address & 0x7f);    //Register address
  UARTSend(crcRegister);       //CRC

  //Get data
  crcRegister=0;
  while(!UARTReceive(&data) || data!=0x05)   //Sync
  crcRegister=nextCRC(crcRegister, 0x05, CRC8_GEN);

  while(!UARTReceive(&data))                 //Master Address
  crcRegister=nextCRC(crcRegister, data, CRC8_GEN);

  while(!UARTReceive(&data))                 //Register Address
  crcRegister=nextCRC(crcRegister, data, CRC8_GEN);

  while(!UARTReceive(&data))                 //Value
  crcRegister=nextCRC(crcRegister, data, CRC8_GEN);

  *value=data;
  while(!UARTReceive(&data))                 //Value
  crcRegister=nextCRC(crcRegister, data, CRC8_GEN);

  (*value)<<=8;
  (*value)|=data;
  while(!UARTReceive(&data))                 //Value
  crcRegister=nextCRC(crcRegister, data, CRC8_GEN);

  (*value)<<=8;
  (*value)|=data;
  while(!UARTReceive(&data))                 //Value
  crcRegister=nextCRC(crcRegister, data, CRC8_GEN);

  *(value)<<=8;
  *(value)|=data;
  timeout=systick_getTick();
  while(!UARTReceive(&data))                 //CRC

  //Here one can check also the CRC if needed:
  //Signal an error if crcRegister!=data
}
