#ifndef __TYPEDEFS_H_
	#define __TYPEDEFS_H_

	typedef signed char             int8;
	typedef signed short int        int16;
	typedef signed long int         int32;
	typedef signed long long 		int64;

	typedef unsigned char           uint8;
	typedef unsigned short int      uint16;
	typedef unsigned long int       uint32;
	typedef unsigned long long 		uint64;

	#define FALSE     0
	#define TRUE      1

#endif /* TYPEDEFS_H_ */
