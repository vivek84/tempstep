#include "../hal/derivative.h"
#include "../hal/bits.h"
#include "../hal/HAL.h"
#include "stepDir.h"

#define MIN(a,b) (a<b) ? (a) : (b)
#define MAX(a,b) (a>b) ? (a) : (b)

#if defined(Startrampe)
	#define TIMER_INTERRUPT TIM2_IRQHandler
#elif defined(Landungsbruecke)
	#define TIMER_INTERRUPT FTM1_IRQHandler
#endif

static void init();
static void deInit();

StepDirectionCtrlType CTRL[STEP_DIR_NO_CHANNELS];

StepDirectionTypeDef StepDir =
{
	.init 		= init,
	.deInit 	= deInit,
	.ch1		= &CTRL[0].channel,
	.ch2		= &CTRL[1].channel
};

IOPinTypeDef DummyPin =
{
	.bitWeight 	= 3
};


unsigned char isEnabled;

void TIMER_INTERRUPT()
{
	uint8 ch;
	uint32 value;

#ifdef Startrampe
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) == RESET) return;
	TIM_ClearITPendingBit(TIM2, TIM_IT_Update); 								// clear pending flag
#else
	FTM1_SC &= ~FTM_SC_TOF_MASK;												// clear timer overflow flag
#endif


	for(ch=0; ch<STEP_DIR_NO_CHANNELS; ch++)									// for each stepDir channel
	{
		if(CTRL[ch].channel.haltMask) continue;
		if(!IS_STEP_DIR_PIN_BOND(CTRL[ch].channel.stepOut->bitWeight))	continue;
		if(!IS_STEP_DIR_PIN_BOND(CTRL[ch].channel.dirOut->bitWeight))	continue;

		*CTRL[ch].channel.stepOut->resetBitRegister = CTRL[ch].channel.stepOut->bitWeight;	// unset step output (falling edge of last pulse)


	// ========================================
	// determine acceleration/deceleration
	// ========================================

		if(CTRL[ch].channel.actualVelocity != CTRL[ch].channel.targetVelocity)
		{
			CTRL[ch].velocityAccu	+= CTRL[ch].channel.actualAcceleration;    		// resolution of acceleration is 32 Bit: every 2^17 interrupts velocity gets in/decreased by 1
			CTRL[ch].velocityAdd	= CTRL[ch].velocityAccu 	>> 17;   		// resolution of acceleration is 32 Bit: every 2^17 interrupts velocity gets in/decreased by 1
			CTRL[ch].velocityAccu	-= CTRL[ch].velocityAdd 	<< 17;			// resolution of acceleration is 32 Bit: every 2^17 interrupts velocity gets in/decreased by 1

			if(CTRL[ch].channel.actualVelocity < CTRL[ch].channel.targetVelocity)			// push actual velocity in direction of target velocity
			{
				CTRL[ch].channel.actualVelocity	= MIN(CTRL[ch].channel.actualVelocity+CTRL[ch].velocityAdd, CTRL[ch].channel.targetVelocity);
			}
			else if(CTRL[ch].channel.actualVelocity > CTRL[ch].channel.targetVelocity)
			{
				CTRL[ch].channel.actualVelocity	= MAX(CTRL[ch].channel.actualVelocity-CTRL[ch].velocityAdd, CTRL[ch].channel.targetVelocity);
			}
		}
		else
		{
			CTRL[ch].velocityAccu	=	0;
			CTRL[ch].velocityAdd	=	0;
		}


	// ========================================
	// positioning
	// ========================================
		CTRL[ch].channel.targetReached = 0;

		if(CTRL[ch].channel.rampMode == SD_RAMP_MODE_POSITIONING)
		{
			switch(CTRL[ch].rampState)
			{
				case RAMP_IDLE:
					if(CTRL[ch].channel.useProfile) CTRL[ch].channel.targetPosition = (CTRL[ch].channel.targetPosition == CTRL[ch].channel.profileFrom) ? CTRL[ch].channel.profileTo : CTRL[ch].channel.profileFrom;

				// wait for CTRL[ch].channel.targetPosition != CTRL[ch].channel.actualPosition (e.g change of CTRL[ch].channel.targetPosition)
					if(CTRL[ch].channel.actualPosition == CTRL[ch].channel.targetPosition)
					{
						CTRL[ch].channel.targetReached	= 1;
						break;
					}
					CTRL[ch].channel.targetVelocity	= (CTRL[ch].channel.actualPosition < CTRL[ch].channel.targetPosition) ? CTRL[ch].channel.maxPositioningSpeed : -CTRL[ch].channel.maxPositioningSpeed;
					CTRL[ch].rampState			= RAMP_ACCELERATE;
					CTRL[ch].accelerationSteps	= CTRL[ch].channel.actualPosition;
				break;

				case RAMP_ACCELERATE:
					if(abs(CTRL[ch].channel.actualVelocity) == CTRL[ch].channel.maxPositioningSpeed)	// velocity reached
					{
						CTRL[ch].accelerationSteps	= abs(CTRL[ch].channel.actualPosition-CTRL[ch].accelerationSteps)+1;
						CTRL[ch].rampState			= RAMP_DRIVING;
					}
					else if(abs(CTRL[ch].channel.actualPosition-CTRL[ch].accelerationSteps) >= abs(CTRL[ch].channel.targetPosition-CTRL[ch].channel.actualPosition))
					{	// start deceleration because steps left are needed for it
						CTRL[ch].channel.targetVelocity	= 0;
						CTRL[ch].rampState			= RAMP_DECELERATE;
					}
				break;

				case RAMP_DRIVING:
					if
					(
							(abs(CTRL[ch].channel.targetPosition-CTRL[ch].channel.actualPosition) <= CTRL[ch].accelerationSteps) ||
							((CTRL[ch].channel.targetVelocity < 0) && (CTRL[ch].channel.actualPosition<CTRL[ch].channel.targetPosition)) ||
							((CTRL[ch].channel.targetVelocity > 0) && (CTRL[ch].channel.actualPosition>CTRL[ch].channel.targetPosition))
					)
					{   // start deceleration because steps left are needed for it
						CTRL[ch].channel.targetVelocity = 0;
						CTRL[ch].rampState				= RAMP_DECELERATE;
					}
				break;

				case RAMP_DECELERATE:
					if(CTRL[ch].channel.actualPosition == CTRL[ch].channel.targetPosition)
					{
						CTRL[ch].channel.targetVelocity	= CTRL[ch].channel.actualVelocity = 0;
						CTRL[ch].rampState				= RAMP_IDLE;
					}
					else
					{
						if(CTRL[ch].channel.actualVelocity == 0)
						{
							CTRL[ch].channel.targetVelocity = CTRL[ch].channel.actualVelocity = CTRL[ch].channel.targetPosition-CTRL[ch].channel.actualPosition;
							CTRL[ch].rampState				= RAMP_ACCELERATE;
						}
					}
				break;
		  }
		}

	// ========================================
	// stop on stall
	// ========================================

		CTRL[ch].channel.stopOnStallActive = 1;

		if(!CTRL[ch].channel.stopOnStallVelocityTreshold) 											CTRL[ch].channel.stopOnStallActive = 0;
		if(abs(CTRL[ch].channel.actualVelocity) < CTRL[ch].channel.stopOnStallVelocityTreshold) 	CTRL[ch].channel.stopOnStallActive = 0;

		if(CTRL[ch].channel.stopOnStallActive && IS_STEP_DIR_PIN_BOND(CTRL[ch].channel.stallSignalIn->bitWeight))
		{
			if(IOs.isHigh(CTRL[ch].channel.stallSignalIn))
			{
				CTRL[ch].channel.stallFlagIn = 1;
			}
		}

		if(CTRL[ch].channel.stallFlagIn) CTRL[ch].channel.actualVelocity = 0;

	// ========================================
	// coolStep
	// ========================================

		if(CTRL[ch].channel.coolStepVelocityTreshold)
		{
			value = (CTRL[ch].channel.actualVelocity >= CTRL[ch].channel.coolStepVelocityTreshold) ? CTRL[ch].channel.coolStepActiveValue : CTRL[ch].channel.coolStepInActiveValue;

			if(CTRL[ch].channel.coolStepActualValue != value)
			{
				CTRL[ch].channel.coolStepActualValue = value;
				if(CTRL[ch].channel.coolStepActivationChanged) CTRL[ch].channel.coolStepActivationChanged(value);
			}
		}


	// ========================================
	// velocity
	// ========================================

		CTRL[ch].positionAccu 	+= CTRL[ch].channel.actualVelocity;   	// resolution of acceleration is 32 Bit: every 2^17 interrupts position gets in/decreased by 1
		CTRL[ch].positionAdd 	= CTRL[ch].positionAccu >> 17;     		// resolution of acceleration is 32 Bit: every 2^17 interrupts position gets in/decreased by 1
		CTRL[ch].positionAccu 	-= CTRL[ch].positionAdd << 17;			// resolution of acceleration is 32 Bit: every 2^17 interrupts position gets in/decreased by 1

		if(CTRL[ch].positionAdd==0) continue;  //keine Positions�nderung bei diesem Durchlauf: sofort abbrechen

	// ========================================
	// direction
	// ========================================

		if(IS_STEP_DIR_PIN_BOND(CTRL[ch].channel.dirOut->bitWeight))
		{
			if(CTRL[ch].positionAdd>=1)
			{
				CTRL[ch].positionAdd		= 1;
				*CTRL[ch].channel.dirOut->resetBitRegister 	= CTRL[ch].channel.dirOut->bitWeight;
			}
			else if(CTRL[ch].positionAdd<=-1)
			{
				CTRL[ch].positionAdd		= -1;
				*CTRL[ch].channel.dirOut->setBitRegister 	= CTRL[ch].channel.dirOut->bitWeight;
			}
		}

		CTRL[ch].channel.actualPosition			+= CTRL[ch].positionAdd;								// update position
		*CTRL[ch].channel.stepOut->setBitRegister = CTRL[ch].channel.stepOut->bitWeight;				// rising edge of step pulse
	}

}

#if defined(Startrampe)
	static void init()
	{
		int i;
		TIM_TimeBaseInitTypeDef 	TIM_TimeBaseStructure;
		NVIC_InitTypeDef 			NVIC_InitStructure;

		for(i=0; i< STEP_DIR_NO_CHANNELS; i++)
		{
			CTRL[i].channel.stallSignalIn				= &DummyPin;
			CTRL[i].channel.stepOut						= &DummyPin;
			CTRL[i].channel.dirOut						= &DummyPin;

			CTRL[i].channel.actualAcceleration			= 0;
			CTRL[i].channel.actualPosition				= 0;
			CTRL[i].channel.actualVelocity				= 0;
			CTRL[i].channel.maxPositioningSpeed			= 0;
			CTRL[i].channel.stopOnStallVelocityTreshold	= 0;
			CTRL[i].channel.targetPosition				= 0;
			CTRL[i].channel.targetVelocity				= 0;
			CTRL[i].channel.haltMask					= 0;
			CTRL[i].channel.stallFlagIn					= 0;
			CTRL[i].channel.coolStepVelocityTreshold	= 0;
			CTRL[i].channel.coolStepActiveValue			= 0;
			CTRL[i].channel.coolStepInActiveValue		= 0;
			CTRL[i].channel.coolStepActualValue			= 0;
			CTRL[i].channel.coolStepActivationChanged	= 0;
			CTRL[i].channel.profileFrom					= 0;
			CTRL[i].channel.profileTo					= 0;
			CTRL[i].channel.useProfile					= 0;
		}


		//Timer 2 konfigurieren (zum Erzeugen von Geschwindigkeiten)
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
		TIM_DeInit(TIM2);
		TIM_TimeBaseStructure.TIM_Period 						= 457;  			// for 120MHz clock -> 60MHz
		TIM_TimeBaseStructure.TIM_Prescaler 					= 0;
		TIM_TimeBaseStructure.TIM_ClockDivision 				= 0;
		TIM_TimeBaseStructure.TIM_CounterMode 					= TIM_CounterMode_Up;
		TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
		TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
		TIM_Cmd(TIM2, ENABLE);

		//Timer-Interrupt im NVIC freischalten
		NVIC_InitStructure.NVIC_IRQChannel 						= TIM2_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority 	= 1;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority 			= 1;
		NVIC_InitStructure.NVIC_IRQChannelCmd 					= ENABLE;
		NVIC_Init(&NVIC_InitStructure);
	}

	static void deInit()
	{
		TIM_DeInit(TIM2);
	}
#elif defined(Landungsbruecke)

	static void init()
	{
		int i;

		for(i=0; i< STEP_DIR_NO_CHANNELS; i++)
		{
			CTRL[i].channel.stallSignalIn		= &DummyPin;
			CTRL[i].channel.stepOut				= &DummyPin;
			CTRL[i].channel.dirOut				= &DummyPin;

			CTRL[i].channel.actualAcceleration			= 0;
			CTRL[i].channel.actualPosition				= 0;
			CTRL[i].channel.actualVelocity				= 0;
			CTRL[i].channel.maxPositioningSpeed			= 0;
			CTRL[i].channel.stopOnStallVelocityTreshold	= 0;
			CTRL[i].channel.targetPosition				= 0;
			CTRL[i].channel.targetVelocity				= 0;
			CTRL[i].channel.haltMask					= 0;
			CTRL[i].channel.stallFlagIn					= 0;
			CTRL[i].channel.coolStepVelocityTreshold	= 0;
			CTRL[i].channel.coolStepActiveValue			= 0;
			CTRL[i].channel.coolStepInActiveValue		= 0;
			CTRL[i].channel.coolStepActualValue			= 0;
			CTRL[i].channel.coolStepActivationChanged	= 0;
			CTRL[i].channel.profileFrom					= 0;
			CTRL[i].channel.profileTo					= 0;
			CTRL[i].channel.useProfile					= 0;
		}


		// enable clock for FTM1
			SIM_SCGC6 |= SIM_SCGC6_FTM1_MASK;

			FTM1_MODE |= FTM_MODE_WPDIS_MASK | FTM_MODE_FTMEN_MASK | FTM_MODE_FAULTM_MASK;	// disable write protection, FTM spezific register are available

			FTM1_SC |= FTM_SC_CLKS(1) | FTM_SC_PS(0);	// Clock source System Clock,divided by 0 Prescaler

			FTM1_CNTIN = 65535-366;

			FTM1_CONF |= FTM_CONF_NUMTOF(0);	// The TOF bit is set for each counter overflow

			// Edge-Aligned PWM (EPWM) mode
			FTM1_C0SC |= FTM_CnSC_MSB_MASK | FTM_CnSC_ELSB_MASK; //FTM_CnSC_CHIE_MASK //

			// enable FTM1 Timer Overflow interrupt
			FTM1_SC |= (uint32)(FTM_SC_TOIE_MASK);

			// set FTM1 interrupt handler
			enable_irq(INT_FTM1-16);
	}

	static void deInit()
	{
		SIM_SCGC6 |= SIM_SCGC6_FTM1_MASK;
		SIM_SCGC6 &= ~SIM_SCGC6_FTM1_MASK;
	}
#endif
