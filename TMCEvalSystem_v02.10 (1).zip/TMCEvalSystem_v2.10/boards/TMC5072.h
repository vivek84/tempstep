#ifndef __TMC5072_H
	#define __TMC5072_H

	#include "boards/board.h"
	EvalBoardTypeDef TMC5072;

#endif
