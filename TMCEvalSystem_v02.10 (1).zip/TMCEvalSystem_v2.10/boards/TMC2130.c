#include "rhino.h"
#include "TMC2130.h"
#include "../tmc/stepDir.h"

static void RotateRight(void);
static void RotateLeft(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void writeRegister(void);
static void readRegister(void);
static void rotate(void);
static void init(void);
static void deInit(void);
static void periodicJob(uint32 tick);
static void userFunction();
static void getMeasuredSpeed(void);

static uint8 reset();
static void enableDriver(uint8 disable0Enable1global2);

#define VM_MIN			50	// VM[V/10] min
#define VM_MAX			480	// VM[V/10] max +5%

typedef struct
{
	IOPinTypeDef *REFL_STEP;
	IOPinTypeDef *REFR_DIR;
	IOPinTypeDef *DRV_ENN_CFG6;
	IOPinTypeDef *ENCA_DCIN_CFG5;
	IOPinTypeDef *ENCB_DCEN_CFG4;
	IOPinTypeDef *ENCN_DCO;
	IOPinTypeDef *DIAG0;
	IOPinTypeDef *DIAG1;
	IOPinTypeDef *AIN_REF_SW;
	IOPinTypeDef *AIN_REF_PWM;
} PinsTypeDef;

static PinsTypeDef Pins;
StepDirectionChannelType 		stepDirDummmy;
EvalBoardTypeDef 				TMC2130 		= {init};
static StepDirectionChannelType *StepDirCh[] 	= {&stepDirDummmy};

void rotate()
{
  if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
  {
	if(TMCL.command->Type==0)
	{
		StepDirCh[TMCL.command->Motor]->rampMode 		= SD_RAMP_MODE_VELOCITY;
		StepDirCh[TMCL.command->Motor]->targetVelocity 	= TMCL.command->Value.Int32;
	}
	else TMCL.reply->Status=REPLY_WRONG_TYPE;
  }
  else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void RotateRight(void)
{
	rotate();
}

static void RotateLeft(void)
{
	TMCL.command->Value.Int32 = -TMCL.command->Value.Int32;
	rotate();
}

static void MotorStop(void)
{
	TMCL.command->Value.Int32 = 0;
	rotate();
}

static void MoveToPosition(void)
{
	if(TMCL.command->Motor==0)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				StepDirCh[0]->targetPosition	= TMCL.command->Value.Int32;
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
				StepDirCh[0]->useProfile		= 0;
			break;

			case MVP_REL:
				StepDirCh[0]->targetPosition	= StepDirCh[0]->actualPosition+TMCL.command->Value.Int32;
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
				StepDirCh[0]->useProfile		= 0;
			break;

			case MVP_PRF:
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
				StepDirCh[0]->useProfile		= 0;
				StepDirCh[0]->profileFrom		= StepDir.ch1->actualPosition;
				StepDirCh[0]->targetPosition	= StepDirCh[0]->profileFrom;
				StepDirCh[0]->profileTo			= TMCL.command->Value.Int32;
				StepDirCh[0]->useProfile 		= 1;
			break;

			default:
				TMCL.reply->Status			= REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
  uint32 value;

  if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
  {
    switch(TMCL.command->Type)
    {
		case 0:
		  StepDirCh[TMCL.command->Motor]->targetPosition			= TMCL.command->Value.Int32;
		break;

		case 1:
		  StepDirCh[TMCL.command->Motor]->actualPosition			= TMCL.command->Value.Int32;
		break;

		case 2:
		  StepDirCh[TMCL.command->Motor]->targetVelocity			= TMCL.command->Value.Int32;
		break;

		case 4:
		  StepDirCh[TMCL.command->Motor]->maxPositioningSpeed		= abs(TMCL.command->Value.Int32);
		break;

		case 5:
		  StepDirCh[TMCL.command->Motor]->actualAcceleration		= TMCL.command->Value.Int32;
		break;

		case 6:
		  value=TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
		  TMCRhino.writeDatagram(TMCRhino_IHOLD_IRUN, 0, value >> 16, TMCL.command->Value.Byte[0], value & 0xff);
		break;

		case 7:
			value	= TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
			TMCRhino.writeDatagram(TMCRhino_IHOLD_IRUN, 0, value >> 16,value >> 8, TMCL.command->Value.Byte[0]);
		break;


		case 21:
			TMCRhino.writeInt(TMCRhino_TZEROWAIT, TMCL.command->Value.Int32);
		break;

		case 22:
			value = (TMCL.command->Value.Int32) ? TMCL.command->Value.Int32 : 1;
			value = (1<<24)/value;
			value = (value > 0xFFFFF) ? 0xFFFFF : value;
			TMCRhino.writeInt(TMCRhino_TCOOLTHRS, value);

			TMCL.reply->Value.Int32 = value;
		break;

		case 23:
			value = (TMCL.command->Value.Int32) ? TMCL.command->Value.Int32 : 1;
			value = (1<<24)/value;
			value = (value > 0xFFFFF) ? 0xFFFFF : value;
			TMCRhino.writeInt(TMCRhino_THIGH, value);

			TMCL.reply->Value.Int32 = value;
		break;

		case 24:
			TMCRhino.writeInt(TMCRhino_VDCMIN, TMCL.command->Value.Int32);
		break;

		case 28:
			value = TMCRhino.readInt(TMCRhino_CHOPCONF);
			value &= ~(0x01<<18);
			if(TMCL.command->Value.Int32) value |= (0x01<<18);
			TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
		break;

		case 140:
			switch(TMCL.command->Value.Int32)
			{
				case 1:	 	TMCL.command->Value.Int32 = 8; break;
				case 2:	 	TMCL.command->Value.Int32 = 7; break;
				case 4:	 	TMCL.command->Value.Int32 = 6; break;
				case 8:	 	TMCL.command->Value.Int32 = 5; break;
				case 16:	TMCL.command->Value.Int32 = 4; break;
				case 32:	TMCL.command->Value.Int32 = 3; break;
				case 64:	TMCL.command->Value.Int32 = 2; break;
				case 128:	TMCL.command->Value.Int32 = 1; break;
				case 256:	TMCL.command->Value.Int32 = 0; break;
				default: 	TMCL.command->Value.Int32 = -1; break;
			}

			if(TMCL.command->Value.Int32 != -1)
			{
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x0F<<24);
				value |= (TMCL.command->Value.Int32 & 0xF) << 24;
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;
		break;

		case 162:
			value = TMCRhino.readInt(TMCRhino_CHOPCONF);
			value &= ~(0x03<<15);
			value |= (TMCL.command->Value.Int32 & 0x3) << 15;
			TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
		break;

		case 163:
			value = TMCRhino.readInt(TMCRhino_CHOPCONF);
			value &= ~(0x01<<14);
			if(TMCL.command->Value.Int32) value |= (0x01<<14);
			TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
		break;

		case 164:
			value = TMCRhino.readInt(TMCRhino_CHOPCONF);
			value &= ~(0x01<<12);
			if(TMCL.command->Value.Int32) value |= (0x01<<12);
			TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
		break;

		case 165:
			if(TMCRhino.readInt(TMCRhino_CHOPCONF) & (1<<14))
			{
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x0F<<7);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 7;
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			}
			else
			{
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);

				if(TMCL.command->Value.Int32 & (1<<3)) value |= (0x01<<11);
				else value &= ~(0x01<<11);

				value &= ~(0x07<<4);
				value |=  (TMCL.command->Value.Int32 & 0x0F) << 4;

				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			}
		break;

		case 166:
			if(TMCRhino.readInt(TMCRhino_CHOPCONF) & (1<<14))
			{
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x07<<4);
				value |= (TMCL.command->Value.Int32 & 0x07) << 4;
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			}
			else
			{
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x0F<<7);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 7;
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			}
		break;

		case 167:
			value = TMCRhino.readInt(TMCRhino_CHOPCONF);
			value &= ~(0x0F<<0);
			value |= (TMCL.command->Value.Int32 & 0x0F) << 0;
			TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
		break;

		case 168:
			value = TMCRhino.readInt(TMCRhino_COOLCONF);
			value &= ~(0x01<<15);
			if(TMCL.command->Value.Int32) value |= (0x01<<15);
			TMCRhino.writeInt(TMCRhino_COOLCONF,value);
		break;

		case 169:
			value = TMCRhino.readInt(TMCRhino_COOLCONF);
			value &= ~(0x03<<13);
			value |= (TMCL.command->Value.Int32 & 0x03) << 13;
			TMCRhino.writeInt(TMCRhino_COOLCONF,value);
		break;

		case 170:
			value = TMCRhino.readInt(TMCRhino_COOLCONF);
			value &= ~(0x0F<<8);
			value |= (TMCL.command->Value.Int32 & 0x0F) << 8;
			TMCRhino.writeInt(TMCRhino_COOLCONF,value);
		break;

		case 171:
			value = TMCRhino.readInt(TMCRhino_COOLCONF);
			value &= ~(0x03<<5);
			value |= (TMCL.command->Value.Int32 & 0x03) << 5;
			TMCRhino.writeInt(TMCRhino_COOLCONF,value);
		break;

		case 172:
			value = TMCRhino.readInt(TMCRhino_COOLCONF);
			value &= ~(0x0F<<0);
			value |= (TMCL.command->Value.Int32 & 0x0F) << 0;
			TMCRhino.writeInt(TMCRhino_COOLCONF,value);
		break;

		case 173:
			value = TMCRhino.readInt(TMCRhino_COOLCONF);
			value &= ~(0x01<<24);
			if(TMCL.command->Value.Int32) value |= (0x01<<24);
			TMCRhino.writeInt(TMCRhino_COOLCONF,value);
		break;

		case 174:
			value = TMCRhino.readInt(TMCRhino_COOLCONF);
			value &= ~(0x07F<<16);
			value |= (TMCL.command->Value.Int32 & 0x07F) << 16;
			TMCRhino.writeInt(TMCRhino_COOLCONF,value);
		break;

		case 179:
			value = TMCRhino.readInt(TMCRhino_CHOPCONF);
			value &= ~(0x01<<17);
			if(TMCL.command->Value.Int32) value |= (0x01<<17);
			TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
		break;

		case 181:
			StepDirCh[TMCL.command->Motor]->stopOnStallVelocityTreshold = TMCL.command->Value.Int32;
			StepDir.ch1->stallFlagIn = 0;
		break;

		case 182:
			if((value = TMCL.command->Value.Int32))
			{
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
			}
			else value = 0xFFFFF;
			TMCRhino.writeInt(TMCRhino_TCOOLTHRS, value);
			TMCL.reply->Value.Int32 = value;
		break;

		case 184:
			value = TMCRhino.readInt(TMCRhino_CHOPCONF);
			value &= ~(0x01<<13);
			if(TMCL.command->Value.Int32) value |= (0x01<<13);
			TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
		break;

		case 185:
			value = TMCRhino.readInt(TMCRhino_CHOPCONF);
			value &= ~(0x0F<<20);
			value |= (TMCL.command->Value.Int32 & 0x0F) << 20;
			TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
		break;
      default:
        TMCL.reply->Status=REPLY_WRONG_TYPE;
      break;
    }
  }
  else TMCL.reply->Status=REPLY_WRONG_TYPE;
}

static void GetAxisParameter(void)
{
	uint32 value;
	if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->targetPosition;
			break;

			case 1:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualPosition;
			break;

			case 2:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->targetVelocity;
			break;

			case 3:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualVelocity;
			break;

			case 4:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->maxPositioningSpeed;
			break;

			case 5:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualAcceleration;
			break;

			case 6:
				value = TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
				TMCL.reply->Value.Int32=(value>>8) & 0xff;
			break;

		    case 7:
		        value=TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
		        TMCL.reply->Value.Int32=value & 0xff;
			break;

		    case 8:
		        TMCL.reply->Value.Int32 = StepDirCh[0]->targetReached;
			break;

			case 22:
				value = TMCRhino.readInt(TMCRhino_TCOOLTHRS);
				value = (value) ? value : 1;
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
				TMCL.reply->Value.Int32 = value;
			break;

			case 23:
				value = TMCRhino.readInt(TMCRhino_THIGH);
				value = (value) ? value : 1;
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
				TMCL.reply->Value.Int32 = value;
			break;

			case 24:
				TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_VDCMIN);
			break;

			case 28:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_GCONF) >> 1) & 1;
			break;

			case 29:
				TMCL.reply->Value.Int32 = StepDir.ch1->actualVelocity;
			break;

			case 140:
				TMCL.reply->Value.Int32 = 256>>((TMCRhino.readInt(TMCRhino_CHOPCONF) >> 24) & 0x0F);
			break;

			case 162:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 15) & 0x03;
			break;

			case 163:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 14) & 0x01;
			break;

			case 164:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 12) & 0x01;
			break;

			case 165:
				if(TMCRhino.readInt(TMCRhino_CHOPCONF) & (1<<14))
				{
					TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 7) & 0x0F;
				}
				else
				{
					value = TMCRhino.readInt(TMCRhino_CHOPCONF);
					TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 4) & 0x07;
					if(value & (1<<11)) TMCL.reply->Value.Int32 |= 1<<3;
				}
			break;

			case 166:
				if(TMCRhino.readInt(TMCRhino_CHOPCONF) & (1<<14))
				{
					TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 4) & 0x07;
				}
				else
				{
					value = TMCRhino.readInt(TMCRhino_CHOPCONF);
					TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 7) & 0x0F;
					if(value & (1<<11)) TMCL.reply->Value.Int32 |= 1<<3;
				}
			break;

			case 167:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 0) & 0x0F;
			break;

			case 168:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 15) & 0x01;
			break;

			case 169:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 13) & 0x03;
			break;

			case 170:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 8) & 0x0F;
			break;

			case 171:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 5) & 0x03;
			break;

			case 172:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 0) & 0x0F;
			break;

			case 173:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 24) & 0x01;
			break;

			case 174:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 16) & 0x7F;
				TMCL.reply->Value.Int32 |= (TMCL.reply->Value.Int32 & (1<<6)) ? 0xFFFFFF80 : 0;
			break;

			case 179:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 17) & 0x01;
			break;

			case 180:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_DRVSTATUS) >> 16) & 0x01F;
			break;

			case 181:
				TMCL.reply->Value.Int32 = StepDirCh[TMCL.command->Motor]->stopOnStallVelocityTreshold;
			break;

			case 182:
				value = TMCRhino.readInt(TMCRhino_TCOOLTHRS);
				value = (value) ? value : 1;
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
				TMCL.reply->Value.Int32 = value;
			break;

			case 184:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 13) & 0x01;
			break;

			case 185:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 20) & 0x0F;
			break;

			case 206:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_DRVSTATUS) >> 0) & 0x03FF;
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void writeRegister(void)
{
	TMCRhino.writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32=TMCRhino.readInt(TMCL.command->Type);
}

static void periodicJob(uint32 tick)
{
	TMCRhino.periodicJob(tick);

	if(!StepDir.ch1->stallFlagIn && StepDir.ch1->stopOnStallActive)
	{
		TMCRhino.readInt(TMCRhino_DRVSTATUS);
		if(TMCRhino.readInt(TMCRhino_DRVSTATUS) & (1<<24)) StepDir.ch1->stallFlagIn = 1;
	}
}

static void userFunction()
{
	uint32 uvalue;

	switch(TMCL.command->Type)
	{
		case 0:	// set analogue current duty
			/*
			 * Current will be defined by analogue value voltage or current signal. In any case this function
			 * will generate a analogue voltage by PWM for up to 50% duty and a switch for the other 50%.
			 * The reference voltage will be AIN_REF = VCC_IO * value/20000 with value = {0..20000}
			 */

			uvalue = (uint32) TMCL.command->Value.Int32;

			if(uvalue <= 20000)
			{
				HAL.IOs->config->setToState(Pins.AIN_REF_SW, (uvalue > 10000) ? HIGH : LOW);
				Timer.setDuty(uvalue%10001);
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;
		break;

		case 1:	// Use internal clock
			/*
			 * Internel clock will be enabled by calling this function with a value != 0 and unpower and repower the motor supply while keeping usb connected.
			 */
			if(TMCL.command->Value.Int32) HAL.IOs->config->setToState(&HAL.IOs->pins->CLK16, LOW);
			else HAL.IOs->config->reset(&HAL.IOs->pins->CLK16);
		break;

		case 2:	// writing a register at address = motor with value = value and reading back the value
			TMCRhino.writeInt(TMCL.command->Motor, TMCL.command->Value.Int32);
			TMCL.reply->Value.Int32 = TMCRhino.readInt(TMCL.command->Motor);
		break;

		case 3:	// set DC_EN
			HAL.IOs->config->setToState(Pins.ENCB_DCEN_CFG4, (TMCL.command->Value.Int32) ? HIGH : LOW);
		break;

		case 4: // move a profile
			switch(TMCL.command->Value.Int32)
			{
				case 0: // deactivate using a profile
					StepDirCh[0]->useProfile 		= 0;
				break;

				case 1: // move from this psoition
					StepDirCh[0]->profileFrom 		= StepDir.ch1->actualPosition;
				break;

				case 2: // to this position
					StepDirCh[0]->profileTo 		= StepDir.ch1->actualPosition;
				break;

				case 3: // activate using a profile
					StepDirCh[0]->useProfile 		= 1;
					StepDirCh[0]->targetPosition	= StepDirCh[0]->profileFrom;
					StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
				break;

				default: // activate using a profile from current position to current position + value
					StepDirCh[0]->useProfile 		= 0;
					StepDirCh[0]->profileFrom		= StepDir.ch1->actualPosition;
					StepDirCh[0]->profileTo			= TMCL.command->Value.Int32;
					StepDirCh[0]->targetPosition	= StepDirCh[0]->profileFrom;
					StepDirCh[0]->useProfile 		= 1;
				break;
			}
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void getMeasuredSpeed(void)
{
	switch(TMCL.command->Motor)
	{
		case 0:
			TMCL.reply->Value.Int32 	= StepDir.ch1->actualVelocity;
		break;

		default:
			TMCL.reply->Status 			= REPLY_WRONG_TYPE;
		break;
	}
}

static void init(void)
{
	Pins.DRV_ENN_CFG6 	= &HAL.IOs->pins->DIO0;
	Pins.REFL_STEP		= &HAL.IOs->pins->DIO6;
	Pins.REFR_DIR		= &HAL.IOs->pins->DIO7;
	Pins.AIN_REF_SW		= &HAL.IOs->pins->DIO10;
	Pins.AIN_REF_PWM	= &HAL.IOs->pins->DIO11;
	Pins.ENCA_DCIN_CFG5 = &HAL.IOs->pins->DIO12;
	Pins.ENCB_DCEN_CFG4	= &HAL.IOs->pins->DIO13;
	Pins.ENCN_DCO	 	= &HAL.IOs->pins->DIO14;
	Pins.DIAG0 			= &HAL.IOs->pins->DIO15;
	Pins.DIAG1 			= &HAL.IOs->pins->DIO16;

	HAL.IOs->config->toInput(Pins.DIAG0);
	HAL.IOs->config->toInput(Pins.DIAG1);
	HAL.IOs->config->toInput(Pins.ENCN_DCO);

	HAL.IOs->config->toOutput(Pins.REFL_STEP);
	HAL.IOs->config->toOutput(Pins.REFR_DIR);
	HAL.IOs->config->toOutput(Pins.DRV_ENN_CFG6);
	HAL.IOs->config->toOutput(Pins.ENCB_DCEN_CFG4);
	HAL.IOs->config->toOutput(Pins.ENCA_DCIN_CFG5);
	HAL.IOs->config->toOutput(Pins.AIN_REF_PWM);
	HAL.IOs->config->toOutput(Pins.AIN_REF_SW);

	HAL.IOs->config->setLow(Pins.AIN_REF_PWM);
	HAL.IOs->config->setLow(Pins.AIN_REF_SW);
	HAL.IOs->config->setLow(Pins.ENCN_DCO);
	HAL.IOs->config->setLow(Pins.ENCA_DCIN_CFG5);

	TMCRhino.SPIChannel					= &HAL.SPI->ch2;
	TMCRhino.SPIChannel->CSN 			= &HAL.IOs->pins->SPI2_CSN0;
	TMCRhino.config 					= EvalBoards.ch2.config;

	StepDir.init();
	StepDirCh[0] 						= StepDir.ch2;
	StepDirCh[0]->stepOut 				= Pins.REFL_STEP;
	StepDirCh[0]->dirOut 				= Pins.REFR_DIR;

	EvalBoards.ch2.config->reset		= reset;
	EvalBoards.ch2.config->restore		= TMCRhino.restore;
	EvalBoards.ch2.config->isBusy 		= 0;
	EvalBoards.ch2.config->ptr	 		= 0;

	EvalBoards.ch2.motorStop			= MotorStop;
	EvalBoards.ch2.getAxisParameter		= GetAxisParameter;
	EvalBoards.ch2.moveToPosition		= MoveToPosition;
	EvalBoards.ch2.rotateLeft			= RotateLeft;
	EvalBoards.ch2.rotateRight			= RotateRight;
	EvalBoards.ch2.setAxisParameter		= SetAxisParameter;
	EvalBoards.ch2.writeRegister		= writeRegister;
	EvalBoards.ch2.readRegister			= readRegister;
	EvalBoards.ch2.periodicJob			= periodicJob;
	EvalBoards.ch2.enableDriver			= enableDriver;
	EvalBoards.ch2.userFunction			= userFunction;
	EvalBoards.ch2.getMeasuredSpeed		= getMeasuredSpeed;
	EvalBoards.ch2.VMMin				= VM_MIN;
	EvalBoards.ch2.VMMax				= VM_MAX;
	EvalBoards.ch2.numberOfMotors		= 1;
	EvalBoards.numberOfMotors			= 1;
	EvalBoards.ch2.deInit				= deInit;

	EvalBoards.ch2.enableDriver(2);

#if defined(Startrampe)
	Pins.AIN_REF_PWM->configuration.GPIO_Mode = GPIO_Mode_AF;
	GPIO_PinAFConfig(Pins.AIN_REF_PWM->port, Pins.AIN_REF_PWM->bit, GPIO_AF_TIM1);
#elif defined(Landungsbruecke)
	HAL.IOs->config->toOutput(Pins.AIN_REF_PWM);
	Pins.AIN_REF_PWM->configuration.GPIO_Mode = GPIO_Mode_AF4;
#endif
	HAL.IOs->config->set(Pins.AIN_REF_PWM);

	Timer.init();
	Timer.setDuty(0);
}

static void deInit(void)
{
	HAL.IOs->config->setHigh(Pins.DRV_ENN_CFG6);	// DISABLE DRIVER

	HAL.IOs->config->reset(Pins.REFL_STEP);
	HAL.IOs->config->reset(Pins.REFR_DIR);
	HAL.IOs->config->reset(Pins.AIN_REF_SW);
	HAL.IOs->config->reset(Pins.AIN_REF_PWM);
	HAL.IOs->config->reset(Pins.ENCA_DCIN_CFG5);
	HAL.IOs->config->reset(Pins.ENCB_DCEN_CFG4);
	HAL.IOs->config->reset(Pins.ENCN_DCO);
	HAL.IOs->config->reset(Pins.DIAG0);
	HAL.IOs->config->reset(Pins.DIAG1);
	HAL.IOs->config->reset(Pins.DRV_ENN_CFG6);

	StepDir.deInit();
	Timer.deInit();
}

static uint8 reset()
{
	if(StepDirCh[0]->actualVelocity && !VitalSignsMonitor.brownOut) return 0;
	TMCRhino.reset();
	StepDir.init();
	StepDirCh[0] 						= StepDir.ch1;
	StepDirCh[0]->stepOut 				= Pins.REFL_STEP;
	StepDirCh[0]->dirOut 				= Pins.REFR_DIR;
	return 1;
}

static void enableDriver(uint8 enable)
{
	if(enable == 2) enable = EvalBoards.driverEnable;

	if(enable ==  0)											HAL.IOs->config->setHigh(Pins.DRV_ENN_CFG6);
	else if((enable == 1) && (EvalBoards.driverEnable == 1))	HAL.IOs->config->setLow(Pins.DRV_ENN_CFG6);
}
