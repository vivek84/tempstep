#include "board.h"

static void init(void);
static void deInit(void);
static void delegation(void);
static void periodicJob(uint32 tick);
static void enableDriver(uint8 reset);
static uint8 delegationReturn(void);

EvalBoardDummyTypeDef TMCDummy =
{
	.init 			= init,
	.deInit 		= deInit,
	.TMCLDelegation = delegation,
	.reset			= delegationReturn,
	.restore		= delegationReturn,
	.periodicJob	= periodicJob,
	.enableDriver	= enableDriver
};


static void init(void)
{

}

static void deInit(void)
{

}

static void delegation(void)
{
	TMCL.reply->Status = REPLY_INVALID_CMD;
}

static uint8 delegationReturn(void)
{
	return 1;
}

static void enableDriver(uint8 enable)
{
	UNUSED(enable);
}

static void periodicJob(uint32 tick)
{
	UNUSED(tick);
}
