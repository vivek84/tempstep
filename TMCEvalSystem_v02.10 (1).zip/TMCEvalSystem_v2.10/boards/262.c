#include "262.h"

static void writeInt(uint8 address, uint32 value);
static uint32 readInt(uint8 address);
static void periodicJob(uint32 tick);
static void continousSync();
static void standStillCurrentLimitation();
static void readWrite(uint32 value);
static void readImmediately(uint8 rdsel);
static uint8 reset();
static uint8 restore();
static void setField(uint8 address, uint32 clearMask, uint32 value);

TMC262TypeDef TMC262 =
{
	.SPIChannel 			= &SPI.ch2,
	.periodicJob			= periodicJob,
	.writeInt				= writeInt,
	.readInt				= readInt,
	.reset					= reset,
	.restore				= restore,
	.setField				= setField,
	.continuosModeEnable		= 1,
	.registerResetState		=
	{
		(TMC262_DRVCTRL<<17)	| 0,																													// 0 DRVCTRL
		0,																																				// 1 UNUSED
		0,																																				// 2 UNUSED
		0,																																				// 3 UNUSED
		(TMC262_CHOPCONF<<17)	| TMC262_SET_TBL(2)		| TMC262_SET_HEND(2) 	| TMC262_SET_HSTRT(3) 	| TMC262_SET_TOFF(5) 	| TMC262_SET_HDEC(3),	// 4 CHOPCONF
		(TMC262_SMARTEN<<17)	| 0,																													// 5 SMARTEN
		(TMC262_SGCSCONF<<17)	| TMC262_SET_SFILT(1) 	| TMC262_SET_SGT(5) 	| TMC262_SET_CS(5),														// 6 SGCSCONF
		(TMC262_DRVCONF<<17)	| TMC262_SET_SLPH(3)	| TMC262_SET_SLPL(3) 	| TMC262_SET_VSENSE(1)													// 7 DRVCONF
	}
};


/* TCM262 registers can't be read back. To keep track of settings all write accesses datagrams get stored in a global shadow register.
 * The register select bits of TMC2660 are used as storage address. In addition the 4th bit is set high to mark a write datagram.
 * The responses are also stored in the global shadow register using the RDSEL setting as address.
 *
 * If continuos mode is enabled(default) all settings are frequently take form shadow registers and frequently written to the chip via SPI.
 * This way, on a brownout, situation settings won't get lost.
 * To keep track of TMC2660 responses without always swichting between the desired responses the read all respones are requested permanently.
 * For faster access to the common lower 7 bits of the read responses the latest response is additionally stored to shadow register address 3.
 *
 * READ SHADOW ADDRESSES
 *		RDSEL==0 Datagram				0 = 0x00
 *		RDSEL==1 Datagram				1 = 0x01
 *		RDSEL==2 Datagram				2 = 0x02
 *		RDSEL==x Datagram				3 = 0x03	// copy of latest read response independent from RDSEL, if just lower 7 bits needed
 *
 *
 * WRITE SHADOW ADDRESSES
 * 		TMC262_DRVCTRL					0 | (1<<4) = 8	= 0x08
 *		TMC262_DRVCONF					3 | (1<<4) = 11 = 0x0B
 *		TMC262_CHOPCONF					4 | (1<<4) = 12 = 0x0C
 *		TMC262_SMARTEN					5 | (1<<4) = 13 = 0x0D
 *		TMC262_SGCSCONF					6 | (1<<4) = 14 = 0x0E
*/

static void readWrite(uint32 value)
{	// sending data (value) via spi to TMC262, coping written and received data to shadow register
	static uint8 rdsel = 0; // number of expected read response

// if SGCONF should be written, check whether stand still, or run current should be used
	if(TMC262_GET_ADDRESS(value) == TMC262_SGCSCONF)
	{
		value &= ~TMC262_SET_CS(-1); // clear CS field
		value |= (TMC262.isStandStillCurrentLimit) ?  TMC262_SET_CS(TMC262.standStillCurrentScale) : TMC262_SET_CS(TMC262.runCurrentScale); // set current
	}

// write value and read reply to shadow register
	TMC262.config->shadowRegister[rdsel]	=	TMC262.SPIChannel->readWrite(value>>16, 0);
	TMC262.config->shadowRegister[rdsel]	<<=	8;
	TMC262.config->shadowRegister[rdsel]	|=	TMC262.SPIChannel->readWrite(value>>8, 0);
	TMC262.config->shadowRegister[rdsel]	<<=	8;
	TMC262.config->shadowRegister[rdsel]	|=	TMC262.SPIChannel->readWrite(value & 0xff, 1);
	TMC262.config->shadowRegister[rdsel]	>>=	4;

	TMC262.config->shadowRegister[TMC262_RESPONSE_LATEST] = TMC262.config->shadowRegister[rdsel]; // copy value to latest field

// set virtual read address for next reply given by RDSEL, can only change by setting RDSEL in DRVCONF
	if(TMC262_GET_ADDRESS(value) == TMC262_DRVCONF) rdsel = TMC262_GET_RDSEL(value);

// write store written value to shadow register
	TMC262.config->shadowRegister[(0x7F & TMC262_GET_ADDRESS(value)) | TMC262_WRITE ] = value;
}

static void readImmediately(uint8 rdsel)
{ // sets desired reply in DRVCONF register, resets it to previous settings whilst reading desired reply
	uint32 value, drvConf;

// additional reading to keep all replies up to date
	value = drvConf = TMC262.readInt(TMC262_WRITE | TMC262_DRVCONF);	// buffer value amd  drvConf to write back later
	value &= ~TMC262_SET_RDSEL(-1);										// clear RDSEL bits
	value |= TMC262_SET_RDSEL((rdsel%3));								// clear set rdsel
	readWrite(value);													// write to chip and readout reply
	readWrite(drvConf);													// write to chip and return desired reply
}

static void continousSync()
{ // refreshes settings to prevent chip from loosing settings on brownout

	static uint8 write 	= 0;
	static uint8 read 	= 0;

	// rotational reading all replys to keep values up to date
		readImmediately(read);

	// determine next read address
		read = (read + 1) % 3;

	// write settings from shadow register to chip.
		readWrite(TMC262.config->shadowRegister[TMC262_WRITE | write]);

	// determine next write address
		write = (!write) ? 4 : ((write + 1) % 8);	 // next write address,skip unused addresses and DRVCONF REGISTER
}

static void writeInt(uint8 address, uint32 value)
{// writes values to chip or in continous sync mode to continously synchronized shadow register

	value &= 0xFFFFF;

// store desired cs value, this can be overwritten by current limitation
	if(TMC262_GET_ADDRESS(value) == TMC262_SGCSCONF) TMC262.runCurrentScale = TMC262_GET_CS(value);

	TMC262.config->shadowRegister[0x7F & (address | TMC262_WRITE)] = value;
	if(!TMC262.continuosModeEnable) readWrite(value);
}

static uint32 readInt(uint8 address)
{ // read values from chip or in continous sync mode rotary synchronized values from shadow register

	if(!TMC262.continuosModeEnable && !(address & TMC262_WRITE)) readImmediately(address);
	return TMC262.config->shadowRegister[0x7F & address];
}

static void periodicJob(uint32 tick)
{
	static uint32 oldTick;

	if(TMC262.continuosModeEnable)
	{ // continously write settings to chip and rotationally read back all replys to keep data up to date
		continousSync();

		if(abs(tick-oldTick) >= 10)
		{
			standStillCurrentLimitation();
			oldTick = tick;
		}
	}
}

static uint8 reset()
{ // write reset configuration, disable continuos mode to make sure these 5 datagrams are written directly

	uint8 continuosMode = TMC262.continuosModeEnable;

	TMC262.continuosModeEnable = 0;

	TMC262.writeInt(TMC262_DRVCTRL, 	TMC262.registerResetState[TMC262_DRVCTRL]);
	TMC262.writeInt(TMC262_CHOPCONF, 	TMC262.registerResetState[TMC262_CHOPCONF]);
	TMC262.writeInt(TMC262_SMARTEN, 	TMC262.registerResetState[TMC262_SMARTEN]);
	TMC262.writeInt(TMC262_SGCSCONF, 	TMC262.registerResetState[TMC262_SGCSCONF]);
	TMC262.writeInt(TMC262_DRVCONF, 	TMC262.registerResetState[TMC262_DRVCONF]);

	TMC262.continuosModeEnable = continuosMode;
	return 1;
}

static uint8 restore()
{ // write reset configuration
	TMC262.writeInt(TMC262_DRVCTRL, 	TMC262.config->shadowRegister[TMC262_DRVCTRL	| TMC262_WRITE]);
	TMC262.writeInt(TMC262_CHOPCONF, 	TMC262.config->shadowRegister[TMC262_CHOPCONF	| TMC262_WRITE]);
	TMC262.writeInt(TMC262_SMARTEN, 	TMC262.config->shadowRegister[TMC262_SMARTEN	| TMC262_WRITE]);
	TMC262.writeInt(TMC262_SGCSCONF, 	TMC262.config->shadowRegister[TMC262_SGCSCONF	| TMC262_WRITE]);
	TMC262.writeInt(TMC262_DRVCONF, 	TMC262.config->shadowRegister[TMC262_DRVCONF	| TMC262_WRITE]);
	return 1;
}

static void standStillCurrentLimitation()
{ // mark if current should be reduced in stand still if 2 high
	static uint8 clear			= 0;
	static uint32 errorTimer 	= 0;

	uint8 stst = TMC262_GET_STST(TMC262.readInt(TMC262_RESPONSE_LATEST));			// request standstill flag

	if(stst && !VitalSignsMonitor.brownOut)											// is stand still
	{
		clear = 0;
		if(TMC262.runCurrentScale > TMC262.standStillCurrentScale)					// current 2 high
		{
			TMC262.isStandStillOverCurrent = 1;										// set overcurrent flag flag

			if(errorTimer++ > TMC262.standStillTimeout/10)							// count timeout
			{
				TMC262.isStandStillCurrentLimit = 1;								// set current limitation flag
				errorTimer 						= 0;								// reset timer
			}
		}
		else clear = 1;
	}
	else clear = 1;

	if(clear == 1)
	{
		TMC262.isStandStillOverCurrent 	= 0;
		TMC262.isStandStillCurrentLimit = 0;
		errorTimer 						= 0;
		clear 							= 0;
	}
}

static void setField(uint8 address, uint32 clearMask, uint32 field)
{	// sets a single field of a write datagram where corresponding bits in clearMasks all bits of this field are high and parameter field gives the value
	uint32 value;
	value = TMC262.readInt(TMC262_WRITE | address);
	value &= ~clearMask;
	value |= field;
	writeInt(address, value);
}


