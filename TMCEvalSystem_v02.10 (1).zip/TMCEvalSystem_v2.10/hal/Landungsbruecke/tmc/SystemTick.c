#include "../../HAL.h"
#include "../../systemTick.h"

static void init();

void __attribute__((interrupt)) SysTick_Handler(void);

SystemTickTypeDef SystemTick =
{
	.init	= init,
	.tick 	= 0
};

void SysTick_Handler(void)
{
	SystemTick.tick++;
}

void init(void)
{
  SYST_RVR	= 48000;
  SYST_CSR	= 7;
}
