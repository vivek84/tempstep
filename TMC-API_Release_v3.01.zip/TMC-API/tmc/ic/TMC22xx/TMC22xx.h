/*
 * TMC22xx.h
 *
 *  Created on: 06.02.2017
 *      Author: OK
 */

#ifndef API_IC_TMC22xx_H
#define API_IC_TMC22xx_H

	#include "../../helpers/API_Header.h"

void tmc22xx_writeRegister(uint8 address, int32 value);
void tmc22xx_readRegister(uint8 address, int32 *value);

#endif
