#ifndef TMCDRIVER_H_
	#define TMCDRIVER_H_

	#include "board.h"

	typedef struct
	{
		void (*init)();
		ConfigurationTypeDef config;
	} EvalBoardDriverTypeDef;

	EvalBoardDriverTypeDef TMCDriver;
#endif
