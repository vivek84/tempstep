#ifndef __WIRELESS_H_
	#define __WIRELESS_H_

	#include "RXTX.h"
	RXTXTypeDef Wireless;
#endif
