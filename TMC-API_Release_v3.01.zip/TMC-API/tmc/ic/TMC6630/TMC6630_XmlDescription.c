
// ===== used for xml file generation =====

// \xml <?xml version="1.0" encoding="UTF-8" standalone="no"?>
// \xml <tmc:product_ic name="TMC6630" version="1.0" author="ed" xmlns:tmc="http://www.trinamic.com" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="https://www.trinamic.com https://www.trinamic.com/fileadmin/xml/TMC_Schema.xsd">
// \xml <desc>Three phase motor control IC.</desc>
// \xml <desc>Sensorless six-step BLDC commutation.</desc>

// \xml <tmc:register_set for="TMC6630" name="All Registers">

// \xml <tmc:group name="Status information"       id="#GROUP_STATUS_INFORMATION#"></tmc:group>
// \xml <tmc:group name="ADCs" 					   id="#GROUP_ADCS#"></tmc:group>
// \xml <tmc:group name="Inputs/Outputs"           id="#GROUP_IO#"></tmc:group>
// \xml <tmc:group name="Sensorless"			   id="#GROUP_SENSORLESS#"></tmc:group>
// \xml <tmc:group name="Operation modes"          id="#GROUP_OPERATION_MODES#"></tmc:group>
// \xml <tmc:group name="PWM_cntl mode"            id="#GROUP_PWM_INPUT#"></tmc:group>
// \xml <tmc:group name="PWM_ext mode"			   id="#GROUP_PWM_MODE#"></tmc:group>
// \xml <tmc:group name="Torque mode"			   id="#GROUP_TORQUE_MODE#"></tmc:group>
// \xml <tmc:group name="Velocity mode"            id="#GROUP_VELOCITY_MODE#"></tmc:group>
// \xml <tmc:group name="Position mode"            id="#GROUP_POSITION_MODE#"></tmc:group>
// \xml <tmc:group name="Integration"			   id="#GROUP_INTEGRATION#"></tmc:group>

// \xml <tmc:value_register address="#TMC6630_CHIPINFO_DATA#" name="CHIPINFO_DATA" size="32" group="#GROUP_STATUS_INFORMATION#">
// \xml    <tmc:register_variant name="Variant 0">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SI_TYPE" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_ascii desc="Hardware type (ASCII)." access="R"></tmc:value_ascii>
// \xml       </tmc:value_register_field>
// \xml       <tmc:register_variant_impacted_by address="#TMC6630_CHIPINFO_ADDR#" shift="0" mask="FFFFFFFF" range_from="0" range_to="0"></tmc:register_variant_impacted_by>
// \xml    </tmc:register_variant>

// \xml    <tmc:register_variant name="Variant 1">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SI_VERSION" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_version desc="Hardware version (u16.u16)." access="R"></tmc:value_version>
// \xml       </tmc:value_register_field>
// \xml       <tmc:register_variant_impacted_by address="#TMC6630_CHIPINFO_ADDR#" shift="0" mask="FFFFFFFF" range_from="1" range_to="1"></tmc:register_variant_impacted_by>
// \xml    </tmc:register_variant>

// \xml    <tmc:register_variant name="Variant 2">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SI_DATE" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_date desc="Hardware date (nibble wise date stamp yyyymmdd)." access="R"></tmc:value_date>
// \xml       </tmc:value_register_field>
// \xml       <tmc:register_variant_impacted_by address="#TMC6630_CHIPINFO_ADDR#" shift="0" mask="FFFFFFFF" range_from="2" range_to="2"></tmc:register_variant_impacted_by>
// \xml    </tmc:register_variant>

// \xml    <tmc:register_variant name="Variant 3">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SI_TIME" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_time desc="Hardware time (nibble wise time stamp --hhmmss)" access="R"></tmc:value_time>
// \xml       </tmc:value_register_field>
// \xml       <tmc:register_variant_impacted_by address="#TMC6630_CHIPINFO_ADDR#" shift="0" mask="FFFFFFFF" range_from="3" range_to="3"></tmc:register_variant_impacted_by>
// \xml    </tmc:register_variant>

// \xml    <tmc:register_variant name="Variant 4">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SI_VARIANT" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:register_variant_impacted_by address="#TMC6630_CHIPINFO_ADDR#" shift="0" mask="FFFFFFFF" range_from="4" range_to="4"></tmc:register_variant_impacted_by>
// \xml    </tmc:register_variant>

// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_CHIPINFO_ADDR#" name="CHIPINFO_ADDR" size="32"  group="#GROUP_STATUS_INFORMATION#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc>Chip info address</desc>
// \xml       <tmc:value_register_field name="CHIP_INFO_ADDRESS" shift="0" mask="000000FF" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="0" desc="SI_TYPE"></choice_element>
// \xml            <choice_element value="1" desc="SI_VERSION"></choice_element>
// \xml            <choice_element value="2" desc="SI_DATE"></choice_element>
// \xml            <choice_element value="3" desc="SI_TIME"></choice_element>
// \xml            <choice_element value="4" desc="SI_VARIANT"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>
// \xml       <tmc:register_variant_impacts address="#TMC6630_CHIPINFO_DATA#"></tmc:register_variant_impacts>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_INPUT_RAW#" name="INPUT_RAW" size="32" group="#GROUP_IO#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>

// \xml       <tmc:value_register_field name="INPUTS_RAW[0]" shift="0" mask="00000001" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[1]" shift="1" mask="00000002" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[2]" shift="2" mask="00000004" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[3]" shift="3" mask="00000008" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[4]" shift="4" mask="00000010" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[5]" shift="5" mask="00000020" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[6]" shift="6" mask="00000040" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[7]" shift="7" mask="00000080" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[8]" shift="8" mask="00000100" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[9]" shift="9" mask="00000200" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[10]" shift="10" mask="00000400" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[11]" shift="11" mask="00000800" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[12]" shift="12" mask="00001000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[13]" shift="13" mask="00002000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[14]" shift="14" mask="00004000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[15]" shift="15" mask="00008000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[16]" shift="16" mask="00010000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[17]" shift="17" mask="00020000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[18]" shift="18" mask="00040000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[19]" shift="19" mask="00080000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[20]" shift="20" mask="00100000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[21]" shift="21" mask="00200000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[22]" shift="22" mask="00400000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[23]" shift="23" mask="00800000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[24]" shift="24" mask="01000000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[25]" shift="25" mask="02000000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[26]" shift="26" mask="04000000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[27]" shift="27" mask="08000000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[28]" shift="28" mask="10000000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[29]" shift="29" mask="20000000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[30]" shift="30" mask="40000000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INPUTS_RAW[31]" shift="31" mask="80000000" desc="---">
// \xml         <tmc:value_bool desc_false="off" desc_true="on" default="false" access="R"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_COMP_RAW_WVU#" name="COMP_RAW_WVU" size="32" group="#GROUP_ADCS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="COMP_RAW_U" shift="0" mask="000003FF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u10_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="COMP_RAW_V" shift="10" mask="000FFC00" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u10_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="COMP_RAW_W" shift="20" mask="3FF00000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u10_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_Z_BLK_CNTS_FILT_LENGTH_NCALC#" name="Z_BLK_CNTS_FILT_LENGTH_NCALC" size="32" group="#GROUP_ADCS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="FILT_LENGTH_NCALC" shift="0" mask="000000FF" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="0" desc="Filter through 1 value (filter off)"></choice_element>
// \xml            <choice_element value="1" desc="Filter through 2 values"></choice_element>
// \xml            <choice_element value="2" desc="Filter through 4 values"></choice_element>
// \xml            <choice_element value="3" desc="Filter through 8 values"></choice_element>
// \xml            <choice_element value="4" desc="Filter through 16 values"></choice_element>
// \xml            <choice_element value="5" desc="Filter through 32 values"></choice_element>
// \xml            <choice_element value="6" desc="Filter through 64 values"></choice_element>
// \xml            <choice_element value="7" desc="Filter through 128 values"></choice_element>
// \xml            <choice_element value="8" desc="Filter through 256 values"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="Z_BLK_CNTS" shift="8" mask="0000FF00" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_ADC_RAW_N_CALCULATED_U_BEMF#" name="ADC_RAW_N_CALCULATED_U_BEMF" size="32" group="#GROUP_ADCS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="U_BEMF" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="ADC_RAW_N_CALCULATED" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_IB_OFFSET_FILT_LENGTH#" name="IB_OFFSET_FILT_LENGTH" size="32" group="#GROUP_ADCS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="FILT_LENGTH_IB" shift="0" mask="000000FF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="8" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="IB_OFFSET" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_DIR_HALL_ACTUAL_ADC_IB#" name="DIR_HALL_ACTUAL_ADC_IB" size="32" group="#GROUP_ADCS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="ADC_IB_FILTERED" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="HALL_ACTUAL" shift="16" mask="00FF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="DIR" shift="24" mask="01000000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_ADCIB_SAMPLEDELAY_MDEC#" name="ADCIB_SAMPLEDELAY_MDEC" size="32" group="#GROUP_ADCS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="ADCIB_MDEC" shift="0" mask="0000FFFF" desc="Decimation divider for IB-dsADC-frontend.">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="ADCIB_SAMPLEDELAY" shift="16" mask="FFFF0000" desc="ampledelay after central sample point (set to 0 for SPI-ADC, set to ADCIB_MDEC/2 for IB-dsADC.">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_OP_MODE#" name="OP_MODE" size="32" group="#GROUP_OPERATION_MODES#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="MOTION_MODE" shift="0" mask="000000FF" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="0" desc="Stop"></choice_element>
// \xml            <choice_element value="1" desc="PWM_CNTL mode"></choice_element>
// \xml            <choice_element value="2" desc="PWM_Ext mode"></choice_element>
// \xml            <choice_element value="4" desc="Torque mode"></choice_element>
// \xml            <choice_element value="8" desc="Velocity mode"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="STOP_MODE" shift="8" mask="0000FF00" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="0" desc="STOP_MODE[0]"></choice_element>
// \xml            <choice_element value="1" desc="STOP_MODE[1]"></choice_element>
// \xml            <choice_element value="2" desc="STOP_MODE[2]"></choice_element>
// \xml            <choice_element value="3" desc="STOP_MODE[3]"></choice_element>
// \xml            <choice_element value="4" desc="STOP_MODE[4]"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="COMMUTATION_MODE" shift="16" mask="00FF0000" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="0" desc="Block"></choice_element>
// \xml            <choice_element value="1" desc="Advanced Trapezoidal"></choice_element>
// \xml            <choice_element value="2" desc="Controlled Sine with ramp generator"></choice_element>
// \xml            <choice_element value="4" desc="Controlled Sine direct"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

//==================== pwm settings ====================

// \xml <tmc:value_register address="#TMC6630_PWM_BBM_CHOP_OPTS#" name="PWM_BBM_CHOP_OPTS" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="USE_EXT_HALL_VALUES" shift="0" mask="00000001" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="USE_DYNAMIC_PWM" shift="1" mask="00000002" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="USE_PWM_LIMIT_DDT" shift="2" mask="00000004" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="USE_AUTO_BLK" shift="3" mask="00000008" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="USE_EXT_GATE_SG" shift="4" mask="00000010" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="EXT_GATE_SG_DIFF_DISABLE" shift="5" mask="00000020" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="PWM_MAXCNTLIM" shift="6" mask="000000C0" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="0" desc="256"></choice_element>
// \xml            <choice_element value="1" desc="1/4 * MAXCNT"></choice_element>
// \xml            <choice_element value="2" desc="1/2 * MAXCNT"></choice_element>
// \xml            <choice_element value="3" desc="3/4 * MAXCNT"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="CHOP_OPTS" shift="8" mask="00000700" desc="">
// \xml          <tmc:value_choice default="2" unit="" access="RW">
// \xml            <choice_element value="0" desc="Centered twisted HS/LS"></choice_element>
// \xml            <choice_element value="1" desc="HS=on, LS=chop"></choice_element>
// \xml            <choice_element value="2" desc="HS=chop, LS=on"></choice_element>
// \xml            <choice_element value="3" desc="HS=chop, LS=chop"></choice_element>
// \xml            <choice_element value="4" desc="Bipolar LS/HS-Chopper"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="PWM_BBM_L" shift="16" mask="00FF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="PWM_BBM_H" shift="24" mask="FF000000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>

// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_MINCNT_MAXCNT#" name="PWM_MINCNT_MAXCNT" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_MAXCNT" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="PWM_MINCNT" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_LIMIT_HIGH_LOW#" name="PWM_LIMIT_HIGH_LOW" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_LIMIT_LOW" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="PWM_LIMIT_HIGH" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_MIN_STALL_VALUE#" name="PWM_MIN_STALL_VALUE" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_MIN_STALL_VALUE" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_MAXCNT_INT_VALUE_INT#" name="PWM_MAXCNT_INT_VALUE_INT" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_VALUE_INT" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="PWM_MAXCNT_INT" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_VALUE_DEBUG#" name="PWM_VALUE_DEBUG" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="REST_DIVISION" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="CNT_PWM_CYCLES" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_VALUE_RELATIV#" name="PWM_VALUE_RELATIV" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_VALUE_RELATIV" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_LIMIT_DDT#" name="PWM_LIMIT_DDT" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_LIMIT_DDT" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_HALL_VALUE_PWM_EXT_VALUE#" name="HALL_VALUE_PWM_EXT_VALUE" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_EXT_VALUE" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="PWM_IN_DIR" shift="16" mask="00010000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="1" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="EXT_HALL_VALUE" shift="24" mask="FF000000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

//==================== sensorless settings ====================

// \xml <tmc:value_register address="#TMC6630_HALL_START_VALUE#" name="HALL_START_VALUE" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="HALL_START_VALUE" shift="0" mask="000000FF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_HALL_NEXT_HALL_ACTUAL_CROSSING#" name="HALL_NEXT_HALL_ACTUAL_CROSSING" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="CROSSING_VALUE" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="HALL_ACTUAL" shift="16" mask="00FF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="HALL_NEXT" shift="24" mask="FF000000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_TRIGGER_PWM_CNT_SG_HALL_STATE#" name="TRIGGER_PWM_CNT_SG_HALL_STATE" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="TRIGGER_HALL_STATE" shift="0" mask="000000FF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="TRIGGER_SIGNAL" shift="8" mask="00000F00" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="0" desc="STALL_BLK-Signal"></choice_element>
// \xml            <choice_element value="1" desc="CHOPPER_ON-Signal"></choice_element>
// \xml            <choice_element value="2" desc="ZERO_CROSSS_WITCH-Signal"></choice_element>
// \xml            <choice_element value="3" desc="BLK_ADAPTIV-Signal"></choice_element>
// \xml            <choice_element value="4" desc="HFL_READY-Signal"></choice_element>
// \xml            <choice_element value="5" desc="COMP_EVAL_READY-Signal"></choice_element>
// \xml            <choice_element value="6" desc="Delayed CHOPPER_ON-Signal"></choice_element>
// \xml            <choice_element value="7" desc="AUTO_BLANK"></choice_element>
// \xml            <choice_element value="8" desc="COMP_DAC"></choice_element>
// \xml            <choice_element value="15" desc="COMP_UVW"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="TRIGGER_INPUT_SIGNAL" shift="12" mask="0000F000" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="1" desc="COMP_U/V/W"></choice_element>
// \xml            <choice_element value="2" desc="COMP_V/W/U"></choice_element>
// \xml            <choice_element value="3" desc="COMP_W/U/V"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="TRIGGER_PWM_CNT" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_SINCOMM_AMPLITUDE_PHI#" name="SINCOMM_AMPLITUDE_PHI" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SINCOMM_PHI" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="SINCOMM_AMPLITUDE" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_SINCOMM_SIN_COS#" name="SINCOMM_SIN_COS" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SINCOMM_COS" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="SINCOMM_SIN" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_SINCOMM_SCALED_U_V_W#" name="SINCOMM_SCALED_U_V_W" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SINCOMM_SCALED_W" shift="0" mask="000003FF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="SINCOMM_SCALED_V" shift="10" mask="000FFC00" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="SINCOMM_SCALED_U" shift="20" mask="3FF00000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_SINCOMM_DIRECT_U_V_W#" name="SINCOMM_DIRECT_U_V_W" size="32" group="#GROUP_PWM_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="SINCOMM_DIRECT_W" shift="0" mask="000003FF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="SINCOMM_DIRECT_V" shift="10" mask="000FFC00" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="SINCOMM_DIRECT_U" shift="20" mask="3FF00000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_CROSSING_OPTS#" name="CROSSING_OPTS" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>

// \xml       <tmc:value_register_field name="USE_HALL_DUR_TARGET" shift="0" mask="00000001" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="ZERO_ADAPT_MODE" shift="1" mask="00000002" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="true" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="CNT_ONLY_FLOAT" shift="2" mask="00000004" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="STALL_PREVENT_EN" shift="3" mask="00000008" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="true" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="USE_EXT_COMP_EVAL" shift="4" mask="00000030" desc="">
// \xml          <tmc:value_choice default="2" unit="" access="RW">
// \xml            <choice_element value="0" desc="CompEval"></choice_element>
// \xml            <choice_element value="1" desc="CompEval with ChopOn"></choice_element>
// \xml            <choice_element value="2" desc="CompEval with ChopOn and considering BBM"></choice_element>
// \xml            <choice_element value="3" desc="CompEval with delayed ChopOn"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="STALL_BLK_LIMIT" shift="6" mask="000000C0" desc="">
// \xml          <tmc:value_choice default="0" unit="" access="RW">
// \xml            <choice_element value="0" desc="BLK_INTEGRAL   > INTEGRAL(A+B)"></choice_element>
// \xml            <choice_element value="1" desc="BLK_INTEGRAL/2 > INTEGRAL(A+B)"></choice_element>
// \xml            <choice_element value="2" desc="BLK_INTEGRAL/4 > INTEGRAL(A+B)"></choice_element>
// \xml            <choice_element value="3" desc="BLK_INTEGRAL/8 > INTEGRAL(A+B)"></choice_element>
// \xml          </tmc:value_choice>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="INTEGRAL_FLT_LENGTH" shift="8" mask="0000FF00" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="ZERO_FILT_LENGTH" shift="16" mask="00FF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="10" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>

// \xml       <tmc:value_register_field name="HALL_DURATION_FILT_LENGTH" shift="24" mask="FF000000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="2" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>

// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_HALL_DUR_EXT#" name="HALL_DUR_EXT" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="HALL_DUR_EXT" shift="0" mask="00FFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u24_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_CROSSING_CNTS_MIN#" name="CROSSING_CNTS_MIN" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="CROSSING_CNTS_MIN" shift="0" mask="00FFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u24_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_CROSSING_CNTS_MAX#" name="CROSSING_CNTS_MAX" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="CROSSING_CNTS_MAX" shift="0" mask="00FFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u24_MAX#" default="2097152" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_CROSSING_FILT#" name="CROSSING_FILT" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="CROSSING_FILT" shift="0" mask="00FFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u24_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_CROSSING_SIGNAL_COUNT#" name="CROSSING_SIGNAL_COUNT" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="CROSSING_COUNT" shift="0" mask="00FFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u24_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="CROSSING_SIGNAL" shift="24" mask="FF000000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_HALL_DUR_P_I#" name="HALL_DUR_P_I" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="HALL_DUR_I" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="HALL_DUR_P" shift="8" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_HALL_DURATION#" name="HALL_DURATION" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="HALL_DURATION" shift="0" mask="00FFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u24_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_HALL_DURATION_PI#" name="HALL_DURATION_PI" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="HALL_DURATION_PI" shift="0" mask="00FFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u24_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

//==================== ??? modes ====================

// \xml <tmc:value_register address="#TMC6630_VELOCITY_PID_OPTS#" name="VELOCITY_PID_OPTS" size="32" group="#GROUP_OPERATION_MODES#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="USE_TORQUE_LIMIT_DDT" shift="0" mask="00000001" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="USE_VELOCITY_LIMIT_DDT" shift="1" mask="00000002" desc="">
// \xml          <tmc:value_bool desc_false="disabled" desc_true="enabled" default="false" access="RW"></tmc:value_bool>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="VELOCITY_FILT_LENGTH" shift="8" mask="0000FF00" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="VELOCITY_FILT_CNT" shift="16" mask="00FF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="POLE_PAIRS" shift="24" mask="FF000000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

//==================== Torque mode ====================

// \xml <tmc:value_register address="#TMC6630_TORQUE_P_I#" name="TORQUE_P_I" size="32" group="#GROUP_TORQUE_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="TORQUE_I" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="TORQUE_P" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_TORQUE_MAX_MIN#" name="TORQUE_MAX_MIN" size="32" group="#GROUP_TORQUE_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="TORQUE_MIN" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="TORQUE_MAX" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_TORQUE_TARGET_LIMIT_DDT#" name="TORQUE_TARGET_LIMIT_DDT" size="32" group="#GROUP_TORQUE_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="TORQUE_LIMIT_DDT" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="TORQUE_TARGET" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_TORQUE_ERROR_PWM_VALUE#" name="TORQUE_ERROR_PWM_VALUE" size="32" group="#GROUP_TORQUE_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="TORQUE_PWM_VALUE" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="TORQUE_ERROR" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_TORQUE_ERROR_SUM#" name="TORQUE_ERROR_SUM" size="32" group="#GROUP_TORQUE_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="TORQUE_ERROR_SUM" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

//==================== VELOCITY mode ====================

// \xml <tmc:value_register address="#TMC6630_VELOCITY_0TIMER#" name="VEL0CITY_0TIMER" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VEL0CITY_0TIMER" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="100000000" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_P_I#" name="VELOCITY_P_I" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_I" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="VELOCITY_P" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#s16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_MAX#" name="VELOCITY_MAX" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_MAX" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_MIN#" name="VELOCITY_MIN" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_MIN" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_LIMIT_DDT#" name="VELOCITY_LIMIT_DDT" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_LIMIT_DDT" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#s32_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_TARGET#" name="VELOCITY_TARGET" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_TARGET" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_ACTUAL#" name="VELOCITY_ACTUAL" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_ACTUAL" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_ERROR#" name="VELOCITY_ERROR" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_ERROR" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_ERROR_SUM#" name="VELOCITY_ERROR_SUM" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_ERROR_SUM" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_TORQUE_TARGET#" name="VELOCITY_TORQUE_TARGET" size="32" group="#GROUP_VELOCITY_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_TORQUE_TARGET" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

//==================== position mode ====================

// \xml <tmc:value_register address="#TMC6630_POSITION_ACTUAL#" name="POSITION_ACTUAL" size="32" group="#GROUP_POSITION_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="POSITION_ACTUAL" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="RW"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_TORQUE_TARGET_LIMIT_DDT_OUT#" name="TORQUE_TARGET_LIMIT_DDT_OUT" size="32" group="#GROUP_POSITION_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="TORQUE_TARGET_LIMIT_DDT_OUT" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_signed min="#s16_MIN#" max="#s16_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_VELOCITY_TARGET_LIMIT_DDT_OUT#" name="VELOCITY_TARGET_LIMIT_DDT_OUT" size="32" group="#GROUP_POSITION_MODE#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="VELOCITY_TARGET_LIMIT_DDT_OUT" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_signed min="#s32_MIN#" max="#s32_MAX#" default="0" unit="" access="R"></tmc:value_signed>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

//==================== PWM input ====================

// \xml <tmc:value_register address="#TMC6630_PWM_CNTL_FILTER_MAXCNT_LENGTH#" name="PWM_CNTL_FILTER_MAXCNT_LENGTH" size="32" group="#GROUP_PWM_INPUT#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_CNTL_FILTER_LENGTH" shift="0" mask="000000FF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u8_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="PWM_CNTL_FILTER_MAXCNT" shift="8" mask="FFFFFF00" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u24_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_CNTL_LIMIT_MAX_SHORT_CNT#" name="PWM_CNTL_LIMIT_MAX_SHORT_CNT" size="32" group="#GROUP_PWM_INPUT#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_CNTL_MAX_SHORT_CNT" shift="0" mask="000FFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u20_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="PWM_CNTL_LIMIT" shift="20" mask="FFF00000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u12_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_CNTL_DUTY_MAX_MIN#" name="PWM_CNTL_DUTY_MAX_MIN" size="32" group="#GROUP_PWM_INPUT#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_CNTL_DUTY_MIN" shift="0" mask="0000FFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="PWM_CNTL_DUTY_MAX" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="RW"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_PWM_CNTL_DUTY_FILTERED_CALC#" name="PWM_CNTL_DUTY_FILTERED_CALC" size="32" group="#GROUP_PWM_INPUT#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="PWM_CNTL_DUTY_FILTERED" shift="16" mask="FFFF0000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_HIGH_FLOAT_LOW#" name="HIGH_FLOAT_LOW" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="LOW" shift="0" mask="000003FF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="FLOAT" shift="10" mask="000FFC00" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml       <tmc:value_register_field name="HIGH" shift="20" mask="3FF00000" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u16_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_INTEGRAL_BLK#" name="INTEGRAL_BLK" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="INTEGRAL_BLK" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_INTEGRAL_BELOW#" name="INTEGRAL_BELOW" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="INTEGRAL_BELOW" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_INTEGRAL_BEYOND#" name="INTEGRAL_BEYOND" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="INTEGRAL_BEYOND" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_INTEGRAL_BELOW_BEYOND#" name="INTEGRAL_BELOW_BEYOND" size="32" group="#GROUP_SENSORLESS#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="INTEGRAL_BELOW_BEYOND" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_CNT01_INTEGRAL_LAST#" name="CNT01_INTEGRAL_LAST" size="32" group="#GROUP_INTEGRATION#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="CNT01_INTEGRAL_LAST" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>

// \xml <tmc:value_register address="#TMC6630_CNT01_INTEGRAL#" name="CNT01_INTEGRAL" size="32" group="#GROUP_INTEGRATION#">
// \xml    <tmc:register_variant name="DEFAULT">
// \xml       <desc></desc>
// \xml       <tmc:value_register_field name="CNT01_INTEGRAL" shift="0" mask="FFFFFFFF" desc="">
// \xml    	     <tmc:value_unsigned min="0" max="#u32_MAX#" default="0" unit="" access="R"></tmc:value_unsigned>
// \xml       </tmc:value_register_field>
// \xml    </tmc:register_variant>
// \xml </tmc:value_register>


// \xml </tmc:register_set>
// \xml </tmc:product_ic>
