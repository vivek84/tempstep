/*
 * TMC2130.h
 *
 *  Created on: 26.01.2017
 *      Author: BS
 */

#ifndef API_IC_TMC2130_H
#define API_IC_TMC2130_H

	#include "../../helpers/API_Header.h"
	#include "TMC2130_Register.h"

	//Factor between 10ms units and internal units for 16MHz
	#define TPOWERDOWN_FACTOR (4.17792*100.0/255.0)
	// TPOWERDOWN_FACTOR = k * 100 / 255 where k = 2^18 * 255 / fClk for fClk = 16000000)

	void tmc2130_writeInt(uint8 Address, int32 Value);
	int32 tmc2130_readInt(uint8 Address);
	void tmc2130_init();
	void tmc2130_rotate(int32 velocity);
	void tmc2130_motorStop();
	void tmc2130_hardStop();
	void tmc2130_moveToAbsolutePosition(int32 position, int32 velocity);
	void tmc2130_moveToRelativePosition(int32 position, int32 velocity, int32 reference);

	// IHold IRun
	void tmc2130_setIHold(uint8 current);
	void tmc2130_setIRun(uint8 current);
	void tmc2130_setIHoldDelay(uint8 delay);
	uint8 tmc2130_getIHold();
	uint8 tmc2130_getIRun();
	uint8 tmc2130_getIHoldDelay();

	// Chopper Conf
	void tmc2130_setStealthChop(uint8 Enable);
	void tmc2130_setChopperMStepRes(uint8 MRes);
	void tmc2130_setChopperMStepInterpolation(uint8 Enable);
	void tmc2130_setChopperVSenseMode(uint8 Mode);
	uint8 tmc2130_getStealthChop();
	uint8 tmc2130_getChopperMStepRes();
	uint8 tmc2130_getChopperMStepInterpolation();
	uint8 tmc2130_getChopperVSenseMode();

	void tmc2130_setChopperTOff(uint8 TOff);
	void tmc2130_setChopperHysteresisStart(uint8 HysteresisStart);
	void tmc2130_setChopperHysteresisEnd(uint8 HysteresisEnd);
	void tmc2130_setChopperBlankTime(uint8 BlankTime);
	void tmc2130_setChopperSync(uint8 Sync);
	void tmc2130_setChopperDisableShortToGround(uint8 Disable);
	void tmc2130_setChopperVHighChm(uint8 VHighChm);
	void tmc2130_setChopperVHighFs(uint8 VHighFs);
	void tmc2130_setChopperConstantTOffMode(uint8 ConstantTOff);
	void tmc2130_setChopperRandomTOff(uint8 RandomTOff);
	void tmc2130_setChopperDisableFastDecayComp(uint8 Disable);
	void tmc2130_setChopperFastDecayTime(uint8 Time);
	void tmc2130_setChopperSineWaveOffset(uint8 Offset);
	uint8 tmc2130_getChopperTOff();
	uint8 tmc2130_getChopperHysteresisStart();
	uint8 tmc2130_getChopperHysteresisEnd();
	uint8 tmc2130_getChopperBlankTime();
	uint8 tmc2130_getChopperSync();
	uint8 tmc2130_getChopperDisableShortToGround();
	uint8 tmc2130_getChopperVHighChm();
	uint8 tmc2130_getChopperVHighFs();
	uint8 tmc2130_getChopperConstantTOffMode();
	uint8 tmc2130_getChopperRandomTOff();
	uint8 tmc2130_getChopperDisableFastDecayComp();
	uint8 tmc2130_getChopperFastDecayTime();
	uint8 tmc2130_getChopperSineWaveOffset();

	// Coolstep Conf
	void tmc2130_setSmartEnergyUpStep(uint8 UpStep);
	void tmc2130_setSmartEnergyDownStep(uint8 DownStep);
	void tmc2130_setSmartEnergyStallLevelMax(uint8 Max);
	void tmc2130_setSmartEnergyStallLevelMin(uint8 Min);
	void tmc2130_setSmartEnergyStallThreshold(int8 Threshold);
	void tmc2130_setSmartEnergyIMin(uint8 IMin);
	void tmc2130_setSmartEnergyFilter(uint8 Filter);
	uint8 tmc2130_getSmartEnergyUpStep();
	uint8 tmc2130_getSmartEnergyDownStep();
	uint8 tmc2130_getSmartEnergyStallLevelMax();
	uint8 tmc2130_getSmartEnergyStallLevelMin();
	int32 tmc2130_getSmartEnergyStallThreshold();
	uint8 tmc2130_getSmartEnergyIMin();
	uint8 tmc2130_getSmartEnergyFilter();

	// PWMConf
	void tmc2130_setPWMFreewheelMode(uint8 Mode);
	void tmc2130_setPWMSymmetric(uint8 Symmetric);
	void tmc2130_setPWMAutoscale(uint8 Autoscale);
	void tmc2130_setPWMFrequency(uint8 Frequency);
	void tmc2130_setPWMGrad(uint8 PWMGrad);
	void tmc2130_setPWMAmpl(uint8 PWMAmpl);
	uint8 tmc2130_getPWMFreewheelMode();
	uint8 tmc2130_getPWMSymmetric();
	uint8 tmc2130_getPWMAutoscale();
	uint8 tmc2130_getPWMFrequency();
	uint8 tmc2130_getPWMGrad();
	uint8 tmc2130_getPWMAmpl();

#endif /* API_IC_TMC2130_H */
