#ifndef __ID_DETECTION
	#define __ID_DETECTION

#if defined(Startrampe)
	#define ID_CLK_LOW() 		GPIOC->BSRRH=BIT9		// set id clk signal to low
	#define ID_CLK_HIGH()   	GPIOC->BSRRL=BIT9		// set id clk signal to high
	#define ID_CLK_STATE		(GPIOC->ODR & BIT9)		// get id clk signal level
	#define ID_CH0_STATE		(GPIOC->IDR & BIT0)		// get id signal level for this channel
	#define ID_CH1_STATE		(GPIOC->IDR & BIT1)		// get id signal level for this channel
#elif defined(Landungsbruecke)
	#define ID_CLK_LOW() 		HAL.IOs->config->setLow(&HAL.IOs->pins->ID_CLK);		// set id clk signal to low
	#define ID_CLK_HIGH()   	HAL.IOs->config->setHigh(&HAL.IOs->pins->ID_CLK);		// set id clk signal to high
#endif

	#define ID_STATE_IDLE		0						// id detection state definitions
	#define ID_STATE_PENDING	1						// id detection pending running
	#define ID_STATE_DONE		2						// id detection finished
	#define ID_STATE_ERROR		3						// id detection failed
	#define ID_STATE_NO_ANSWER	4						// id detection failed because board doesn't answer
	#define ID_STATE_TIMEOUT	5						// id detection failed because of timeout, board id signal went high not low again
	#define ID_STATE_NOT_IN_FW	6						// id detection failed because of board is not in firmware

	#include "boardAssignment.h"

	typedef struct										// struct of information according to id detection
	{
		void (*init)(void);
		void (*deInit)(void);
		uint8 (*detect)(IdAssignmentTypeDef *out);
	} IdDetectionTypeDef;

	IdDetectionTypeDef IdDetection;
#endif
