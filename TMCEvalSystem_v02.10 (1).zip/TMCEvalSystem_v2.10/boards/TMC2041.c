#include "562v3.h"
#include "TMC2041.h"
#include "../tmc/stepDir.h"

static void RotateRight(void);
static void RotateLeft(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void writeRegister(void);
static void readRegister(void);
static void rotate(void);
static void init(void);
static void deInit(void);
static void periodicJob(uint32 tick);
static void userFunction();
static void getMeasuredSpeed(void);

static uint8 reset();
static void enableDriver(uint8 disable0Enable1global2);

#define VM_MIN			50	// VM[V/10] min
#define VM_MAX			280	// VM[V/10] max +10%

typedef struct
{
	IOPinTypeDef *REFL1_STEP1;
	IOPinTypeDef *REFL2_STEP2;
	IOPinTypeDef *REFR1_DIR1;
	IOPinTypeDef *REFR2_DIR2;
	IOPinTypeDef *DRV_ENN;
	IOPinTypeDef *SWIOP;
	IOPinTypeDef *SWION;
	IOPinTypeDef *SWSEL;
	IOPinTypeDef *INT;
	IOPinTypeDef *PP;
	IOPinTypeDef *CSN;
} PinsTypeDef;
static PinsTypeDef Pins;
StepDirectionChannelType 		stepDirDummmy;
EvalBoardTypeDef 				TMC2041 		= {init};
static StepDirectionChannelType *StepDirCh[] 	= {&stepDirDummmy,&stepDirDummmy};

void rotate()
{
  if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
  {
	if(TMCL.command->Type==0)
	{
		StepDirCh[TMCL.command->Motor]->rampMode 		= SD_RAMP_MODE_VELOCITY;
		StepDirCh[TMCL.command->Motor]->targetVelocity 	= TMCL.command->Value.Int32;
	}
	else TMCL.reply->Status=REPLY_WRONG_TYPE;
  }
  else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void RotateRight(void)
{
	rotate();
}

static void RotateLeft(void)
{
	TMCL.command->Value.Int32 = -TMCL.command->Value.Int32;
	rotate();
}

static void MotorStop(void)
{
	TMCL.command->Value.Int32 = 0;
	rotate();
}

static void MoveToPosition(void)
{
	if(TMCL.command->Motor==0)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				StepDirCh[0]->targetPosition	= TMCL.command->Value.Int32;
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
				StepDirCh[0]->useProfile		= 0;
			break;

			case MVP_REL:
				StepDirCh[0]->targetPosition	= StepDirCh[0]->actualPosition+TMCL.command->Value.Int32;
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
				StepDirCh[0]->useProfile		= 0;
			break;

			case MVP_PRF:
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
				StepDirCh[0]->useProfile		= 0;
				StepDirCh[0]->profileFrom		= StepDir.ch1->actualPosition;
				StepDirCh[0]->targetPosition	= StepDirCh[0]->profileFrom;
				StepDirCh[0]->profileTo			= TMCL.command->Value.Int32;
				StepDirCh[0]->useProfile 		= 1;
			break;

			default:
				TMCL.reply->Status			= REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
  uint32 value;

  if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
  {
    switch(TMCL.command->Type)
    {
		case 0:
		  StepDirCh[TMCL.command->Motor]->targetPosition			= TMCL.command->Value.Int32;
		break;

		case 1:
		  StepDirCh[TMCL.command->Motor]->actualPosition			= TMCL.command->Value.Int32;
		break;

		case 2:
		  StepDirCh[TMCL.command->Motor]->targetVelocity			= TMCL.command->Value.Int32;
		break;

		case 4:
		  StepDirCh[TMCL.command->Motor]->maxPositioningSpeed		= abs(TMCL.command->Value.Int32);
		break;

		case 5:
		  StepDirCh[TMCL.command->Motor]->actualAcceleration		= TMCL.command->Value.Int32;
		break;

		case 6:
			value=TMC562V3.readInt(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor));
			TMC562V3.writeDatagram(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor), 0, value >> 16, TMCL.command->Value.Byte[0], value & 0xff);
		break;

		case 7:
			value=TMC562V3.readInt(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor));
			TMC562V3.writeDatagram(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor), 0, value >> 16,
								value >> 8, TMCL.command->Value.Byte[0]);
		break;


		case 21:
			TMC562V3.writeInt(TMC562V3_TZEROWAIT|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
		break;

		case 22:
			TMC562V3.writeInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
		break;

		case 23:
			TMC562V3.writeInt(TMC562V3_VHIGH|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
		break;

		case 24:
			TMC562V3.writeInt(TMC562V3_VDCMIN|MOTOR_ADDR(TMCL.command->Motor), TMCL.command->Value.Int32);
		break;

		case 28:
			value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x01<<18);
			if(TMCL.command->Value.Int32) value |= (0x01<<18);
			TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 140:
			switch(TMCL.command->Value.Int32)
			{
				case 1:	 	TMCL.command->Value.Int32 = 8; break;
				case 2:	 	TMCL.command->Value.Int32 = 7; break;
				case 4:	 	TMCL.command->Value.Int32 = 6; break;
				case 8:	 	TMCL.command->Value.Int32 = 5; break;
				case 16:	TMCL.command->Value.Int32 = 4; break;
				case 32:	TMCL.command->Value.Int32 = 3; break;
				case 64:	TMCL.command->Value.Int32 = 2; break;
				case 128:	TMCL.command->Value.Int32 = 1; break;
				case 256:	TMCL.command->Value.Int32 = 0; break;
				default: 	TMCL.command->Value.Int32 = -1; break;
			}

			if(TMCL.command->Value.Int32 != -1)
			{
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x0F<<24);
				value |= TMCL.command->Value.Int32<<24;
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;
		break;

		case 162:
			value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x03<<15);
			value |= (TMCL.command->Value.Int32 & 0x3) << 15;
			TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 163:
			value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x01<<14);
			if(TMCL.command->Value.Int32) value |= (0x01<<14);
			TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 164:
			value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x01<<12);
			if(TMCL.command->Value.Int32) value |= (0x01<<12);
			TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 165:
			if(TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) & (1<<14))
			{
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x0F<<7);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 7;
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			}
			else
			{
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));

				if(TMCL.command->Value.Int32 & (1<<3)) value |= (0x01<<11);
				else value &= ~(0x01<<11);

				value &= ~(0x07<<4);
				value |=  (TMCL.command->Value.Int32 & 0x0F) << 4;

				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			}
		break;

		case 166:
			if(TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) & (1<<14))
			{
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x07<<4);
				value |= (TMCL.command->Value.Int32 & 0x07) << 4;
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			}
			else
			{
				value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
				value &= ~(0x0F<<7);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 7;
				TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
			}
		break;

		case 167:
			value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x0F<<0);
			value |= (TMCL.command->Value.Int32 & 0x0F) << 0;
			TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 168:
			value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x01<<15);
			if(TMCL.command->Value.Int32) value |= (0x01<<15);
			TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 169:
			value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x03<<13);
			value |= (TMCL.command->Value.Int32 & 0x03) << 13;
			TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 170:
			value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x0F<<8);
			value |= (TMCL.command->Value.Int32 & 0x0F) << 8;
			TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 171:
			value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x03<<5);
			value |= (TMCL.command->Value.Int32 & 0x03) << 5;
			TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 172:
			value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x0F<<0);
			value |= (TMCL.command->Value.Int32 & 0x0F) << 0;
			TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 173:
			value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x01<<24);
			if(TMCL.command->Value.Int32) value |= (0x01<<24);
			TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 174:
			value = TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x07F<<16);
			value |= (TMCL.command->Value.Int32 & 0x07F) << 16;
			TMC562V3.writeInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 179:
			value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x01<<17);
			if(TMCL.command->Value.Int32) value |= (0x01<<17);
			TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 181:
			TMC562V3.writeInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor),TMCL.command->Value.Int32);

			value = TMC562V3.readInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor));
			value &= ~(1<<10);
			TMC562V3.writeInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor), value);
			value |= (TMCL.command->Value.Int32) ? (1<<10) : 0;
			TMC562V3.writeInt(TMC562V3_SWMODE|MOTOR_ADDR(TMCL.command->Motor), value);
		break;

		case 182:
			TMC562V3.writeInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor),TMCL.command->Value.Int32);
		break;

		case 184:
			value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x01<<13);
			if(TMCL.command->Value.Int32) value |= (0x01<<13);
			TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;

		case 185:
			value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
			value &= ~(0x0F<<20);
			value |= (TMCL.command->Value.Int32 & 0x0F) << 20;
			TMC562V3.writeInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor),value);
		break;
      default:
        TMCL.reply->Status=REPLY_WRONG_TYPE;
      break;
    }
  }
  else TMCL.reply->Status=REPLY_WRONG_TYPE;
}

static void GetAxisParameter(void)
{
	uint32 value;
	if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->targetPosition;
			break;

			case 1:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualPosition;
			break;

			case 2:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->targetVelocity;
			break;

			case 3:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualVelocity;
			break;

			case 4:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->maxPositioningSpeed;
			break;

			case 5:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualAcceleration;
			break;

			case 6:
				value=TMC562V3.readInt(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor));
				TMCL.reply->Value.Int32=(value>>8) & 0xff;
			break;

		    case 7:
				value=TMC562V3.readInt(TMC562V3_IHOLD_IRUN|MOTOR_ADDR(TMCL.command->Motor));
				TMCL.reply->Value.Int32=value & 0xff;
			break;

		    case 8:
		        TMCL.reply->Value.Int32 = StepDirCh[0]->targetReached;
			break;

			case 22:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 23:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VHIGH|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 24:
				TMCL.reply->Value.Int32=TMC562V3.readInt(TMC562V3_VDCMIN|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 28:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 18) & 0x01;
			break;

			case 29:
				TMCL.reply->Value.Int32 = StepDir.ch1->actualVelocity;
			break;

			case 140:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 24) & 0x0F;
			break;

			case 162:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 15) & 0x03;
			break;

			case 163:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 14) & 0x01;
			break;

			case 164:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 12) & 0x01;
			break;

			case 165:
				if(TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) & (1<<14))
				{
					TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 7) & 0x0F;
				}
				else
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
					TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 4) & 0x07;
					if(value & (1<<11)) TMCL.reply->Value.Int32 |= 1<<3;
				}
			break;

			case 166:
				if(TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) & (1<<14))
				{
					TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 4) & 0x07;
				}
				else
				{
					value = TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor));
					TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 7) & 0x0F;
					if(value & (1<<11)) TMCL.reply->Value.Int32 |= 1<<3;
				}
			break;

			case 167:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 0) & 0x0F;
			break;

			case 168:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 15) & 0x01;
			break;

			case 169:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 13) & 0x03;
			break;

			case 170:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 8) & 0x0F;
			break;

			case 171:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 5) & 0x03;
			break;

			case 172:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 0) & 0x0F;
			break;

			case 173:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 24) & 0x01;
			break;

			case 174:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_COOLCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 16) & 0xFF;
				TMCL.reply->Value.Int32 |= (TMCL.reply->Value.Int32 & (1<<7)) ? 0xFFFFFF00 : 0;
			break;

			case 179:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 17) & 0x01;
			break;

			case 180:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_DRVSTATUS|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 16) & 0x0FF;
			break;

			case 181:
				TMCL.reply->Value.Int32 = StepDirCh[TMCL.command->Motor]->stopOnStallVelocityTreshold;
			break;

			case 182:
				TMCL.reply->Value.Int32 = TMC562V3.readInt(TMC562V3_VCOOLTHRS|MOTOR_ADDR(TMCL.command->Motor));
			break;

			case 184:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 13) & 0x01;
			break;

			case 185:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_CHOPCONF|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 20) & 0x0F;
			break;

			case 206:
				TMCL.reply->Value.Int32 = (TMC562V3.readInt(TMC562V3_DRVSTATUS|MOTOR_ADDR_DRV(TMCL.command->Motor)) >> 0) & 0x03FF;
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void writeRegister(void)
{
	TMC562V3.writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32=TMC562V3.readInt(TMCL.command->Type);
}

static void periodicJob(uint32 tick)
{
	TMC562V3.periodicJob(tick);

//	if(!StepDir.ch1->stallFlagIn && StepDir.ch1->stopOnStallActive)
//	{
//		TMC562V3.readInt(TMC562V3_DRVSTATUS);
//		if(TMC562V3.readInt(TMC562V3_DRVSTATUS) & (1<<24)) StepDir.ch1->stallFlagIn = 1;
//	}
}

static void userFunction(void)
{
	switch(TMCL.command->Type)
	{
		case 1:		// read interrupt pin INT
			TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.INT))	? 1 : 0;
		break;

		case 2:		// read position compare pin PP
			TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.PP)) 	? 1 : 0;
		break;

		default:
			TMCL.reply->Status=REPLY_WRONG_TYPE;
		break;
	}
}

static void getMeasuredSpeed(void)
{
	switch(TMCL.command->Motor)
	{
		case 0:
			TMCL.reply->Value.Int32 	= StepDir.ch1->actualVelocity;
		break;

		default:
			TMCL.reply->Status 			= REPLY_WRONG_TYPE;
		break;
	}
}

static void init(void)
{
	Pins.DRV_ENN				= &HAL.IOs->pins->DIO0;

	Pins.PP 					= &HAL.IOs->pins->DIO4;
	Pins.INT 					= &HAL.IOs->pins->DIO5;

	Pins.REFL1_STEP1 			= &HAL.IOs->pins->DIO6;
	Pins.REFR1_DIR1				= &HAL.IOs->pins->DIO7;
	Pins.REFL2_STEP2			= &HAL.IOs->pins->DIO8;
	Pins.REFR2_DIR2				= &HAL.IOs->pins->DIO9;

	Pins.CSN	 				= &HAL.IOs->pins->SPI1_CSN;

	HAL.IOs->config->toOutput(Pins.REFL1_STEP1);
	HAL.IOs->config->toOutput(Pins.REFR1_DIR1);
	HAL.IOs->config->toOutput(Pins.REFL2_STEP2);
	HAL.IOs->config->toOutput(Pins.REFR2_DIR2);
	HAL.IOs->config->toOutput(Pins.DRV_ENN);
	HAL.IOs->config->toOutput(Pins.CSN);

	TMC562V3.SPIChannel			= &HAL.SPI->ch1;
	TMC562V3.SPIChannel->CSN 	= Pins.CSN;
	TMC562V3.config				= &TMCDriver.config;

	TMC562V3.writeInt(0x0, TMC562V3.readInt(0) | (3<<1));	// enable step/dir

	StepDir.init();
	StepDirCh[0] 			= StepDir.ch1;
	StepDirCh[0]->stepOut 	= Pins.REFL1_STEP1;
	StepDirCh[0]->dirOut 	= Pins.REFR1_DIR1;

	StepDirCh[1] 			= StepDir.ch2;
	StepDirCh[1]->stepOut 	= Pins.REFL2_STEP2;
	StepDirCh[1]->dirOut 	= Pins.REFR2_DIR2;

	EvalBoards.ch2.config->reset		= reset;
	EvalBoards.ch2.config->restore		= TMC562V3.restore;
	EvalBoards.ch2.config->isBusy 		= 0;
	EvalBoards.ch2.config->ptr	 		= 0;

	EvalBoards.ch2.motorStop			= MotorStop;
	EvalBoards.ch2.getAxisParameter		= GetAxisParameter;
	EvalBoards.ch2.moveToPosition		= MoveToPosition;
	EvalBoards.ch2.rotateLeft			= RotateLeft;
	EvalBoards.ch2.rotateRight			= RotateRight;
	EvalBoards.ch2.setAxisParameter		= SetAxisParameter;
	EvalBoards.ch2.writeRegister		= writeRegister;
	EvalBoards.ch2.readRegister			= readRegister;
	EvalBoards.ch2.periodicJob			= periodicJob;
	EvalBoards.ch2.enableDriver			= enableDriver;
	EvalBoards.ch2.userFunction			= userFunction;
	EvalBoards.ch2.getMeasuredSpeed		= getMeasuredSpeed;
	EvalBoards.ch2.VMMin				= VM_MIN;
	EvalBoards.ch2.VMMax				= VM_MAX;
	EvalBoards.ch2.numberOfMotors		= 2;
	EvalBoards.numberOfMotors			= 2;
	EvalBoards.ch2.deInit				= deInit;

	EvalBoards.ch2.enableDriver(2);

	Timer.init();
	Timer.setDuty(0);
}

static void deInit(void)
{
	HAL.IOs->config->reset(Pins.DRV_ENN);
	HAL.IOs->config->reset(Pins.INT);
	HAL.IOs->config->reset(Pins.PP);

	StepDir.deInit();
	Timer.deInit();
}

static uint8 reset()
{

	if(!VitalSignsMonitor.brownOut)
	{
		if(StepDirCh[0]->actualVelocity && !VitalSignsMonitor.brownOut) return 0;
		if(StepDirCh[0]->actualVelocity && !VitalSignsMonitor.brownOut) return 0;
	}
	TMC562V3.reset();

	StepDir.init();
	StepDirCh[0] 						= StepDir.ch1;
	StepDirCh[0]->stepOut 				= Pins.REFL1_STEP1;
	StepDirCh[0]->dirOut 				= Pins.REFR1_DIR1;

	StepDirCh[1] 						= StepDir.ch1;
	StepDirCh[1]->stepOut 				= Pins.REFL2_STEP2;
	StepDirCh[1]->dirOut 				= Pins.REFR2_DIR2;

	return 1;
}


static void enableDriver(uint8 enable)
{
	if(enable == 2) enable = EvalBoards.driverEnable;

	if(enable ==  0)											HAL.IOs->config->setHigh(Pins.DRV_ENN);
	else if((enable == 1) && (EvalBoards.driverEnable == 1))	HAL.IOs->config->setLow(Pins.DRV_ENN);
}
