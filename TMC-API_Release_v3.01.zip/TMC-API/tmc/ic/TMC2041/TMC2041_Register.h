#ifndef TMC2041_REGISTER_H
#define TMC2041_REGISTER_H

	// ===== TMC2041 register set =====

	#define TMC2041_GCONF        0x00
	#define TMC2041_GSTAT        0x01
	#define TMC2041_IFCNT        0x02
	#define TMC2041_SLAVECONF    0x03
	#define TMC2041_INP_OUT      0x04

	#define TMC2041_IHOLD_IRUN_1 0x30

	#define TMC2041_MSCNT_1      0x6A
	#define TMC2041_MSCURACT_1   0x6B
	#define TMC2041_CHOPCONF_1   0x6C
	#define TMC2041_COOLCONF_1   0x6D
	#define TMC2041_DRVSTATUS_1  0x6F

	#define TMC2041_IHOLD_IRUN_2 0x50

	#define TMC2041_MSCNT_2      0x7A
	#define TMC2041_MSCURACT_2   0x7B
	#define TMC2041_CHOPCONF_2   0x7C
	#define TMC2041_COOLCONF_2   0x7D
	#define TMC2041_DRVSTATUS_2  0x7F

	#define TMC2041_IHOLD_IRUN   0x10

	#define TMC2041_CHOPCONF     0x6C
	#define TMC2041_COOLCONF     0x6D
	#define TMC2041_DRVSTATUS    0x6F

	//Motorbits und Write-Bit
	#define TMC2041_MOTOR0       0x20
	#define TMC2041_MOTOR1       0x40
	#define TMC2041_WRITE        0x80

	#define MOTOR_ADDR(m) (0x20 << m )
	#define MOTOR_ADDR_DRV(m)  (m << 4)

#endif
