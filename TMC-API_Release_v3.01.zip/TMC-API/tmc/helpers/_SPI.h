/*
 * _SPI.h
 *
 *  Created on: Jan 24, 2017
 *      Author: Thomas
 */

#ifndef BOARDS__SPI_H_
#define BOARDS__SPI_H_

//	#include "../hal/hal.h" // Verlinkung in ein anderes Projekt? (ED)
	#include "TypeDefs.h"

	#define SPI_TMC5072 0
	#define SPI_TMC4361 1
	#define SPI_TMC4361_COVER 2

	typedef struct
	{
		uint8 address;
		union
		{
			uint32 int32;
			uint16 word[2];
			uint8 byte[4];
		}value;
	} TDatagram;

	void SPIWriteDatagram(uint8 chip, TDatagram *datagram);
	void SPIReadDatagram(uint8 chip, TDatagram *datagram);

	void SPIWriteBytes(uint8 chip, uint8 address, uint8 x1, uint8 x2, uint8 x3, uint8 x4);

	void SPIWriteInt(uint8 chip, uint8 address, int32 value);

	int32 SPIReadInt(uint8 chip, uint8 address);
	uint8 SPIWrapper(uint8 chip, uint8 value, uint8 lastByte);

#endif /* BOARDS__SPI_H_ */
