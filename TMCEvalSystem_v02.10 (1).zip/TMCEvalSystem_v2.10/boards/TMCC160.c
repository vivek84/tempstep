#include "TMCC160.h"
#include "TMCC160_Registers.h"

#define VM_MIN		50	// VM[V/10] min
#define VM_MAX		280	// VM[V/10] max +10%

static void RotateRight(void);
static void RotateLeft(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void writeRegister(void);
static void handleAxisParameter(void);
static void readRegister(void);
static void periodicJob(uint32 tick);
static void init(void);
static void deInit(void);
static void userFunction(void);
static void getMeasuredSpeed(void);
static uint8 reset();
static uint8 restore();
static void enableDriver(uint8 disable0Enable1global2);

EvalBoardTypeDef TMCC160 = { .init = init };

typedef struct
{
	IOPinTypeDef *DRV_ENN;
} PinsTypeDef;

static PinsTypeDef Pins;
SPIChannelTypeDef *C160_SPIChannel;
ConfigurationTypeDef *C160_config;

#define __NOP 			asm volatile ("nop")

void C160_delay(uint32 nCount)
{
	while(nCount--)
	{
		__NOP;
	}
}

void C160_default_delay()
{
	C160_delay(1550);
}

static void C160_writeDatagram(uint8 address, uint8 x3, uint8 x2, uint8 x1, uint8 x0)
{
	C160_SPIChannel->readWrite(address|0x80, FALSE);
	C160_SPIChannel->readWrite(x3, FALSE);
	C160_SPIChannel->readWrite(x2, FALSE);
	C160_SPIChannel->readWrite(x1, FALSE);
	C160_SPIChannel->readWrite(x0, TRUE);
}

static void C160_writeInt(uint8 address, int value)
{
	C160_SPIChannel->readWrite(address|0x80, FALSE);
	C160_SPIChannel->readWrite(0xFF & (value>>24), FALSE);
	C160_SPIChannel->readWrite(0xFF & (value>>16), FALSE);
	C160_SPIChannel->readWrite(0xFF & (value>>8), FALSE);
	C160_SPIChannel->readWrite(0xFF & (value>>0), TRUE);
}

static int C160_readInt(uint8 address)
{
	// clear write bit
	address &= 0x7f;

	C160_SPIChannel->readWrite(address, FALSE);
	C160_SPIChannel->readWrite(0, FALSE);
	C160_SPIChannel->readWrite(0, FALSE);
	C160_SPIChannel->readWrite(0, FALSE);
	C160_SPIChannel->readWrite(0, TRUE);

	// delay needed!
	C160_default_delay();

	C160_SPIChannel->readWrite(address, FALSE);
	int value	=	C160_SPIChannel->readWrite(0, FALSE);
	value		<<=	8;
	value		|=	C160_SPIChannel->readWrite(0, FALSE);
	value		<<=	8;
	value		|=	C160_SPIChannel->readWrite(0, FALSE);
	value		<<=	8;
	value		|=	C160_SPIChannel->readWrite(0, TRUE);
    return value;
}

static void RotateRight(void)
{
	if(TMCL.command->Motor == 0)
		C160_writeInt(VELOCITY_TARGET_REG_ADDR | 0x80, TMCL.command->Value.Int32);
	else
		TMCL.reply->Status = REPLY_INVALID_VALUE;
}

static void RotateLeft(void)
{
	if(TMCL.command->Motor == 0)
		C160_writeInt(VELOCITY_TARGET_REG_ADDR | 0x80, -TMCL.command->Value.Int32);
	else
		TMCL.reply->Status = REPLY_INVALID_VALUE;
}

static void MotorStop(void)
{
	if(TMCL.command->Motor == 0)
		C160_writeInt(VELOCITY_TARGET_REG_ADDR | 0x80, 0);
	else
		TMCL.reply->Status = REPLY_INVALID_VALUE;
}
static void MoveToPosition(void)
{
	if(TMCL.command->Motor == 0)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				C160_writeInt(POSITION_TARGET_ABS_REG_ADDR | 0x80, TMCL.command->Value.Int32);
				break;
			case MVP_REL:
				C160_writeInt(POSITION_TARGET_REL_REG_ADDR | 0x80,  TMCL.command->Value.Int32);
				break;
			default:
				TMCL.reply->Status = REPLY_WRONG_TYPE;
				break;
		}
	}
	else
	{
		TMCL.reply->Status = REPLY_INVALID_VALUE;
	}
}

static void handleAxisParameter(void)
{
	// --- write tmcl data ---

	// write Byte 0..3
	C160_writeDatagram(TMCL_REQUEST_BYTE_0123_REG_ADDR | 0x80, TMCL.command->Opcode, TMCL.command->Type, TMCL.command->Motor, TMCL.command->Error);
	C160_default_delay();

	// write Byte 4..7
	C160_writeInt(TMCL_REQUEST_BYTE_4567_REG_ADDR | 0x80, TMCL.command->Value.Int32);
	C160_default_delay();

	// spend extra time for STAP/RSAP commands (because EEProm access)
	if ((TMCL.command->Opcode == TMCL_STAP) || TMCL.command->Opcode == TMCL_RSAP)
	{
		int i;
		for (i = 0; i < 10; i++)
			C160_default_delay();
	}

	// --- read tmcl data ---

	// read Byte 0..3
	int reply = C160_readInt(TMCL_REPLY_BYTE_0123_REG_ADDR);
	TMCL.reply->Status = (reply) & 0xFF;
	TMCL.reply->Opcode = (reply >> 24) & 0xFF;
	C160_default_delay();

	// read Byte 4..7
	TMCL.reply->Value.Int32	= C160_readInt(TMCL_REPLY_BYTE_4567_REG_ADDR);
	C160_default_delay();
}

static void getMeasuredSpeed(void) {}

static void writeRegister(void)
{
	C160_writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32	= C160_readInt(TMCL.command->Type);
}

static void periodicJob(uint32 tick)
{
	UNUSED(tick);
}

static void userFunction(void) {}

static void init(void)
{
	Pins.DRV_ENN		= &HAL.IOs->pins->DIO0;		// ENABLE CC160

	HAL.IOs->config->toOutput(Pins.DRV_ENN);
	HAL.IOs->config->setHigh(Pins.DRV_ENN);

	C160_SPIChannel		 = &HAL.SPI->ch1;
	C160_SPIChannel->CSN = &HAL.IOs->pins->SPI1_CSN;
	C160_config			 = EvalBoards.ch1.config;

	EvalBoards.ch2.config->isBusy		= 0;
	EvalBoards.ch2.config->reset		= reset;
	EvalBoards.ch2.config->restore		= restore;
	EvalBoards.ch2.motorStop			= MotorStop;
	EvalBoards.ch2.moveToPosition		= MoveToPosition;
	EvalBoards.ch2.rotateLeft			= RotateLeft;
	EvalBoards.ch2.rotateRight			= RotateRight;
	EvalBoards.ch2.setAxisParameter		= handleAxisParameter;
	EvalBoards.ch2.getAxisParameter		= handleAxisParameter;
	EvalBoards.ch2.storeAxisParameter	= handleAxisParameter;
	EvalBoards.ch2.restoreAxisParameter	= handleAxisParameter;
	EvalBoards.ch2.writeRegister		= writeRegister;
	EvalBoards.ch2.readRegister			= readRegister;
	EvalBoards.ch2.periodicJob			= periodicJob;
	EvalBoards.ch2.init					= init;
	EvalBoards.ch2.deInit				= deInit;
	EvalBoards.ch2.getMeasuredSpeed		= getMeasuredSpeed;
	EvalBoards.ch2.enableDriver			= enableDriver;
	EvalBoards.ch2.userFunction			= userFunction;
	EvalBoards.ch2.numberOfMotors		= 1;
	EvalBoards.numberOfMotors			= 1;
	EvalBoards.ch2.VMMin				= VM_MIN;
	EvalBoards.ch2.VMMax				= VM_MAX;
	enableDriver(1);
};

static void deInit(void)
{
	enableDriver(0);
	HAL.IOs->config->reset(Pins.DRV_ENN);
};

static uint8 reset()
{
	// todo: RESET/REBOOT _REGISTER schreiben
	return 1;
}

static uint8 restore()
{
	return 1;
}

static void enableDriver(uint8 enable) // enable = {disable:0|enable:1|global:2)
{
	if(enable == 2) enable = EvalBoards.driverEnable;

	if(enable ==  0)
		HAL.IOs->config->setLow(Pins.DRV_ENN);
	else if((enable == 1) && (EvalBoards.driverEnable == 1))
		HAL.IOs->config->setHigh(Pins.DRV_ENN);
}
