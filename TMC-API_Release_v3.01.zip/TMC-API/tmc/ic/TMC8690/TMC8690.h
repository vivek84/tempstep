/*
 * TMC8690.h
 *
 *  Created on: 18.07.2016
 *      Author: bs, ed
 */

#ifndef API_IC_TMC8690_H
#define API_IC_TMC8690_H

	#include "../../helpers/API_Header.h"
	#include "TMC8690_Register.h"

//	void tmc8690_init();
//	void tmc8690_periodicJob(u32 actualSystick);

#endif /* API_IC_TMC8690_H_ */
