#include "562.h"


#define R30 0x00<<24 	| 0x07<<16	| 0x17<<8	| 0x03			// not reset but preconfiguration
#define R32 0xFFFFFF
#define R3A 65536
#define R60 0b10101010101010101011010101010100
#define R61 0b01001010100101010101010010101010
#define R62 0b00100100010010010010100100101001
#define R63 0b00010000000100000100001000100010
#define R64 0b11111011111111111111111111111111
#define R65 0b10110101101110110111011101111101
#define R66 0b01001001001010010101010101010110
#define R67 0b00000000010000000100001000100010
#define R68 255<<24 	| 255<<16 	| 0x80<<8 	| 0b01010110
#define R69 247<<16
#define R6C 0x00<<24 	| 0x01<<16	| 0x01<<8	| 0xd5			// not reset but preconfiguration

static void writeDatagram(uint8 address, uint8 x1, uint8 x2, uint8 x3, uint8 x4);
static void writeInt(uint8 Address, int Value);
static int readInt(uint8 address);
static void periodicJob(uint32 tick);
static uint8 reset();
static uint8 restore();
static void writeConfiguration();

TMC562TypeDef TMC562 =
{
	.SPIChannel				= &SPI.ch1,
	.velocityMotor1			= 1,
	.velocityMotor2			= 2,
	.periodicJob			= periodicJob,
	.writeDatagram			= writeDatagram,
	.writeInt				= writeInt,
	.readInt				= readInt,
	.reset					= reset,
	.restore				= restore,
	.registerAccess			=
	{
	// access
	// none :	0
	// r 	:	1
	// w 	: 	2
	// rw 	: 	3
	// r/w 	: 	7

	//	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F
		3, 1, 1, 2, 7, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//00..0f
		2, 1, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0,    	//10..1f

		3, 3, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 0, 0,    	//20..2f
		2, 2, 2, 2, 3, 1, 1, 0, 3, 3, 2, 1, 1, 0, 0, 0,    	//30..3f
		3, 3, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 0, 0,    	//40..2f
		2, 2, 2, 2, 3, 1, 1, 0, 3, 3, 2, 1, 1, 0, 0, 0,    	//50..3f

		2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 3, 2, 2, 1,    	//60..6f
		2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 3, 2, 2, 1		//70..7f
	},

	.registerResetState		=
	{
	//	0,   1,   2,   3,   4,   5,   6,   7,   8,   9,   A,   B,   C,   D,   E,   F
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //00..0f
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //10..1f
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //20..2f
		R30, 0,   R32, 0,   0,   0,   0,   0,   0,   0,   R3A, 0,   0,   0,   0,   0,   //30..3f
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //40..4f
		R30, 0,   R32, 0,   0,   0,   0,   0,   0,   0,   R3A, 0,   0,   0,   0,   0,   //50..5f
		R60, R61, R62, R63, R64, R65, R66, R67, R68, R69, 0,   0,   R6C, 0,   0,   0,   //60..6f
		R60, R61, R62, R63, R64, R65, R66, R67, R68, R69, 0,   0,   R6C, 0,   0,   0   	//70..7f
	}
};

static void writeDatagram(uint8 address, uint8 x1, uint8 x2, uint8 x3, uint8 x4)
{
  int value;

  TMC562.SPIChannel->readWrite(address|0x80, FALSE);
  TMC562.SPIChannel->readWrite(x1, FALSE);
  TMC562.SPIChannel->readWrite(x2, FALSE);
  TMC562.SPIChannel->readWrite(x3, FALSE);
  TMC562.SPIChannel->readWrite(x4, TRUE);

  value	=	x1;
  value	<<=	8;
  value	|=	x2;
  value	<<=	8;
  value	|=	x3;
  value	<<=	8;
  value	|=	x4;
  TMC562.config->shadowRegister[address & 0x7f] = value;
}

static void writeInt(uint8 Address, int Value)
{
	writeDatagram(Address, 0xFF & (Value>>24), 0xFF & (Value>>16), 0xFF & (Value>>8), 0xFF & (Value>>0));
}

static int readInt(uint8 address)
{
  int value;

  address &= 0x7f;
  if(!(TMC562.registerAccess[address] & 1) && !(TMC562.registerAccess[address] & 4))  return TMC562.config->shadowRegister[address];	// register not readable -> softwarecopy

	TMC562.SPIChannel->readWrite(address, FALSE);
	TMC562.SPIChannel->readWrite(0, FALSE);
	TMC562.SPIChannel->readWrite(0, FALSE);
	TMC562.SPIChannel->readWrite(0, FALSE);
	TMC562.SPIChannel->readWrite(0, TRUE);

	TMC562.SPIChannel->readWrite(address, FALSE);
	value	=	TMC562.SPIChannel->readWrite(0, FALSE);
	value	<<=	8;
	value	|=	TMC562.SPIChannel->readWrite(0, FALSE);
	value	<<=	8;
	value	|=	TMC562.SPIChannel->readWrite(0, FALSE);
	value	<<=	8;
	value	|=	TMC562.SPIChannel->readWrite(0, TRUE);

    if((address==0x22 || address==0x42)	&& (value & BIT23)) value|=0xff000000;

    return value;
}

static void periodicJob(uint32 tick)
{
	// mesure speed
	// store xactual
	// trigger sequetial reset

	int
		xActual,t;

	static int
		oldTick	= 0,
		oldX[]	= {0,0};

	if(TMC562.config->isBusy)
	{
		writeConfiguration();
		return;
	}

	if((t = abs(tick-oldTick)) >= 5)
	{
		VitalSignsMonitor.checkVitalSigns(tick);
		xActual	= readInt(TMC562_XACTUAL_1);
		if(!VitalSignsMonitor.brownOut) TMC562.config->shadowRegister[TMC562_XACTUAL_1] = xActual;
		TMC562.velocityMotor1 = (int) ((float) (abs(xActual-oldX[0]) / (float) t) 	* (float) 1048.576);
		if(readInt(TMC562_VACTUAL_1)<0) TMC562.velocityMotor1 *= -1;
		oldX[0]	= xActual;

		xActual	= readInt(TMC562_XACTUAL_2);
		if(!VitalSignsMonitor.brownOut) TMC562.config->shadowRegister[TMC562_XACTUAL_2] = xActual;
		TMC562.velocityMotor2 = (int) ((float) (abs(xActual-oldX[1]) / (float) t)	* (float) 1048.576);
		if(readInt(TMC562_VACTUAL_2)<0) TMC562.velocityMotor2 *= -1;
		oldX[1]	= xActual;

		oldTick=tick;
	}
}

static uint8 reset()
{
	if(TMC562.config->isBusy) return 0;
	TMC562.config->isBusy 			= 1;
	TMC562.config->ptr	 			= 0;
	return 1;
}

static uint8 restore()
{
	if(TMC562.config->isBusy) return 0;
	TMC562.config->isBusy 			= 2;
	TMC562.config->ptr	 			= 0;
	return 1;
}

static void writeConfiguration()
{
	uint8 *ptr			= &TMC562.config->ptr;
	const int32 *settings	= (TMC562.config->isBusy == 2) ? TMC562.config->shadowRegister : TMC562.registerResetState;

	while(!(TMC562.registerAccess[*ptr]&2) && (*ptr<128)) (*ptr)++;
	if(*ptr<128)
	{
		TMC562.writeInt(*ptr, settings[*ptr]);
		(*ptr)++;
	}
	else
	{
		if(TMC562.config->isBusy&1) 		TMC562.config->resetCallBack();
		else if(TMC562.config->isBusy&2)	TMC562.config->restoreCallBack();
		TMC562.config->isBusy = 0;
	}
}
