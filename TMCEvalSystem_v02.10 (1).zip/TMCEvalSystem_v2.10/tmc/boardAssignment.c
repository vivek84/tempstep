#include "../hal/derivative.h"
#include "../hal/HAL.h"

#include "boardAssignment.h"
#include "TMCL.h"
#include "idDetection.h"

#include "../boards/SelfTest.h"
#include "../boards/board.h"

#include "../boards/262.h"
#include "../boards/TMC2660.h"

#include "../boards/TMC2100.h"
#include "../boards/TMC2130.h"
#include "../boards/TMC5130.h"
#include "../boards/TMC2130_TQFP48.h"

#include "../boards/TMC5041.h"
#include "../boards/TMC5072.h"
#include "../boards/TMC5031.h"
#include "../boards/TMC5062.h"

#include "../boards/squirrel.h"
#include "../boards/TMC4361.h"
#include "../boards/TMC4331.h"

#include "../boards/TMCC160.h"

static int32 assign(IdAssignmentTypeDef *ids);
static int32 supported(IdAssignmentTypeDef *ids);
static uint8 assignCh1(uint8 id, uint8 justCheck);
static uint8 assignCh2(uint8 id, uint8 justCheck);
static void assigned_(IdAssignmentTypeDef *ids);
static void assigned_ch2(IdAssignmentTypeDef *ids);
static void assigned_ch2_ch1(IdAssignmentTypeDef *ids);
static void unassign(IdAssignmentTypeDef *ids);
static void periodicJob(unsigned int timeStamp);
static void deInit(void);

BoardAssignmentTypeDef BoardAssignment =
{
	.assign 		= assign,
	.supported 		= supported,
	.periodicJob	= periodicJob,
	.deInit			= deInit
};


static int32 assign(IdAssignmentTypeDef *ids)
{
	int32 out = 0;

	if((ids->ch1.id == 0xFF) || (ids->ch2.id == 0xFF))	// testMode
	{
		if((EvalBoards.ch1.id != 0) || (EvalBoards.ch2.id != 0) || (ids->ch1.id != ids->ch2.id))
		{
			ids->ch1.state = ID_STATE_NOT_IN_FW;
			ids->ch2.state = ID_STATE_NOT_IN_FW;
			out |= ids->ch2.state	<< 24;
			out |= ids->ch2.id		<< 16;
			out |= ids->ch1.state	<< 8;
			out |= ids->ch1.id		<< 0;
			return out;
		}
	}

	assigned_(ids);

	if((EvalBoards.ch2.id == ids->ch2.id) && (ids->ch2.id != 0)) ids->ch2.state = assignCh2(ids->ch2.id, 1);
	else
	{
		EvalBoards.ch2.deInit();
		ids->ch2.state = (ids->ch2.state == 2) ? assignCh2(ids->ch2.id, 0) : ids->ch2.state;
		EvalBoards.ch2.config->reset();
	}

	assigned_ch2(ids);

	if((EvalBoards.ch1.id == ids->ch1.id) && (ids->ch1.id != 0)) ids->ch1.state = assignCh1(ids->ch1.id, 1);
	else
	{
		EvalBoards.ch1.deInit();
		ids->ch1.state = (ids->ch1.state == 2) ? assignCh1(ids->ch1.id, 0) : ids->ch1.state;
		EvalBoards.ch1.config->reset();
	}

	assigned_ch2_ch1(ids);

	EvalBoards.ch1.id = ids->ch1.id;
	EvalBoards.ch2.id = ids->ch2.id;

	out |= (ids->ch2.state	<< 24)	& 0xFF;
	out |= (ids->ch2.id		<< 16) 	& 0xFF;
	out |= (ids->ch1.state	<< 8) 	& 0xFF;
	out |= (ids->ch1.id		<< 0) 	& 0xFF;

	return out;
}

static int32 supported(IdAssignmentTypeDef *ids)
{
	int32 out = 0;
	ids->ch1.state = assignCh1(ids->ch1.id, 1);
	ids->ch2.state = assignCh2(ids->ch2.id, 1);

	out |= ids->ch2.state	<< 24;
	out |= ids->ch2.id		<< 16;
	out |= ids->ch1.state	<< 8;
	out |= ids->ch1.id		<< 0;
	return out;
}

static uint8 assignCh1(uint8 id, uint8 justCheck)
{
	uint8 ok = ID_STATE_DONE;
	if(!justCheck) TMCMotionController.init();

	switch(id)
	{
		case ID_TMC5041:  			if(!justCheck) TMC5041.init(); 				break;
		case ID_TMC5072:  			if(!justCheck) TMC5072.init(); 				break;
		case ID_TMC5031:  			if(!justCheck) TMC5031.init(); 				break;
		case ID_TMC5062:  			if(!justCheck) TMC5062.init(); 				break;

		case ID_TMC5130:  			if(!justCheck) TMC5130.init(); 				break;

		case ID_TMC4361:  			if(!justCheck) TMC4361.init(); 				break;
		case ID_TMC4331:  			if(!justCheck) TMC4331.init(); 				break;

		case ID_TMC2130_TQFP48:  	if(!justCheck) TMC2130_TQFP48.init(); 		break;

		case ID_SELFTEST:			if(!justCheck) SelfTest.init(); 	break;
		default:	ok = ID_STATE_NOT_IN_FW;	break;
	}
	return ok;
}

static uint8 assignCh2(uint8 id, uint8 justCheck)
{
	uint8 ok = ID_STATE_DONE;

	if(!justCheck) TMCDriver.init();

	switch(id)
	{
		case ID_TMC2100: 	if(!justCheck) TMC2100.init(); 				break;
		case ID_TMC2130: 	if(!justCheck) TMC2130.init(); 				break;
		case ID_TMC2660: 	if(!justCheck) TMC2660.init(); 				break;
		case ID_TMCC160:	if(!justCheck) TMCC160.init();				break;
		default:	ok = ID_STATE_NOT_IN_FW;							break;
	}
	return ok;
}

static void assigned_(IdAssignmentTypeDef *ids)
{
	UNUSED(ids);
}

static void assigned_ch2(IdAssignmentTypeDef *ids)
{
	UNUSED(ids);
}

static void assigned_ch2_ch1(IdAssignmentTypeDef *ids)
{
	if((ids->ch1.id == ID_TMC4361) || (ids->ch1.id == ID_TMC4331))
	{
		if(ids->ch2.id == (uint8) ID_TMC2660)
		{
			TMC262.continuosModeEnable = 0;
			EvalBoards.ch2.periodicJob = TMCDummy.periodicJob;
		}

		SPI.ch2.readWrite	= TMCSquirrel.cover;
		EvalBoards.ch2.config->reset();
	}
}

static void unassign(IdAssignmentTypeDef *ids)
{
	switch(ids->ch1.id)
	{
		default: 														break;
	}
}

static void periodicJob(unsigned int tick)
{
	UNUSED(tick);
}

static void deInit(void)
{
	IdAssignmentTypeDef ids;
	EvalBoards.ch1.deInit();
	EvalBoards.ch2.deInit();

	ids.ch1.id = EvalBoards.ch1.id;
	ids.ch2.id = EvalBoards.ch2.id;
	unassign(&ids);

	TMCDriver.init();
	TMCMotionController.init();
}
