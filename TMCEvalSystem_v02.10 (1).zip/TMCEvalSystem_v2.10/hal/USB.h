#ifndef __USB_H
	#define __USB_H

	#include "RXTX.h"
	RXTXTypeDef USB;
#endif
