#include "rhino_standalone.h"
#include "TMC2100.h"
#include "../tmc/stepDir.h"
#include "../hal/Timer.h"


static void RotateRight(void);
static void RotateLeft(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void writeRegister(void);
static void readRegister(void);
static void rotate(void);
static void init(void);
static void deInit(void);
static void setStandAloneSettings(uint8 i);
static void getStandAloneSettings(uint8 i);

static uint8 reset();

static void enableDriver(uint8 disable0Enable1global2);
static enum IOS_STATES lastEnable = IOS_OPEN; //TMCRhinoSA.Enable_StandStillPowerDownSettings.ENABLED_034;

typedef struct
{
	IOPinTypeDef *CFG3;
	IOPinTypeDef *CFG2;
	IOPinTypeDef *CFG1;
	IOPinTypeDef *CFG0;
	IOPinTypeDef *STEP;
	IOPinTypeDef *DIR;
	IOPinTypeDef *CFG4;
	IOPinTypeDef *CFG5;
	IOPinTypeDef *ERROR;
	IOPinTypeDef *INDEX;
	IOPinTypeDef *CFG6_ENN;
	IOPinTypeDef *AIN_SW;
	IOPinTypeDef *AIN_PWM;

} PinsTypeDef;

static PinsTypeDef Pins;
StepDirectionChannelType 		stepDirDummmy;
EvalBoardTypeDef 				TMC2100 		= {init};
static StepDirectionChannelType *StepDirCh[] 	= {&stepDirDummmy};

void rotate()
{
  if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
  {
	if(TMCL.command->Type==0)
	{
		StepDirCh[TMCL.command->Motor]->rampMode 		= SD_RAMP_MODE_VELOCITY;
		StepDirCh[TMCL.command->Motor]->targetVelocity 	= TMCL.command->Value.Int32;
	}
	else TMCL.reply->Status=REPLY_WRONG_TYPE;
  }
  else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void RotateRight(void)
{
	TMCL.command->Value.Int32 = -TMCL.command->Value.Int32;
	rotate();
}

static void RotateLeft(void)
{
	rotate();
}

static void MotorStop(void)
{
	TMCL.command->Value.Int32 = 0;
	rotate();
}

static void MoveToPosition(void)
{
	if(TMCL.command->Motor==0)
	{
		switch(TMCL.command->Type)
		{
		case MVP_ABS:
			StepDirCh[0]->targetPosition	= TMCL.command->Value.Int32;
			StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
			StepDirCh[0]->useProfile		= 0;
		break;

		case MVP_REL:
			StepDirCh[0]->targetPosition	= StepDirCh[0]->actualPosition+TMCL.command->Value.Int32;
			StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
			StepDirCh[0]->useProfile		= 0;
		break;

			default:
				TMCL.reply->Status			= REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
	if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				StepDirCh[TMCL.command->Motor]->targetPosition			= TMCL.command->Value.Int32;
			break;

			case 1:
				StepDirCh[TMCL.command->Motor]->actualPosition			= TMCL.command->Value.Int32;
			break;

			case 2:
				StepDirCh[TMCL.command->Motor]->targetVelocity			= TMCL.command->Value.Int32;
			break;

			case 3:
				StepDirCh[TMCL.command->Motor]->actualVelocity			= TMCL.command->Value.Int32;
			break;

			case 4:
				StepDirCh[TMCL.command->Motor]->maxPositioningSpeed		= abs(TMCL.command->Value.Int32);
			break;

			case 5:
				StepDirCh[TMCL.command->Motor]->actualAcceleration		= TMCL.command->Value.Int32;
			break;

			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
			case 11:
				setStandAloneSettings(TMCL.command->Type-6);
			break;

			case 12:
				if(TMCL.command->Value.Int32) HAL.IOs->config->setHigh(Pins.AIN_SW);
				else HAL.IOs->config->setLow(Pins.AIN_SW);
			break;

			case 13:
				if(((uint32) TMCL.command->Value.Int32) > 10000)
				{
					TMCL.reply->Status = REPLY_INVALID_VALUE;
					return;
				}
				Timer.setDuty(TMCL.command->Value.Int32);
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_WRONG_TYPE;
}

static void GetAxisParameter(void)
{
	if(TMCL.command->Motor<EvalBoards.ch2.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->targetPosition;
			break;

			case 1:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualPosition;

			break;

			case 2:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->targetPosition;
			break;

			case 3:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualVelocity;
			break;

			case 4:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->maxPositioningSpeed;
			break;

			case 5:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualAcceleration;
			break;

		    case 8:
		    	TMCL.reply->Value.Int32 = StepDirCh[0]->targetReached;
			break;


			case 12:
				TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.AIN_SW)) ? 1 : 0;
			break;

			case 13:
				TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.AIN_PWM)) ? 1 : 0;
			break;


			case 14:
			case 15:
			case 16:
			case 17:
			case 18:
			case 19:
				getStandAloneSettings(TMCL.command->Type-14);
			break;

			case 140: // microstep resolution without interpolation

				getStandAloneSettings(1);


				enum IOS_STATES CFG[7];

				TMCRhinoSA.getPins(&CFG);

				if(0);
				else if((CFG[2] == LOW)		&& (CFG[1] == LOW)) 	TMCL.reply->Value.Int32 = 1;
				else if((CFG[2] == LOW) 	&& (CFG[1] == HIGH))	TMCL.reply->Value.Int32 = 2;
				else if((CFG[2] == LOW) 	&& (CFG[1] == OPEN)) 	TMCL.reply->Value.Int32 = 2;
				else if((CFG[2] == HIGH) 	&& (CFG[1] == LOW)) 	TMCL.reply->Value.Int32 = 4;
				else if((CFG[2] == HIGH) 	&& (CFG[1] == HIGH)) 	TMCL.reply->Value.Int32 = 16;
				else if((CFG[2] == HIGH) 	&& (CFG[1] == OPEN)) 	TMCL.reply->Value.Int32 = 4;
				else if((CFG[2] == OPEN) 	&& (CFG[1] == LOW)) 	TMCL.reply->Value.Int32 = 16;
				else if((CFG[2] == OPEN) 	&& (CFG[1] == HIGH)) 	TMCL.reply->Value.Int32 = 4;
				else if((CFG[2] == OPEN) 	&& (CFG[1] == OPEN)) 	TMCL.reply->Value.Int32 = 16;

			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void writeRegister(void)
{
	TMCRhinoSA.setInt(TMCL.command->Value.Int32);
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32 = TMCRhinoSA.getInt();
}

static void setStandAloneSettings(uint8 i)
{
	TMCRhinoTypeStandAloneConfigDef config;

	if(i > 6)
	{
		TMCL.reply->Status = REPLY_WRONG_TYPE;
		return;
	}

	if((TMCL.command->Value.Int32 < 0) || (TMCL.command->Value.Int32 > 2))
	{
		if((i!=1) || (TMCL.command->Value.Int32 > 0x0F))
		{
			TMCL.reply->Status = REPLY_INVALID_VALUE;
			return;
		}
	}

	TMCRhinoSA.getConfig(&config);

	switch(i)
	{
		case 0:
			config.chopperOffTime 				= TMCL.command->Value.Int32;
		break;

		case 1:
			switch(TMCL.command->Value.Int32)
			{
				case 0:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.BY1_INTERPOL0;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.BY1_INTERPOL0;
				break;
				case 1:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.BY2_INTERPOL0;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.BY2_INTERPOL0;
				break;
				case 2:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.BY2_INTERPOL256;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.BY2_INTERPOL256;
				break;
				case 3:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.BY4_INTERPOL0;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.BY4_INTERPOL0;
				break;
				case 4:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.BY4_INTERPOL256;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.BY4_INTERPOL256;
				break;
				case 5:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.BY16_INTERPOL0;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.BY16_INTERPOL0;
				break;
				case 6:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.BY16_INTERPOL256;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.BY16_INTERPOL256;
				break;
				case 7:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.PWM_CHOP_BY4_INTERPOL256;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.PWM_CHOP_BY4_INTERPOL256;
				break;
				case 8:
					config.microsteResolution1 = TMCRhinoSA.MicrosteResolutionSettings1.PWM_CHOP_BY16_INTERPOL256;
					config.microsteResolution2 = TMCRhinoSA.MicrosteResolutionSettings2.PWM_CHOP_BY16_INTERPOL256;
				break;
			}
		break;

		case 2:
			config.currentSetting 				= TMCL.command->Value.Int32;
		break;

		case 3:
			config.chopperHysteresis 			= TMCL.command->Value.Int32;
		break;

		case 4:
			config.chopperBlankTime 			= TMCL.command->Value.Int32;
		break;

		case 5:
			config.enable_StandStillPowerDown 	= lastEnable = TMCL.command->Value.Int32;
		break;
	}

	TMCRhinoSA.setConfig(&config);

}

static void getStandAloneSettings(uint8 i)
{
	TMCRhinoTypeStandAloneConfigDef config;

	if(i > 6)
	{
		TMCL.reply->Status = REPLY_WRONG_TYPE;
		return;
	}

	TMCRhinoSA.getConfig(&config);

	switch(i)
	{
		case 0:
			TMCL.reply->Value.Int32 = config.chopperOffTime;
		break;

		case 1:
			if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.BY1_INTERPOL0)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.BY1_INTERPOL0)
			) TMCL.reply->Value.Int32 = 0;
			else if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.BY2_INTERPOL0)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.BY2_INTERPOL0)
			) TMCL.reply->Value.Int32 = 1;
			else if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.BY2_INTERPOL256)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.BY2_INTERPOL256)
			) TMCL.reply->Value.Int32 = 2;
			else if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.BY4_INTERPOL0)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.BY4_INTERPOL0)
			) TMCL.reply->Value.Int32 = 3;
			else if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.BY4_INTERPOL256)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.BY4_INTERPOL256)
			) TMCL.reply->Value.Int32 = 4;
			else if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.BY16_INTERPOL0)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.BY16_INTERPOL0)
			) TMCL.reply->Value.Int32 = 5;
			else if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.BY16_INTERPOL256)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.BY16_INTERPOL256)
			) TMCL.reply->Value.Int32 = 6;
			else if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.PWM_CHOP_BY4_INTERPOL256)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.PWM_CHOP_BY4_INTERPOL256)
			) TMCL.reply->Value.Int32 = 7;
			else if
			(
				1
				&& (config.microsteResolution1 == TMCRhinoSA.MicrosteResolutionSettings1.PWM_CHOP_BY16_INTERPOL256)
				&& (config.microsteResolution2 == TMCRhinoSA.MicrosteResolutionSettings2.PWM_CHOP_BY16_INTERPOL256)
			) TMCL.reply->Value.Int32 = 8;
			else
			{
				TMCL.reply->Status = REPLY_INVALID_VALUE;
			}
		break;

		case 2:
			TMCL.reply->Value.Int32 = config.currentSetting;
		break;

		case 3:
			TMCL.reply->Value.Int32 = config.chopperHysteresis;
		break;

		case 4:
			TMCL.reply->Value.Int32 = config.chopperBlankTime;
		break;

		case 5:
			TMCL.reply->Value.Int32 = config.enable_StandStillPowerDown;
		break;

		case 6:
			TMCL.reply->Value.Int32 = config.chopperOffTime;
		break;


	}
}

static void init(void)
{
	Pins.AIN_PWM		= &HAL.IOs->pins->DIO11;
	Pins.AIN_SW			= &HAL.IOs->pins->DIO10;
	Pins.CFG0 			= &HAL.IOs->pins->SPI2_SDO;
	Pins.CFG1 			= &HAL.IOs->pins->SPI2_SDI;
	Pins.CFG2 			= &HAL.IOs->pins->SPI2_SCK;
	Pins.CFG3 			= &HAL.IOs->pins->SPI2_CSN0;
	Pins.CFG4 			= &HAL.IOs->pins->DIO13;
	Pins.CFG5 			= &HAL.IOs->pins->DIO12;
	Pins.CFG6_ENN		= &HAL.IOs->pins->DIO0;
	Pins.DIR			= &HAL.IOs->pins->DIO7;
	Pins.ERROR			= &HAL.IOs->pins->DIO15;
	Pins.INDEX			= &HAL.IOs->pins->DIO16;
	Pins.STEP			= &HAL.IOs->pins->DIO6;

	HAL.IOs->config->toOutput(Pins.STEP);
	HAL.IOs->config->toOutput(Pins.DIR);
	HAL.IOs->config->toOutput(Pins.AIN_PWM);
	HAL.IOs->config->toOutput(Pins.AIN_SW);

	HAL.IOs->config->toInput(Pins.ERROR);
	HAL.IOs->config->toInput(Pins.INDEX);



	TMCRhinoSA.CFGPins[0] = Pins.CFG0;
	TMCRhinoSA.CFGPins[1] = Pins.CFG1;
	TMCRhinoSA.CFGPins[2] = Pins.CFG2;
	TMCRhinoSA.CFGPins[3] = Pins.CFG3;
	TMCRhinoSA.CFGPins[4] = Pins.CFG4;
	TMCRhinoSA.CFGPins[5] = Pins.CFG5;
	TMCRhinoSA.CFGPins[6] = Pins.CFG6_ENN;

	uint8 i;

	for(i=0; i<7; i++)
	{
		HAL.IOs->config->toOutput(TMCRhinoSA.CFGPins[i]);
		HAL.IOs->config->setLow(TMCRhinoSA.CFGPins[i]);
	}

	EvalBoards.ch2.config->isBusy		= 0;

	StepDir.init();
	StepDirCh[0] 						= StepDir.ch1;
	StepDirCh[0]->stepOut 				= Pins.STEP;
	StepDirCh[0]->dirOut 				= Pins.DIR;

	EvalBoards.ch2.motorStop			= MotorStop;
	EvalBoards.ch2.getAxisParameter		= GetAxisParameter;
	EvalBoards.ch2.moveToPosition		= MoveToPosition;
	EvalBoards.ch2.rotateLeft			= RotateLeft;
	EvalBoards.ch2.rotateRight			= RotateRight;
	EvalBoards.ch2.setAxisParameter		= SetAxisParameter;
	EvalBoards.ch2.readRegister			= readRegister;
	EvalBoards.ch2.writeRegister		= writeRegister;
	EvalBoards.ch2.enableDriver			= enableDriver;
	EvalBoards.ch2.numberOfMotors		= 1;
	EvalBoards.numberOfMotors			= 1;
	EvalBoards.ch2.deInit				= deInit;
	enableDriver(2);
	reset();

#if defined(Startrampe)
	Pins.AIN_PWM->configuration.GPIO_Mode = GPIO_Mode_AF;
	GPIO_PinAFConfig(Pins.AIN_PWM->port, Pins.AIN_PWM->bit, GPIO_AF_TIM1);
#elif defined(Landungsbreucke)
	HAL.IOs->config->toOutput(Pins.AIN_REF_PWM);
	Pins.AIN_REF_PWM->configuration.GPIO_Mode = GPIO_Mode_AF4;
#endif

	HAL.IOs->config->set(Pins.AIN_PWM);
	Timer.init();
	Timer.setDuty(0);
}

static void deInit(void)
{
	enableDriver(0);
	HAL.IOs->config->reset(Pins.AIN_PWM);
	HAL.IOs->config->reset(Pins.AIN_SW);
	HAL.IOs->config->reset(Pins.CFG0);
	HAL.IOs->config->reset(Pins.CFG1);
	HAL.IOs->config->reset(Pins.CFG2);
	HAL.IOs->config->reset(Pins.CFG3);
	HAL.IOs->config->reset(Pins.CFG4);
	HAL.IOs->config->reset(Pins.CFG5);
	HAL.IOs->config->reset(Pins.CFG6_ENN);
	HAL.IOs->config->reset(Pins.DIR);
	HAL.IOs->config->reset(Pins.ERROR);
	HAL.IOs->config->reset(Pins.INDEX);
	HAL.IOs->config->reset(Pins.STEP);

	StepDir.deInit();
	Timer.deInit();
}

static uint8 reset()
{
	if(StepDirCh[0]->actualVelocity && !VitalSignsMonitor.brownOut) return 0;
	TMCRhinoSA.reset();
	return 1;
}

static void enableDriver(uint8 enable)
{
	TMCRhinoTypeStandAloneConfigDef config;
	TMCRhinoSA.getConfig(&config);

	if(!enable)
	{
		lastEnable = config.enable_StandStillPowerDown;
		config.enable_StandStillPowerDown = TMCRhinoSA.Enable_StandStillPowerDownSettings.DISABLED;
	}
	else
	{
		config.enable_StandStillPowerDown = lastEnable;
	}
}
