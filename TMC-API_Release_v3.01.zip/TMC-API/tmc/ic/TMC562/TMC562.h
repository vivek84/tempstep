/*
 * TMC562.h
 *
 *  Created on: 26.01.2017
 *      Author: BS
 *    Based on: TMC562-MKL.h (26.01.2012 OK)
 */

#ifndef API_IC_TMC562_H
#define API_IC_TMC562_H

	#include "../../helpers/API_Header.h"
	#include "TMC562_Register.h"

	void tmc562_writeDatagram(uint8 Address, uint8 x1, uint8 x2, uint8 x3, uint8 x4);
	void tmc562_writeInt(uint8 Address, int32 Value);
	int32 tmc562_readInt(uint8 Address);

	void tmc562_setChopperTOff(uint8 Motor, uint8 TOff);
	void tmc562_setChopperHysteresisStart(uint8 Motor, uint8 HysteresisStart);
	void tmc562_setChopperHysteresisEnd(uint8 Motor, uint8 HysteresisEnd);
	void tmc562_setChopperBlankTime(uint8 Motor, uint8 BlankTime);
	void tmc562_setChopperSync(uint8 Motor, uint8 Sync);
	void tmc562_setChopperMStepRes(uint8 Motor, uint8 MRes);
	void tmc562_setChopperDisableShortToGround(uint8 Motor, uint8 Disable);
	void tmc562_setChopperVHighChm(uint8 Motor, uint8 VHighChm);
	void tmc562_setChopperVHighFs(uint8 Motor, uint8 VHighFs);
	void tmc562_setChopperConstantTOffMode(uint8 Motor, uint8 ConstantTOff);
	void tmc562_setChopperRandomTOff(uint8 Motor, uint8 RandomTOff);
	void tmc562_setChopperDisableFastDecayComp(uint8 Motor, uint8 Disable);
	void tmc562_setChopperFastDecayTime(uint8 Motor, uint8 Time);
	void tmc562_setChopperSineWaveOffset(uint8 Motor, uint8 Offset);
	void tmc562_setChopperVSenseMode(uint8 Motor, uint8 Mode);
	uint8 tmc562_getChopperTOff(uint8 Motor);
	uint8 tmc562_getChopperHysteresisStart(uint8 Motor);
	uint8 tmc562_getChopperHysteresisEnd(uint8 Motor);
	uint8 tmc562_getChopperBlankTime(uint8 Motor);
	uint8 tmc562_getChopperSync(uint8 Motor);
	uint8 tmc562_getChopperMStepRes(uint8 Motor);
	uint8 tmc562_getChopperDisableShortToGround(uint8 Motor);
	uint8 tmc562_getChopperVHighChm(uint8 Motor);
	uint8 tmc562_getChopperVHighFs(uint8 Motor);
	uint8 tmc562_getChopperConstantTOffMode(uint8 Motor);
	uint8 tmc562_getChopperRandomTOff(uint8 Motor);
	uint8 tmc562_getChopperDisableFastDecayComp(uint8 Motor);
	uint8 tmc562_getChopperFastDecayTime(uint8 Motor);
	uint8 tmc562_getChopperSineWaveOffset(uint8 Motor);
	uint8 tmc562_getChopperVSenseMode(uint8 Motor);
	void tmc562_setSmartEnergyUpStep(uint8 Motor, uint8 UpStep);
	void tmc562_setSmartEnergyDownStep(uint8 Motor, uint8 DownStep);
	void tmc562_setSmartEnergyStallLevelMax(uint8 Motor, uint8 Max);
	void tmc562_setSmartEnergyStallLevelMin(uint8 Motor, uint8 Min);
	void tmc562_setSmartEnergyStallThreshold(uint8 Motor, int8 Threshold);
	void tmc562_setSmartEnergyIMin(uint8 Motor, uint8 IMin);
	void tmc562_setSmartEnergyFilter(uint8 Motor, uint8 Filter);
	uint8 tmc562_getSmartEnergyUpStep(uint8 Motor);
	uint8 tmc562_getSmartEnergyDownStep(uint8 Motor);
	uint8 tmc562_getSmartEnergyStallLevelMax(uint8 Motor);
	uint8 tmc562_getSmartEnergyStallLevelMin(uint8 Motor);
	int32 tmc562_getSmartEnergyStallThreshold(uint8 Motor);
	uint8 tmc562_getSmartEnergyIMin(uint8 Motor);
	uint8 tmc562_getSmartEnergyFilter(uint8 Motor);
	void tmc562_setPwmAmpl(uint8 Motor, uint8 PwmAmpl);
	void tmc562_setPwmGrad(uint8 Motor, uint8 PwmGrad);
	void tmc562_setPwmFreq(uint8 Motor, uint8 PwmFreq);
	void tmc562_setPwmAutoscale(uint8 Motor, uint8 Autoscale);
	void tmc562_setFreewheel(uint8 Motor, uint8 Freewheel);
	uint8 tmc562_getPwmAmpl(uint8 Motor);
	uint8 tmc562_getPwmGrad(uint8 Motor);
	uint8 tmc562_getPwmFreq(uint8 Motor);
	uint8 tmc562_getPwmAutoscale(uint8 Motor);
	uint8 tmc562_getPwmFreewheel(uint8 Motor);
	uint8 tmc562_getPwmStatus(uint8 Motor);

	void tmc562_initMotorDrivers(void);
	void tmc562_hardStop(uint8 Motor);

#endif
