/*
 * States.c
 *
 *  Created on: 05.10.2016
 *      Author: ed
 */
#include "States.h"

DRIVER_STATE_T DRIVER_STATE = {
		.DISABLE 			= 0,
		.ENABLE 			= 1,
		.USE_GLOBAL_ENABLE 	= 2
};
