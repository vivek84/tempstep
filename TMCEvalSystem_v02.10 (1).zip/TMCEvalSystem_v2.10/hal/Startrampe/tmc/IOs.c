#include "../../IOs.h"


static void init();
static void setPinConfiguration(IOPinTypeDef *pin);
static void copyPinConfiguration(IOPinInitTypeDef *from, IOPinTypeDef*to);
static void resetPinConfiguration(IOPinTypeDef *pin);
static void setPin2Output(IOPinTypeDef *pin);
static void setPin2Input(IOPinTypeDef *pin);
static void setPinHigh(IOPinTypeDef *pin);
static void setPinLow(IOPinTypeDef *pin);
static void setPinState(IOPinTypeDef *pin, enum IOS_STATES state);
static unsigned char isPinHigh(IOPinTypeDef *pin);

IOsTypeDef IOs =
{
	.init 					= init,
	.set 					= setPinConfiguration,
	.reset 					= resetPinConfiguration,
	.copy					= copyPinConfiguration,
	.toOutput 				= setPin2Output,
	.toInput 				= setPin2Input,
	.setHigh 				= setPinHigh,
	.setLow 				= setPinLow,
	.setToState 			= setPinState,
	.isHigh 				= isPinHigh,
	.HIGH_LEVEL_FUNCTIONS 	=
	{
		.DEFAULT	= IO_DEFAULT,
		.DI			= IO_DI,
		.AI			= IO_AI,
		.DO			= IO_DO,
		.PWM		= IO_PWM,
		.SD			= IO_SD,
		.CLK16		= IO_CLK16,
		.SPI		= IO_SPI
	}
};

static void init()
{
	RCC_MCO1Config(RCC_MCO1Source_HSE, RCC_MCO1Div_1); 	// clock out @PA8: 16MHz (crystal)
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
}

static void setPinConfiguration(IOPinTypeDef *pin)
{
	if(pin->bitWeight == 3) return;	// dummy pin
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin		= pin->bitWeight;
	GPIO_InitStructure.GPIO_Mode	= pin->configuration.GPIO_Mode;
	GPIO_InitStructure.GPIO_OType	= pin->configuration.GPIO_OType;
	GPIO_InitStructure.GPIO_Speed	= pin->configuration.GPIO_Speed;
	GPIO_InitStructure.GPIO_PuPd 	= pin->configuration.GPIO_PuPd;
	GPIO_Init(pin->port, &GPIO_InitStructure);
}

static void setPin2Output(IOPinTypeDef *pin)
{
	if(pin->bitWeight == 3) return;	// dummy pin
	pin->configuration.GPIO_Mode = GPIO_Mode_OUT;
	setPinConfiguration(pin);
}

static void setPin2Input(IOPinTypeDef *pin)
{
	if(pin->bitWeight == 3) return;	// dummy pin
	pin->configuration.GPIO_Mode = GPIO_Mode_IN;
	setPinConfiguration(pin);
}

static void setPinState(IOPinTypeDef *pin, enum IOS_STATES state)
{
	if(pin->bitWeight == 3) return;	// dummy pin
	switch(state)
	{
		case LOW:
			pin->configuration.GPIO_Mode = GPIO_Mode_OUT;
			*pin->resetBitRegister = pin->bitWeight;
		break;

		case HIGH:
			pin->configuration.GPIO_Mode = GPIO_Mode_OUT;
			*pin->setBitRegister = pin->bitWeight;
		break;

		case OPEN:
			pin->configuration.GPIO_Mode = GPIO_Mode_IN;
		break;
	}

	setPinConfiguration(pin);
}

static void setPinHigh(IOPinTypeDef *pin)
{
	if(pin->bitWeight == 3) return;	// dummy pin
	*pin->setBitRegister = pin->bitWeight;
}

static void setPinLow(IOPinTypeDef *pin)
{
	if(pin->bitWeight == 3) return;	// dummy pin
	*pin->resetBitRegister = pin->bitWeight;
}

static unsigned char isPinHigh(IOPinTypeDef *pin)
{
	if(pin->bitWeight == 3) return-1;	// dummy pin
	return (pin->port->IDR & pin->bitWeight) ? 1 : 0;
}

static void copyPinConfiguration(IOPinInitTypeDef *from, IOPinTypeDef *to)
{
	if(to->bitWeight == 3) return;	// dummy pin

	to->configuration.GPIO_Mode		= from->GPIO_Mode;
	to->configuration.GPIO_OType	= from->GPIO_OType;
	to->configuration.GPIO_PuPd		= from->GPIO_PuPd;
	to->configuration.GPIO_Speed	= from->GPIO_Speed;
	setPinConfiguration(to);
}

static void resetPinConfiguration(IOPinTypeDef *pin)
{
	if(pin->bitWeight == 3) return;	// dummy pin
	copyPinConfiguration(&(pin->resetConfiguration), pin);
	pin->highLevelFunction  = IOs.HIGH_LEVEL_FUNCTIONS.DEFAULT;
}

