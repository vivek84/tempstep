#include "../../HAL.h"
#include "../../RXTX.h"
#include "../../Wireless.h"
#include "../freescale/Cpu.h"

#define BUFFER_SIZE 		1024
#define INTR_PRI	 		6
#define UART_TIMEOUT_VALUE 	5


static void init();
static void deInit();
static void tx(int8 ch);
static uint8 rx(int8 *ch);
static void txN(int8 *str, uint8 number);
static uint8 rxN(int8 *ch, uint8 number);
static void clearBuffers(void);
static uint8 bytesAvailable();


static volatile int8
	rxBuffer[BUFFER_SIZE],
	txBuffer[BUFFER_SIZE];

static volatile unsigned int
	available 	= 0;

volatile uint32 UART0_TimeoutTimer;

RXTXTypeDef Wireless =
{
	.init 			= init,
	.deInit			= deInit,
	.rx				= rx,
	.tx				= tx,
	.rxN			= rxN,
	.txN			= txN,
	.clearBuffers	= clearBuffers,
	.baudRate		= 115200,
	.bytesAvailable	= bytesAvailable
};

static RXTXBufferingTypeDef buffers =
{
		.rx =
		{
			.read	= 0,
			.wrote	= 0,
			.buffer = rxBuffer
		},

		.tx =
		{
			.read	= 0,
			.wrote	= 0,
			.buffer = txBuffer
		}
};

static void init()
{
	register uint32 ubd;

	SIM_SCGC4 |= SIM_SCGC4_UART0_MASK;

	HAL.IOs->pins->WIRELESS_RX.configuration.GPIO_Mode = GPIO_Mode_AF3;
	HAL.IOs->pins->WIRELESS_TX.configuration.GPIO_Mode = GPIO_Mode_AF3;

	HAL.IOs->config->set(&HAL.IOs->pins->WIRELESS_RX);
	HAL.IOs->config->set(&HAL.IOs->pins->WIRELESS_TX);
	/* Disable the transmitter and receiver */
	UART_C2_REG(UART0_BASE_PTR) &= ~(UART_C2_TE_MASK | UART_C2_RE_MASK );

	/* Configure the UART for 8-bit mode, no parity */
	/* We need all default settings, so entire register is cleared */
	UART_C1_REG(UART0_BASE_PTR) = 0;

	ubd = (CPU_BUS_CLK_HZ / 16) / (Wireless.baudRate);

	UART_BDH_REG(UART0_BASE_PTR) = (ubd >> 8) & UART_BDH_SBR_MASK;
	UART_BDL_REG(UART0_BASE_PTR) = (ubd & UART_BDL_SBR_MASK);

	/* Enable receiver and transmitter */
	UART_C2_REG(UART0_BASE_PTR) |= (UART_C2_TE_MASK | UART_C2_RE_MASK | UART_C2_RIE_MASK);

	enable_irq(INT_UART0_RX_TX-16);
}

static void deInit()
{
	SIM_SCGC4 &= ~(SIM_SCGC4_UART0_MASK);

	HAL.IOs->pins->WIRELESS_RX.configuration.GPIO_Mode = GPIO_Mode_IN;
	HAL.IOs->pins->WIRELESS_TX.configuration.GPIO_Mode = GPIO_Mode_IN;

	HAL.IOs->config->set(&HAL.IOs->pins->WIRELESS_RX);
	HAL.IOs->config->set(&HAL.IOs->pins->WIRELESS_TX);

	disable_irq(INT_UART0_RX_TX-16);

	clearBuffers();
}

void UART0_RX_TX_IRQHandler(void)
{
	uint32 status = UART0_S1;

    if(status & UART_S1_RDRF_MASK)
	{
		buffers.rx.buffer[buffers.rx.wrote] = UART0_D;
		if(++buffers.rx.wrote >= BUFFER_SIZE) buffers.rx.wrote = 0;
			available++;
    	// reset timeout value
    	UART0_TimeoutTimer = UART_TIMEOUT_VALUE;
    	UART0_S1 &= ~(UART_S1_RDRF_MASK);	//Zur�cksetzen InterruptFlag
	}

	if(status & UART_S1_TDRE_MASK)
	{
		if(buffers.tx.read != buffers.tx.wrote)
		{
			UART0_D	= buffers.tx.buffer[buffers.tx.read];
			if(++buffers.tx.read >= BUFFER_SIZE) buffers.tx.read = 0;
		}
		else
    		// empty buffer -> turn off send interrupt
			UART0_C2 &= ~UART_C2_TIE_MASK;
		UART0_S1 &= ~(UART_S1_TDRE_MASK);	// Zur�cksetzen InterruptFlag
	}
}

static void tx(int8 ch)
{
	buffers.tx.buffer[buffers.tx.wrote] = ch;

	if(++buffers.tx.wrote >= BUFFER_SIZE) buffers.tx.wrote = 0;
	// enable send interrupt
	UART0_C2 |= UART_C2_TIE_MASK;
}

static uint8 rx(int8 *ch)
{
  if(buffers.rx.read == buffers.rx.wrote) return 0;
  *ch = buffers.rx.buffer[buffers.rx.read];
  if(++buffers.rx.read >= BUFFER_SIZE) buffers.rx.read = 0;
  available--;
  return 1;
}

static void txN(int8 *str, uint8 number)
{
	int32 i=0;
	for(i=0; i<number; i++){
		tx(str[i]);
	}
}

static uint8 rxN(int8 *str, uint8 number)
{
	int32 i;
	if(bytesAvailable() < number) return 0;
	for(i=0; i<number; i++) rx(&str[i]);
	return 1;
}

static void clearBuffers(void)
{
	disable_irq(INT_UART0_RX_TX-16);
	available			= 0;
	buffers.rx.read	= 0;
	buffers.rx.wrote	= 0;

	buffers.tx.read	= 0;
	buffers.tx.wrote	= 0;
	enable_irq(INT_UART0_RX_TX-16);
}

static uint8 bytesAvailable()
{
	return available;
}

