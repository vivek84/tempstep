#ifndef __TMC5041_H
	#define __TMC5041_H

	#include "board.h"
	EvalBoardTypeDef TMC5041;

#endif
