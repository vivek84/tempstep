#include "../../HAL.h"
#include "../../systemTick.h"

static void init(void);
void __attribute__ ((interrupt)) SysTick_Handler(void);


SystemTickTypeDef SystemTick =
{
	.init	= init,
	.tick 	= 0
};


void SysTick_Handler(void)
{
	SystemTick.tick++;
}

void init(void)
{
  SysTick_Config(15000);
  SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
}

