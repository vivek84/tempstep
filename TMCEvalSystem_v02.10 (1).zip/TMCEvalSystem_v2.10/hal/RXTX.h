#ifndef RXTX_H_
	#define RXTX_H_

	typedef struct
	{
		void (*init)(void);
		void (*deInit)(void);
		void (*tx)(char ch);
		unsigned char (*rx)(char *ch);
		void (*txN)(char *ch, unsigned char number);
		unsigned char (*rxN)(char *ch, unsigned char number);
		void (*clearBuffers)(void);
		unsigned char (*bytesAvailable)(void);
		unsigned int baudRate;
	} RXTXTypeDef;

	typedef struct
	{
		unsigned int read;
		unsigned int wrote;
		volatile char *buffer;
	} BufferingTypeDef;

	typedef struct
	{
		BufferingTypeDef tx;
		BufferingTypeDef rx;
	} RXTXBufferingTypeDef;

#endif
