#ifndef __EVAL_H
	#define __EVAL_H

	#define SW_VERSION_HIGH 1
	#define SW_VERSION_LOW  0

	#define MIN(a,b) (a<b) ? (a) : (b)
	#define MAX(a,b) (a>b) ? (a) : (b)


	#define RESET_WATCHDOG()
#endif
