#include "../../derivative.h"
#include "../../HAL.h"

static void init(void);
static void reset(uint8 ResetPeripherals);
static void NVIC_DeInit(void);

static const IOsFunctionsTypeDef IOFunctions =
{
	.config = &IOs,
	.pins	= &IOMap,
	.LOW	= IOS_LOW,
	.HIGH	= IOS_HIGH,
	.OPEN	= IOS_OPEN
};

const HALTypeDef HAL =
{
	.init			= init,
	.reset			= reset,
	.NVIC_DeInit 	= NVIC_DeInit,
	.SPI			= &SPI,
	.USB			= &USB,
	.LEDs			= &LEDs,
	.ADCs			= &ADCs,
	.IOs 			= &IOFunctions,
	.RS232 			= &RS232,
	.Wireless		= &Wireless,
	.SystemTick		= &SystemTick,
	.Timer			= &Timer
};

static void init(void)
{
	Cpu.initClocks();
	Cpu.initLowLevel();
	EnableInterrupts;

	SystemTick.init();
	uint32 wait = SystemTick.tick;

	while(abs(SystemTick.tick-wait)<100);

	IOs.init();
	IOMap.init();
	LEDs.init();
	ADCs.init();
	SPI.init();
	Wireless.init();
	RS232.init();
	USB.init();
}

static void reset(uint8 ResetPeripherals)
{
	  if(ResetPeripherals)
	    SCB_AIRCR = SCB_AIRCR_VECTKEY(0x5FA) | SCB_AIRCR_SYSRESETREQ_MASK;
	  else
	    SCB_AIRCR = SCB_AIRCR_VECTKEY(0x5FA) | SCB_AIRCR_VECTRESET_MASK;
}

static void NVIC_DeInit(void)
{
	uint8 index;

	asm volatile("CPSID I\n");	// disable interrupts

	for(index = 0; index < 8; index++)
	{
		NVIC_ICER_REG(NVIC_BASE_PTR,index) = 0xFFFFFFFF;
		NVIC_ICPR_REG(NVIC_BASE_PTR,index) = 0xFFFFFFFF;
	}

	for(index = 0; index < 240; index++)
	{
		NVIC_IP_REG(NVIC_BASE_PTR,index) = 0x00000000;
	}


    DisableInterrupts;
    SYST_CSR=0;
    NVICICER0=0xFFFFFFFF;  //alle Interrupts sperren
    NVICICPR0=0xFFFFFFFF;
    NVICICER1=0xFFFFFFFF;
    NVICICPR1=0xFFFFFFFF;
    NVICICER2=0xFFFFFFFF;
    NVICICPR2=0xFFFFFFFF;
    NVICICER3=0xFFFFFFFF;
    NVICICPR3=0xFFFFFFFF;
}

void _exit(int i)
{
	UNUSED(i);
}

void _kill(void)
{
}

void _getpid(void)
{
}
