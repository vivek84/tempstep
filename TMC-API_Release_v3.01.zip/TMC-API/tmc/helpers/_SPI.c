/*
 * _SPI.h
 *
 *  Created on: Jan 24, 2017
 *      Author: Thomas
 *
 *      Suggested common SPI routines
 */


#include "_SPI.h"

static uint8 SPIStatus = 0;

void waitMs(uint32 milliSeconds);

static uint8 TMC4361Cover(uint8 data,uint8 lastTransfer);

uint8 SPIWrapper(uint8 chip, uint8 value, uint8 lastByte)
{// translate between TRINAMIC SPI routines and low level SPI routines.

// TODO add external low level functions

	uint8 read = 0;

	switch(chip)
	{
		case SPI_TMC5072:
		break;

		case SPI_TMC4361:
		break;

		case SPI_TMC4361_COVER:
			TMC4361Cover(value, lastByte);
		break;

		default: break;
	}
	return read;
}

void SPIWriteBytes(uint8 chip, uint8 address, uint8 x1, uint8 x2, uint8 x3, uint8 x4)
{// write  SPI datagram byte-wise
	SPIStatus	= SPIWrapper(chip, address|0x80, 0);	// address byte marked as write access
	SPIWrapper(chip, x1, 0);							// SPI access
	SPIWrapper(chip, x2, 0);							// SPI access
	SPIWrapper(chip, x3, 0);							// SPI access
	SPIWrapper(chip, x4, 1);							// SPI access last byte, chip select can be released
}

void SPIWriteInt(uint8 chip, uint8 address, int32 value)
{// write in value with SPI datagram
	SPIWriteBytes(chip, address, 0xFF & (value>>24), 0xFF & (value>>16), 0xFF & (value>>8), 0xFF & (value>>0));
}

int32 SPIReadInt(uint8 chip, uint8 address)
{// read 32bit value from register
  int32 value;

  address &= 0x7f;
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// discard first access because SPI reply is related to last SPI datagram
  	  SPIWrapper(chip, address, 0);
  	  SPIWrapper(chip, 0, 0);
  	  SPIWrapper(chip, 0, 0);
  	  SPIWrapper(chip, 0, 0);
  	  SPIWrapper(chip, 0, 1);
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	SPIStatus = SPIWrapper(chip, address, 0);
	value	=	SPIWrapper(chip, 0, 0);
	value	<<=	8;
	value	|=	SPIWrapper(chip, 0, 0);
	value	<<=	8;
	value	|=	SPIWrapper(chip, 0, 0);
	value	<<=	8;
	value	|=	SPIWrapper(chip, 0, 1);
    return value;
}

void SPIWriteDatagram(uint8 chip, TDatagram *datagram)
{
	SPIWriteBytes(chip, datagram->address, datagram->value.byte[3], datagram->value.byte[2], datagram->value.byte[1], datagram->value.byte[0]);
}

void SPIReadDatagram(uint8 chip, TDatagram *datagram)
{
	datagram->value.int32 = SPIReadInt(chip,  datagram->address);
}

static uint8 TMC4361Cover(uint8 data,uint8 lastTransfer)
{
	static uint64
		coverIn		= 0,			// read from squirrel
		coverOut	= 0;			// write 2 squirrel

	static uint8
		coverLength	= 0,			// data 2 be written
		out			= 0;			// return value of this function

	/* In covering case data will be read/written in blocks. The cover function emulates a SPI readWrite function.
	 * So for every call a one byte will be send and one byte read will be returned. This means that outgoing as well as
	 * incoming data needs 2 be buffered.
	 *
	 */

	// buffering outgoing data until lastTransfer flag is high
		coverOut	<<=	8;			// shift left by one byte to make room for a new
		coverOut	|=	data;		// add new byte 2 be written
		coverLength++;				// count outgoing bytes

	// return read and buffered byte to be returned
		out			= coverIn>>56;	// output last received byte
		coverIn		<<= 8;			// shift by one byte to read this next time

	if(lastTransfer)				// last byte to be sent/buffered
	{
	// WRITE TWICE
		/* Write data 2 cover register. If there are more than 4 bytes 2 be written cover high register is used also.
		 * Than wait covering to be finished.
		 * This whole writing procedure is done twice because for calls of readwrite procedure a valid value is suspected
		 * on second read call for a whole datagram. As this procedure needs one datagram to buffer all data data valid data
		 * would only be served on third call not doing this.
		 */

		waitMs(10);
		if(coverLength>4) SPIWriteInt(SPI_TMC4361, 0x6D, 	coverOut >> 32);	// write TMC4361_COVER_HIGH
		SPIWriteInt(SPI_TMC4361, 0x6C, 	coverOut & 0xFFFFFFFF);					// write TMC4361_COVER_LOW

		waitMs(50);
		SPIWriteInt(SPI_TMC4361, 0x6C, 	coverOut & 0xFFFFFFFF);	//write TMC4361_COVER_LOW - need 2 send again for valid access 2 start covering, cover high register is still valid

		coverOut	= 0;			// clear outgoing buffer
	// READ ONCE
		coverIn		= 0;			// clear incoming buffer

		if(coverLength>4)
		{
			coverIn |= 	SPIReadInt(SPI_TMC4361, 0x6F);						// read from TMC4361_COVER_DRV_HIGH - byte form cover register an add byte to in buffer
			coverIn <<=	32;													// shift left to make room for low cover register
		}
		coverIn |= 	SPIReadInt(SPI_TMC4361, 0x6E);							// read from TMC4361_COVER_DRV_LOW - byte form cover register an add byte to in buffer
		coverIn <<=	(8-coverLength)*8;										// shift left to place highest received byte most left
		coverLength=0;														// clear in counter
	}

	return out;																// return buffered read byte
}

void waitMs(uint32 milliSeconds)
{
	// TODO adapt for your low level routines to wait milliseconds
//	uint32 lastTick = HAL.SystemTick->tick;
	// todo: hier vielleicht besser einen externen "extern uint32 systemTick" nutzen, anstatt der Abh�ngigkeit
	// zu einer Struktur, die in jedem externen Projekt mitgezogen werden muss? (ED)
//	while(abs(HAL.SystemTick->tick-lastTick) > milliSeconds);	// wait 50ms before next sending
}
