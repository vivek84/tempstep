/*
 * TMC5160.h
 *
 *  Created on: 17.03.2017
 *      Author: ED based on BS
 */

#ifndef API_IC_TMC5160_H
#define API_IC_TMC5160_H

	#include "../../helpers/API_Header.h"
	#include "TMC5160_Register.h"

	//Factor between 10ms units and internal units for 16MHz
	#define TPOWERDOWN_FACTOR (4.17792*100.0/255.0)
	// TPOWERDOWN_FACTOR = k * 100 / 255 where k = 2^18 * 255 / fClk for fClk = 16000000)

	void tmc5160_writeInt(uint8 Address, int32 Value);
	int32 tmc5160_readInt(uint8 Address);
	void tmc5160_init();
	void tmc5160_rotate(int32 velocity);
	void tmc5160_motorStop();
	void tmc5160_hardStop();
	void tmc5160_moveToAbsolutePosition(int32 position, int32 velocity);
	void tmc5160_moveToRelativePosition(int32 position, int32 velocity, int32 reference);

	// IHold IRun
	void tmc5160_setIHold(uint8 current);
	void tmc5160_setIRun(uint8 current);
	void tmc5160_setIHoldDelay(uint8 delay);
	uint8 tmc5160_getIHold();
	uint8 tmc5160_getIRun();
	uint8 tmc5160_getIHoldDelay();

	// Chopper Conf
	void tmc5160_setStealthChop(uint8 Enable);
	void tmc5160_setChopperMStepRes(uint8 MRes);
	void tmc5160_setChopperMStepInterpolation(uint8 Enable);
	void tmc5160_setChopperVSenseMode(uint8 Mode);
	uint8 tmc5160_getStealthChop();
	uint8 tmc5160_getChopperMStepRes();
	uint8 tmc5160_getChopperMStepInterpolation();
	uint8 tmc5160_getChopperVSenseMode();

	void tmc5160_setChopperTOff(uint8 TOff);
	void tmc5160_setChopperHysteresisStart(uint8 HysteresisStart);
	void tmc5160_setChopperHysteresisEnd(uint8 HysteresisEnd);
	void tmc5160_setChopperBlankTime(uint8 BlankTime);
	void tmc5160_setChopperSync(uint8 Sync);
	void tmc5160_setChopperDisableShortToGround(uint8 Disable);
	void tmc5160_setChopperVHighChm(uint8 VHighChm);
	void tmc5160_setChopperVHighFs(uint8 VHighFs);
	void tmc5160_setChopperConstantTOffMode(uint8 ConstantTOff);
	void tmc5160_setChopperRandomTOff(uint8 RandomTOff);
	void tmc5160_setChopperDisableFastDecayComp(uint8 Disable);
	void tmc5160_setChopperFastDecayTime(uint8 Time);
	void tmc5160_setChopperSineWaveOffset(uint8 Offset);
	uint8 tmc5160_getChopperTOff();
	uint8 tmc5160_getChopperHysteresisStart();
	uint8 tmc5160_getChopperHysteresisEnd();
	uint8 tmc5160_getChopperBlankTime();
	uint8 tmc5160_getChopperSync();
	uint8 tmc5160_getChopperDisableShortToGround();
	uint8 tmc5160_getChopperVHighChm();
	uint8 tmc5160_getChopperVHighFs();
	uint8 tmc5160_getChopperConstantTOffMode();
	uint8 tmc5160_getChopperRandomTOff();
	uint8 tmc5160_getChopperDisableFastDecayComp();
	uint8 tmc5160_getChopperFastDecayTime();
	uint8 tmc5160_getChopperSineWaveOffset();

	// Coolstep Conf
	void tmc5160_setSmartEnergyUpStep(uint8 UpStep);
	void tmc5160_setSmartEnergyDownStep(uint8 DownStep);
	void tmc5160_setSmartEnergyStallLevelMax(uint8 Max);
	void tmc5160_setSmartEnergyStallLevelMin(uint8 Min);
	void tmc5160_setSmartEnergyStallThreshold(int8 Threshold);
	void tmc5160_setSmartEnergyIMin(uint8 IMin);
	void tmc5160_setSmartEnergyFilter(uint8 Filter);
	uint8 tmc5160_getSmartEnergyUpStep();
	uint8 tmc5160_getSmartEnergyDownStep();
	uint8 tmc5160_getSmartEnergyStallLevelMax();
	uint8 tmc5160_getSmartEnergyStallLevelMin();
	int32 tmc5160_getSmartEnergyStallThreshold();
	uint8 tmc5160_getSmartEnergyIMin();
	uint8 tmc5160_getSmartEnergyFilter();

	// PWMConf
	void tmc5160_setPWMFreewheelMode(uint8 Mode);
	void tmc5160_setPWMSymmetric(uint8 Symmetric);
	void tmc5160_setPWMAutoscale(uint8 Autoscale);
	void tmc5160_setPWMFrequency(uint8 Frequency);
	void tmc5160_setPWMGrad(uint8 PWMGrad);
	void tmc5160_setPWMAmpl(uint8 PWMAmpl);
	uint8 tmc5160_getPWMFreewheelMode();
	uint8 tmc5160_getPWMSymmetric();
	uint8 tmc5160_getPWMAutoscale();
	uint8 tmc5160_getPWMFrequency();
	uint8 tmc5160_getPWMGrad();
	uint8 tmc5160_getPWMAmpl();

#endif /* API_IC_TMC5160_H */
