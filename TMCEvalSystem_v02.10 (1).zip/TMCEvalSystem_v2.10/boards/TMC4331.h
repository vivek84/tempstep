#ifndef __TMC4331_H
	#define __TMC4331_H

	#include "board.h"
	EvalBoardTypeDef TMC4331;

#endif
