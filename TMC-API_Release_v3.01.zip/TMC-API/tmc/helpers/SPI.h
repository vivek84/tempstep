/*
 * SPI.h
 *
 *  Created on: 30.09.2016
 *      Author: ed
 */

#ifndef API_SPI_H
#define API_SPI_H

	#include "TypeDefs.h"

	#define Bit0to15 	0
	#define Bit16to31	1

	typedef struct
	{
		u8 address;
		union
		{
			u32 int32;
			u16 word[2];
			u8 byte[4];
		}value;
	} TDatagram;

#endif /* API_SPI_H */
