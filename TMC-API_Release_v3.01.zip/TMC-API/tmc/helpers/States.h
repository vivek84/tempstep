/*
 * States.h
 *
 *  Created on: 29.09.2016
 *      Author: ed
 */

#ifndef API_STATES_H_
#define API_STATES_H_

	#include "TypeDefs.h"

	typedef struct {
		u8 DISABLE;
		u8 ENABLE;
		u8 USE_GLOBAL_ENABLE;
	} DRIVER_STATE_T;

	extern DRIVER_STATE_T DRIVER_STATE;


#endif /* API_STATES_H_ */
