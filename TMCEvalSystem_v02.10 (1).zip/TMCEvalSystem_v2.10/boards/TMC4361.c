#include "squirrel.h"
#include "TMC4361.h"
#include "../tmc/boardAssignment.h"

static void readRegister(void);
static void writeRegister(void);
static void init(void);
static void deInit(void);
static void RotateRight(void);
static void RotateLeft(void);
static void MoveToPosition(void);
static void MotorStop(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void periodicJob(uint32 tick);
static void userFunction(void);

static int32 discardVelocityDecimals(int32 value);

static uint8 reset();

typedef struct
{
	IOPinTypeDef *TARGET_REACHED;
	IOPinTypeDef *NRST;
	IOPinTypeDef *FREEZE;
	IOPinTypeDef *START;
	IOPinTypeDef *HOME_REF;
	IOPinTypeDef *STOP_R;
	IOPinTypeDef *STOP_L;
	IOPinTypeDef *INTR;
	IOPinTypeDef *STANDBY_CLK;
} PinsTypeDef;

static PinsTypeDef Pins;

EvalBoardTypeDef TMC4361 = {init};

static int32 discardVelocityDecimals(int32 value)
{
	if(abs(value) > 8000000)
	{
		value = (value < 0) ? -8000000 : 8000000;
	}
	return (value<<8);
}

static void rotate()
{
	TMCSquirrel.writeInt(TMCSQUIRREL_RAMPMODE, TMCSQUIRREL_RAMP_HOLD | TMCSquirrel.rampMode);
	TMCSquirrel.writeInt(TMCSQUIRREL_VMAX, discardVelocityDecimals(TMCL.command->Value.Int32));
}

static void RotateRight(void)
{
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		rotate();
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void RotateLeft(void)
{
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		TMCL.command->Value.Int32 = -TMCL.command->Value.Int32;
		rotate();
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void MoveToPosition(void)
{
	int32 newPosition = 0;

	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				newPosition = TMCL.command->Value.Int32;
			break;

			case MVP_REL:
				newPosition = TMCSquirrel.readInt(TMCSquirrel.moveRelativeBy)	+ TMCL.command->Value.Int32;
			break;

			case MVP_PRF:
//				newPosition = TMCSquirrel.readInt(TMCSQUIRREL_ENC_POS) 			+ TMCL.command->Value.Int32;
			break;

			default:
				return;
			break;
		}
		TMCSquirrel.writeInt(TMCSQUIRREL_RAMPMODE, TMCSQUIRREL_RAMP_POSITION | TMCSquirrel.rampMode);
		TMCSquirrel.writeInt(TMCSQUIRREL_X_TARGET, newPosition);
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;


}

static void MotorStop(void)
{
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		TMCL.command->Value.Int32 = 0;
		rotate();
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
	uint32 uvalue;

	switch(TMCL.command->Type)
	{
		case 0:
			TMCSquirrel.writeInt( TMCSQUIRREL_X_TARGET, TMCL.command->Value.Int32);
		break;

		case 1:
			TMCSquirrel.writeInt( TMCSQUIRREL_XACTUAL, TMCL.command->Value.Int32);
		break;

		case 2:
			TMCSquirrel.writeInt( TMCSQUIRREL_VMAX, discardVelocityDecimals(TMCL.command->Value.Int32));
		break;

		case 3:
			TMCSquirrel.writeInt( TMCSQUIRREL_VACTUAL, TMCL.command->Value.Int32);
		break;

		case 4:
			TMCSquirrel.writeInt( TMCSQUIRREL_VMAX, discardVelocityDecimals(TMCL.command->Value.Int32));
		break;

		case 5:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_AMAX, TMCL.command->Value.Int32<<2);
		break;

//		case 6:
//			MotorConfig[TMCL.command->Motor].IRun=ActualCommand.value.Byte[0];
//			if(!ClosedLoopConfig[TMCL.command->Motor].ClosedLoopMode)
//			{
//				TMCSquirrel.writeDatagram( TMCSQUIRREL_SCALE_VALUES, MotorConfig[TMCL.command->Motor].IStandby, 0,
//													MotorConfig[TMCL.command->Motor].IRun, MotorConfig[TMCL.command->Motor].BoostCurrent);
//			}
//			else
//			{
//				Set262StallGuardCurrentScale(TMCL.command->Motor, ActualCommand.value.Byte[0]/8);
//			}
//		break;

//		case 7:
//			MotorConfig[TMCL.command->Motor].IStandby=ActualCommand.value.Byte[0];
//			if(!ClosedLoopConfig[TMCL.command->Motor].ClosedLoopMode)
//			{
//				TMCSquirrel.writeDatagram( TMCSQUIRREL_SCALE_VALUES, MotorConfig[TMCL.command->Motor].IStandby, 0,
//													MotorConfig[TMCL.command->Motor].IRun, MotorConfig[TMCL.command->Motor].BoostCurrent);
//			}
//		break;

//		case 12:
//			value = TMCSquirrel.readInt( TMCSQUIRREL_REFERENCE_CONF) & ~(TMCSQUIRREL_REFCONF_STOP_RIGHT_EN|TMCSQUIRREL_REFCONF_POL_STOP_RIGHT);
//			if(TMCL.command->Value.Int32 & BIT0) value|=TMCSQUIRREL_REFCONF_STOP_RIGHT_EN;
//			if(TMCL.command->Value.Int32 & BIT1) value|=TMCSQUIRREL_REFCONF_POL_STOP_RIGHT;
//			TMCSquirrel.writeInt( TMCSQUIRREL_REFERENCE_CONF, value);
//		break;

//		case 13:
//			value = TMCSquirrel.readInt( TMCSQUIRREL_REFERENCE_CONF) & ~(TMCSQUIRREL_REFCONF_STOP_LEFT_EN|TMCSQUIRREL_REFCONF_POL_STOP_LEFT);
//			if(TMCL.command->Value.Int32 & BIT0) value|=TMCSQUIRREL_REFCONF_STOP_LEFT_EN;
//			if(TMCL.command->Value.Int32 & BIT1) value|=TMCSQUIRREL_REFCONF_POL_STOP_LEFT;
//			TMCSquirrel.writeInt( TMCSQUIRREL_REFERENCE_CONF, value);
//		break;

		case 14:
				TMCSquirrel.rampMode = (TMCL.command->Value.Int32) ? TMCSQUIRREL_RAMP_SSHAPE : TMCSQUIRREL_RAMP_TRAPEZ;
		break;

		case 15:
			TMCSquirrel.writeInt( TMCSQUIRREL_VSTART, TMCL.command->Value.Int32);
		break;

		case 16:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_ASTART, TMCL.command->Value.Int32<<2);
		break;

		case 17:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_DMAX, TMCL.command->Value.Int32<<2);
		break;

		case 18:
			TMCSquirrel.writeInt( TMCSQUIRREL_VBREAK, TMCL.command->Value.Int32);
		break;

		case 19:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_DFINAL, TMCL.command->Value.Int32<<2);
		break;

		case 20:
			TMCSquirrel.writeInt( TMCSQUIRREL_VSTOP, TMCL.command->Value.Int32);
		break;

		case 21:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_DSTOP, TMCL.command->Value.Int32);
		break;

		case 22:
			TMCSquirrel.writeInt( TMCSQUIRREL_BOW1, TMCL.command->Value.Int32);
		break;

		case 23:
			TMCSquirrel.writeInt( TMCSQUIRREL_BOW2, TMCL.command->Value.Int32);
		break;

		case 24:
			TMCSquirrel.writeInt( TMCSQUIRREL_BOW3, TMCL.command->Value.Int32);
		break;

		case 25:
			TMCSquirrel.writeInt( TMCSQUIRREL_BOW4, TMCL.command->Value.Int32);
		break;

		case 26:
			TMCSquirrel.writeInt( TMCSQUIRREL_VIRT_STOP_LEFT, TMCL.command->Value.Int32);
		break;

		case 27:
			TMCSquirrel.writeInt( TMCSQUIRREL_VIRT_STOP_RIGHT, TMCL.command->Value.Int32);
		break;

		case 108:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_VMIN_EMF, TMCL.command->Value.Int32);
		break;

		case 109:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_VADD_EMF, TMCL.command->Value.Int32);
		break;

		case 110:
			uvalue = TMCSquirrel.readInt( TMCSQUIRREL_CL_BETA) & 0x000001ff;
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_BETA, uvalue|(TMCL.command->Value.Int32<<16));
		break;

		case 111:
			uvalue = TMCSquirrel.readInt( TMCSQUIRREL_CL_BETA) & 0x00ff0000;
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_BETA, uvalue|(TMCL.command->Value.Int32 & 0x1ff));
		break;

		case 112:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_OFFSET, TMCL.command->Value.Int32);
		break;

		case 113:
			uvalue = TMCSquirrel.readInt(TMCSQUIRREL_SCALE_VALUES) & ~(0xFF<<0);
			uvalue |= (TMCL.command->Value.Int32 & 0xFF) << 0;
			TMCSquirrel.writeInt(TMCSQUIRREL_SCALE_VALUES, uvalue);
		break;

		case 114:
			uvalue = TMCSquirrel.readInt(TMCSQUIRREL_SCALE_VALUES) & ~(0xFF<<8);
			uvalue |= (TMCL.command->Value.Int32 & 0xFF) << 0;
			TMCSquirrel.writeInt(TMCSQUIRREL_SCALE_VALUES, uvalue);
		break;

		case 115:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_VMAX_CALC_P, TMCL.command->Value.Int32);
		break;

		case 116:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_VMAX_CALC_I, TMCL.command->Value.Int32);
		break;

		case 117:
			uvalue = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_PID_I];
			uvalue &= ~(0x7FFF << 0);
			uvalue |= (TMCL.command->Value.Int32 & 0x7FFF) << 0;
			TMCSquirrel.writeInt(TMCSQUIRREL_PID_I, uvalue);
		break;

		case 118:
			uvalue = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_PID_I];
			uvalue &= ~(0xFF << 16);
			uvalue |= (TMCL.command->Value.Int32 & 0xFF) << 16;
			TMCSquirrel.writeInt(TMCSQUIRREL_PID_I, uvalue);
		break;

		case 119:
			TMCSquirrel.writeInt( TMCSQUIRREL_PID_DV_CLIP, TMCL.command->Value.Int32);
		break;

		case 120:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_UPSCALE_DELAY, TMCL.command->Value.Int32);
		break;

		case 121:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_DOWNSCALE_DELAY, TMCL.command->Value.Int32);
		break;

		case 124:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_DELTA_P, TMCL.command->Value.Int32);
		break;

		case 125:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_TOLERANCE, TMCL.command->Value.Int32);
		break;

		case 126:
			uvalue = TMCSquirrel.readInt(TMCSQUIRREL_SCALE_VALUES) & ~(0xFF<<16);
			uvalue |= (TMCL.command->Value.Int32 & 0xFF) << 0;
			TMCSquirrel.writeInt(TMCSQUIRREL_SCALE_VALUES, uvalue);
		break;

		case 129:	//Closed loop on/off
			if(TMCL.command->Value.Int32)
			{
				uvalue = TMCSquirrel.calibrateClosedLoop(1);
				TMCL.reply->Status 		= uvalue ? REPLY_OK : REPLY_DELAYED;;
				TMCL.reply->Value.Int32 = uvalue;
			}
			else
			{
				uvalue 	= TMCSquirrel.readInt(TMCSQUIRREL_ENC_IN_CONF);
				uvalue 	&= ~(1<<22);														// closed loop
				TMCSquirrel.writeInt(TMCSQUIRREL_ENC_IN_CONF, uvalue);
			}
		break;

		case 134:
			TMCSquirrel.writeInt( TMCSQUIRREL_CL_TR_TOLERANCE, TMCL.command->Value.Int32);
		break;

		case 136:
			uvalue = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_ENC_VMEAN_WAIT];
			uvalue &= ~(0xFF << 0);
			uvalue |= (TMCL.command->Value.Int32 & 0x0F) << 0;
			TMCSquirrel.writeInt(TMCSQUIRREL_ENC_VMEAN_WAIT, uvalue);
		break;

		case 137:
			uvalue = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_ENC_VMEAN_WAIT];
			uvalue &= ~(0xF << 8);
			uvalue |= (TMCL.command->Value.Int32 & 0x0F) << 8;
			TMCSquirrel.writeInt(TMCSQUIRREL_ENC_VMEAN_WAIT, uvalue);
		break;

		case 138:
			uvalue = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_ENC_VMEAN_WAIT];
			uvalue &= ~(0xFF << 16);
			uvalue |= (TMCL.command->Value.Int32 & 0x0FF) << 16;
			TMCSquirrel.writeInt(TMCSQUIRREL_ENC_VMEAN_WAIT, uvalue);
		break;

		case 200:
			uvalue = TMCSquirrel.readInt(TMCSQUIRREL_SCALE_VALUES) & ~(0xFF<<0);
			uvalue |= (TMCL.command->Value.Int32 & 0xFF) << 0;
			TMCSquirrel.writeInt(TMCSQUIRREL_SCALE_VALUES, uvalue);
		break;

		case 212:
			TMCSquirrel.writeInt( TMCSQUIRREL_ENC_POS_DEV_TOL, TMCL.command->Value.Int32);
		break;

//		case 213:
//			MotorConfig[TMCL.command->Motor].MaxVelocityDeviation=TMCL.command->Value.Int32;
//		break;

		case 214:
			TMCSquirrel.writeInt( TMCSQUIRREL_STDBY_DELAY, TMCL.command->Value.Int32*160000);
		break;

		default:
			TMCL.reply->Status=REPLY_WRONG_TYPE;
		break;
	}

}

static void GetAxisParameter(void)
{

	uint32 value;

	switch(TMCL.command->Type)
	{
		case 0:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_X_TARGET);
		break;

		case 1:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_XACTUAL);
		break;

		case 2:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VMAX);
		break;

		case 3:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VACTUAL);
		break;

		case 4:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VMAX);
		break;

		case 5:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_AMAX)>>2;
		break;

//		case 6:
//			TMCL.reply->Value.Int32 = MotorConfig[TMCL.command->Motor].IRun;
//		break;
//
//		case 7:
//			TMCL.reply->Value.Int32 = MotorConfig[TMCL.command->Motor].IStandby;
//		break;

		case 8:
			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt(TMCSQUIRREL_STATUS) & (1<<0)) ? 1:0;
		break;

//		case 9:
//			TMCL.reply->Value.Int32 = HOME_SWITCH() ? 1:0;
//		break;

//		case 10:
//			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt( TMCSQUIRREL_STATUS) & TMCSQUIRREL_ST_STOP_RIGHT_ACTIVE) ? 1:0;
//		break;

//		case 11:
//			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt( TMCSQUIRREL_STATUS) & TMCSQUIRREL_ST_STOP_LEFT_ACTIVE) ? 1:0;
//		break;

//		case 12:
//			value = TMCSquirrel.readInt( TMCSQUIRREL_REFERENCE_CONF);
//			if(value & TMCSQUIRREL_REFCONF_STOP_RIGHT_EN) TMCL.reply->Value.Int32|=BIT0;
//			if(value & TMCSQUIRREL_REFCONF_POL_STOP_RIGHT) TMCL.reply->Value.Int32|=BIT1;
//		break;

//		case 13:
//			value = TMCSquirrel.readInt( TMCSQUIRREL_REFERENCE_CONF);
//			if(value & TMCSQUIRREL_REFCONF_STOP_LEFT_EN) TMCL.reply->Value.Int32|=BIT0;
//			if(value & TMCSQUIRREL_REFCONF_POL_STOP_LEFT) TMCL.reply->Value.Int32|=BIT1;
//		break;

		case 14:
			TMCL.reply->Value.Int32 = TMCSquirrel.rampMode<<1;
		break;

		case 15:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VSTART);
		break;

		case 16:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_ASTART)>>2;
		break;

		case 17:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_DMAX)>>2;
		break;

		case 18:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VBREAK);
		break;

		case 19:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_DFINAL)>>2;
		break;

		case 20:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VSTOP);
		break;

		case 21:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_DSTOP);
		break;

		case 22:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_BOW1);
		break;

		case 23:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_BOW2);
		break;

		case 24:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_BOW3);
		break;

		case 25:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_BOW4);
		break;

		case 26:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VIRT_STOP_LEFT);
		break;

		case 27:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VIRT_STOP_RIGHT);
		break;

//		case 28:
//			value = TMCSquirrel.readInt( TMCSQUIRREL_REFERENCE_CONF);
//			if(value & TMCSQUIRREL_REFCONF_VIRT_LEFT_LIM_EN) TMCL.reply->Value.Int32|=BIT0;
//			if(value & TMCSQUIRREL_REFCONF_VIRT_RIGHT_LIM_EN) TMCL.reply->Value.Int32|=BIT1;
//		break;

//		case 29:
//			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt(TMCSQUIRREL_REFERENCE_CONF) >> 8) & 0x03;
//		break;

//		case 33:
//			value = TMCSquirrel.readInt(TMCSQUIRREL_REFERENCE_CONF);
//			TMCL.reply->Value.Int32 = (value & TMCSQUIRREL_REFCONF_INV_STOP_DIR) ? 1: 0;
//		break;

//		case 34:
//			value = TMCSquirrel.readInt(TMCSQUIRREL_REFERENCE_CONF);
//			if(value & TMCSQUIRREL_REFCONF_SOFT_STOP_EN)
//				TMCL.reply->Value.Int32 = 1;
//			else
//				TMCL.reply->Value.Int32 = 0;
//		break;

		case 108:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_VMIN_EMF);		// read from shadow register
		break;

		case 109:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_VADD_EMF); 	// read from shadow register
		break;

		case 110:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_BETA) >> 16;
		break;

		case 111:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_BETA) & 0xFF;
		break;

		case 112:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_OFFSET);
		break;

		case 113:
			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt(TMCSQUIRREL_SCALE_VALUES) >> 0) & 0xFF;
		break;

		case 114:
			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt(TMCSQUIRREL_SCALE_VALUES) >> 8) & 0xFF;
		break;

		case 115:
			TMCL.reply->Value.Int32 = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_CL_VMAX_CALC_P];
		break;

		case 116:
			TMCL.reply->Value.Int32 = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_CL_VMAX_CALC_I];
		break;

		case 117:
			TMCL.reply->Value.Int32 = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_PID_I] >> 0;
			TMCL.reply->Value.Int32 &= 0x7FFF;
		break;

		case 118:
			TMCL.reply->Value.Int32 = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_PID_I] >> 16;
			TMCL.reply->Value.Int32 &= 0xFF;
		break;


		case 119:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_PID_DV_CLIP);
		break;

		case 120:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_UPSCALE_DELAY);
		break;

		case 121:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_DOWNSCALE_DELAY);
		break;

		case 124:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_DELTA_P);
		break;

		case 125:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_CL_TOLERANCE);
		break;

		case 126:
			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt(TMCSQUIRREL_SCALE_VALUES) >> 16) & 0xFF;
		break;

//		case 127:
//			TMCL.reply->Value.Int32 = RelativePositioningOptionCode[TMCL.command->Motor];
//		break;

//		case 129:
//			TMCL.reply->Value.Int32 = ClosedLoopConfig[TMCL.command->Motor].ClosedLoopMode;
//		break;

//		case 131:
//			if(MotorConfig[TMCL.command->Motor].EncoderResolution==0)	//magnetischer Encoder
//				TMCL.reply->Value.Int32 = GetEncoderSpeed(TMCL.command->Motor);
//			else
//				TMCL.reply->Value.Int32 = TMCSquirrel.readInt( TMCSQUIRREL_VENC_MEAN);
//		break;

		case 132:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_V_ENC);
		break;

		case 133:
			value 	= TMCSquirrel.readInt(TMCSQUIRREL_ENC_IN_CONF);
			value 	>>= 22;
			value 	&= 3;
			TMCL.reply->Value.Int32 = (value == 1) ? 1 : 0;
		break;

		case 134:
			TMCL.reply->Value.Int32 = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_CL_TR_TOLERANCE];
		break;

		case 136:
			TMCL.reply->Value.Int32 = (TMCSquirrel.config->shadowRegister[TMCSQUIRREL_ENC_VMEAN_WAIT] >> 0) &  0xFF;
		break;

		case 137:
			TMCL.reply->Value.Int32 = (TMCSquirrel.config->shadowRegister[TMCSQUIRREL_ENC_VMEAN_WAIT] >> 8) &  0xF;
		break;

		case 138:
			TMCL.reply->Value.Int32 = (TMCSquirrel.config->shadowRegister[TMCSQUIRREL_ENC_VMEAN_WAIT] >> 16) &  0xFF;
		break;

		case 200:
			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt(TMCSQUIRREL_SCALE_VALUES) >> 0) & 0xFF;
		break;

		case 209:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_ENC_POS);
		break;

		case 212:
			TMCL.reply->Value.Int32 = TMCSquirrel.config->shadowRegister[TMCSQUIRREL_SCALE_VALUES];
		break;

//		case 213:
//			MotorConfig[TMCL.command->Motor].MaxVelocityDeviation=TMCL.command->Value.Int32;
//		break;

		case 214:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_STDBY_DELAY);
		break;

		default:
			TMCL.reply->Status=REPLY_WRONG_TYPE;
		break;
	}
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32	= TMCSquirrel.readInt(TMCL.command->Type);
}

static void writeRegister(void)
{
	TMCSquirrel.writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void periodicJob(uint32 tick)
{
	TMCSquirrel.periodicJob(tick);
	if(TMCSquirrel.config->isBusy) reset();
}

static void userFunction()
{
	uint32 	uvalue;
//	int32 	svalue;

	switch(TMCL.command->Type)
	{
		case 0:	// simulate left/right reference switches, set high to support external ref swiches
		/*
		 * The the TMC4361 ref switch input is pulled high by external resistor an can be pulled low either by
		 * this �C or external signal. To use external signal make sure the signals from �C are high or floating.
		 */
			if(!(TMCL.command->Value.Int32 & ~3))
			{
				if(TMCL.command->Value.Int32 & (1<<0)) HAL.IOs->config->toInput(Pins.STOP_R); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.STOP_R);
					HAL.IOs->config->setLow(Pins.STOP_R);
				}

				if(TMCL.command->Value.Int32 & (1<<1)) HAL.IOs->config->toInput(Pins.STOP_L); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.STOP_L);
					HAL.IOs->config->setLow(Pins.STOP_L);
				}
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;

		break;

		case 1:	// simulate reference switche HOME_REF, set high to support external ref swiches
			/*
			 * The the TMC43x1 ref switch input is pulled high by external resistor an can be pulled low either by
			 * this �C or external signal. To use external signal make sure the signals from �C are high or floating.
			 */

				if(TMCL.command->Value.Int32) HAL.IOs->config->toInput(Pins.HOME_REF); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.HOME_REF);
					HAL.IOs->config->setLow(Pins.HOME_REF);
				}
		break;

		case 2:	// simulate reference switche FREEZE, set high to support external ref swiches
			/*
			 * The the TMC43x1 ref switch input is pulled high by external resistor an can be pulled low either by
			 * this �C or external signal. To use external signal make sure the signals from �C are high or floating.
			 */

				if(TMCL.command->Value.Int32) HAL.IOs->config->toInput(Pins.FREEZE); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.FREEZE);
					HAL.IOs->config->setLow(Pins.FREEZE);
				}
		break;

		case 3:
			uvalue = TMCSquirrel.calibrateClosedLoop(1);
			TMCL.reply->Status 		= uvalue ? REPLY_OK : REPLY_DELAYED;;
			TMCL.reply->Value.Int32 = uvalue;
		break;

		case 255:
			EvalBoards.ch2.config->reset();
			EvalBoards.ch1.config->reset();
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void init(void)
{
	Pins.STANDBY_CLK 		= &HAL.IOs->pins->DIO4;
	Pins.INTR 				= &HAL.IOs->pins->DIO5;
	Pins.STOP_L				= &HAL.IOs->pins->DIO12;
	Pins.STOP_R 			= &HAL.IOs->pins->DIO13;
	Pins.HOME_REF 			= &HAL.IOs->pins->DIO14;
	Pins.START	 			= &HAL.IOs->pins->DIO15;
	Pins.FREEZE 			= &HAL.IOs->pins->DIO16;
	Pins.NRST 				= &HAL.IOs->pins->DIO17;
	Pins.TARGET_REACHED 	= &HAL.IOs->pins->DIO18;

	HAL.IOs->config->toOutput(Pins.NRST);
	HAL.IOs->config->toOutput(Pins.STOP_L);
	HAL.IOs->config->toOutput(Pins.STOP_R);
	HAL.IOs->config->toOutput(Pins.HOME_REF);
	HAL.IOs->config->toOutput(Pins.START);
	HAL.IOs->config->toOutput(Pins.FREEZE);

	HAL.IOs->config->setHigh(Pins.NRST);

	HAL.IOs->config->setHigh(Pins.STOP_L);
	HAL.IOs->config->setHigh(Pins.STOP_R);
	HAL.IOs->config->setHigh(Pins.HOME_REF);
	HAL.IOs->config->setHigh(Pins.START);
	HAL.IOs->config->setHigh(Pins.FREEZE);

	HAL.IOs->config->toInput(Pins.STANDBY_CLK);
	HAL.IOs->config->toInput(Pins.INTR);
	HAL.IOs->config->toInput(Pins.TARGET_REACHED);

	TMCSquirrel.SPIChannel 				= &HAL.SPI->ch1;
	TMCSquirrel.SPIChannel->CSN 		= &HAL.IOs->pins->SPI1_CSN;
	TMCSquirrel.config 					= EvalBoards.ch1.config;

	TMCSquirrel.rampMode				= TMCSQUIRREL_RAMP_TRAPEZ;

	EvalBoards.ch1.config->reset		= reset;

	EvalBoards.ch1.motorStop			= MotorStop;
	EvalBoards.ch1.getAxisParameter		= GetAxisParameter;
	EvalBoards.ch1.moveToPosition		= MoveToPosition;
	EvalBoards.ch1.rotateLeft			= RotateLeft;
	EvalBoards.ch1.rotateRight			= RotateRight;
	EvalBoards.ch1.setAxisParameter		= SetAxisParameter;
	EvalBoards.ch1.writeRegister		= writeRegister;
	EvalBoards.ch1.readRegister			= readRegister;
	EvalBoards.ch1.periodicJob			= periodicJob;
	EvalBoards.ch1.userFunction			= userFunction;
	EvalBoards.ch1.init					= init;
	EvalBoards.ch1.deInit				= deInit;
	EvalBoards.ch1.numberOfMotors		= 1;
	EvalBoards.numberOfMotors			= (EvalBoards.numberOfMotors < 1) ? 1 : EvalBoards.numberOfMotors;
};

static void deInit(void)
{
	HAL.IOs->config->setLow(Pins.NRST);

	HAL.IOs->config->reset(Pins.STOP_L);
	HAL.IOs->config->reset(Pins.STOP_R);
	HAL.IOs->config->reset(Pins.HOME_REF);
	HAL.IOs->config->reset(Pins.START);
	HAL.IOs->config->reset(Pins.FREEZE);
	HAL.IOs->config->reset(Pins.STANDBY_CLK);
	HAL.IOs->config->reset(Pins.INTR);
	HAL.IOs->config->reset(Pins.TARGET_REACHED);
	HAL.IOs->config->reset(Pins.NRST);

	HAL.SPI->ch2.reset();
}

static uint8 reset()
{
	uint32_t 	value;
	uint8_t 	driver = 0;

	if(!TMCSquirrel.config->isBusy)
	{
		HAL.IOs->config->setLow(Pins.NRST);
		TMCSquirrel.config->isBusy = 1;
	}
	else
	{
		HAL.IOs->config->setHigh(Pins.NRST);

		switch(EvalBoards.ch2.id)
		{
			case ID_TMC2130: 	driver = 0b1101;		break;
			case ID_TMC2660: 	driver = 0b1011;		break;
			default: 			driver = 0b1111;		break;
		}

		value = 	0;
		value |= 	(driver << 0);	// mode
		value |= 	(((EvalBoards.ch2.id == ID_TMC2660) ? 20 : 40)	<< 13);		// data length
		value |= 	(4 	<< 20);		// low time
		value |= 	(4 	<< 24);		// high time
		value |= 	(4 	<< 28);		// block time
		value |= 	(1 	<< 6);		// block polling


		TMCSquirrel.writeInt(TMCSQUIRREL_SPIOUT_CONF, 		value);

		value = 	0;
		value |= 	(4 << 0);		// STP_LENGTH
		TMCSquirrel.writeInt(TMCSQUIRREL_STP_LENGTH_ADD, 	value);

		TMCSquirrel.config->isBusy = 0;
		EvalBoards.ch2.config->reset();
	}
	return 1;
}
