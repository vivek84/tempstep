 #include "squirrel.h"
#include "TMC4331.h"
#include "../tmc/boardAssignment.h"

static void readRegister(void);
static void writeRegister(void);
static void init(void);
static void deInit(void);
static void RotateRight(void);
static void RotateLeft(void);
static void MoveToPosition(void);
static void MotorStop(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void periodicJob(uint32 tick);
static void userFunction(void);

static int32 discardVelocityDecimals(int32 value);

static uint8 reset();

typedef struct
{
	IOPinTypeDef *TARGET_REACHED;
	IOPinTypeDef *NRST;
	IOPinTypeDef *START;
	IOPinTypeDef *HOME_REF;
	IOPinTypeDef *STOP_R;
	IOPinTypeDef *STOP_L;
	IOPinTypeDef *INTR;
	IOPinTypeDef *STANDBY_CLK;
} PinsTypeDef;

static PinsTypeDef Pins;

EvalBoardTypeDef TMC4331 = {init};

static int32 discardVelocityDecimals(int32 value)
{
	if(abs(value) > 8000000)
	{
		value = (value < 0) ? -8000000 : 8000000;
	}
	return (value<<8);
}

static void rotate()
{
	TMCSquirrel.writeInt(TMCSQUIRREL_RAMPMODE, TMCSQUIRREL_RAMP_HOLD | TMCSquirrel.rampMode);
	TMCSquirrel.writeInt(TMCSQUIRREL_VMAX, discardVelocityDecimals(TMCL.command->Value.Int32));
}

static void RotateRight(void)
{
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		rotate();
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void RotateLeft(void)
{
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		TMCL.command->Value.Int32 = -TMCL.command->Value.Int32;
		rotate();
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void MoveToPosition(void)
{
	int32 newPosition = 0;

	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				newPosition = TMCL.command->Value.Int32;
			break;

			case MVP_REL:
				newPosition = TMCSquirrel.readInt(TMCSquirrel.moveRelativeBy)	+ TMCL.command->Value.Int32;
			break;

			case MVP_PRF:
//				newPosition = TMCSquirrel.readInt(TMCSQUIRREL_ENC_POS) 			+ TMCL.command->Value.Int32;
			break;

			default:
				return;
			break;
		}
		TMCSquirrel.writeInt(TMCSQUIRREL_RAMPMODE, TMCSQUIRREL_RAMP_POSITION | TMCSquirrel.rampMode);
		TMCSquirrel.writeInt(TMCSQUIRREL_X_TARGET, newPosition);
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;


}

static void MotorStop(void)
{
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		TMCL.command->Value.Int32 = 0;
		rotate();
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
//	uint32 uvalue;

	switch(TMCL.command->Type)
	{
		case 0:
			TMCSquirrel.writeInt( TMCSQUIRREL_X_TARGET, TMCL.command->Value.Int32);
		break;

		case 1:
			TMCSquirrel.writeInt( TMCSQUIRREL_XACTUAL, TMCL.command->Value.Int32);
		break;

		case 2:
			TMCSquirrel.writeInt( TMCSQUIRREL_VMAX, discardVelocityDecimals(TMCL.command->Value.Int32));
		break;

		case 3:
			TMCSquirrel.writeInt( TMCSQUIRREL_VACTUAL, TMCL.command->Value.Int32);
		break;

		case 4:
			TMCSquirrel.writeInt( TMCSQUIRREL_VMAX, discardVelocityDecimals(TMCL.command->Value.Int32));
		break;

		case 5:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_AMAX, TMCL.command->Value.Int32<<2);
		break;

		case 14:
				TMCSquirrel.rampMode = (TMCL.command->Value.Int32) ? TMCSQUIRREL_RAMP_SSHAPE : TMCSQUIRREL_RAMP_TRAPEZ;
		break;

		case 15:
			TMCSquirrel.writeInt( TMCSQUIRREL_VSTART, TMCL.command->Value.Int32);
		break;

		case 16:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_ASTART, TMCL.command->Value.Int32<<2);
		break;

		case 17:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_DMAX, TMCL.command->Value.Int32<<2);
		break;

		case 18:
			TMCSquirrel.writeInt( TMCSQUIRREL_VBREAK, TMCL.command->Value.Int32);
		break;

		case 19:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_DFINAL, TMCL.command->Value.Int32<<2);
		break;

		case 20:
			TMCSquirrel.writeInt( TMCSQUIRREL_VSTOP, TMCL.command->Value.Int32);
		break;

		case 21:
			if(TMCL.command->Value.Int32 & ~0x3FFFFF) TMCL.reply->Status = REPLY_INVALID_VALUE;
			else TMCSquirrel.writeInt( TMCSQUIRREL_DSTOP, TMCL.command->Value.Int32);
		break;

		case 22:
			TMCSquirrel.writeInt( TMCSQUIRREL_BOW1, TMCL.command->Value.Int32);
		break;

		case 23:
			TMCSquirrel.writeInt( TMCSQUIRREL_BOW2, TMCL.command->Value.Int32);
		break;

		case 24:
			TMCSquirrel.writeInt( TMCSQUIRREL_BOW3, TMCL.command->Value.Int32);
		break;

		case 25:
			TMCSquirrel.writeInt( TMCSQUIRREL_BOW4, TMCL.command->Value.Int32);
		break;

		case 26:
			TMCSquirrel.writeInt( TMCSQUIRREL_VIRT_STOP_LEFT, TMCL.command->Value.Int32);
		break;

		case 27:
			TMCSquirrel.writeInt( TMCSQUIRREL_VIRT_STOP_RIGHT, TMCL.command->Value.Int32);
		break;

		case 214:
			TMCSquirrel.writeInt( TMCSQUIRREL_STDBY_DELAY, TMCL.command->Value.Int32*160000);
		break;

		default:
			TMCL.reply->Status=REPLY_WRONG_TYPE;
		break;
	}

}

static void GetAxisParameter(void)
{

//	uint32 value;

	switch(TMCL.command->Type)
	{
		case 0:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_X_TARGET);
		break;

		case 1:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_XACTUAL);
		break;

		case 2:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VMAX);
		break;

		case 3:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VACTUAL);
		break;

		case 4:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VMAX);
		break;

		case 5:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_AMAX)>>2;
		break;

//		case 6:
//			TMCL.reply->Value.Int32 = MotorConfig[TMCL.command->Motor].IRun;
//		break;
//
//		case 7:
//			TMCL.reply->Value.Int32 = MotorConfig[TMCL.command->Motor].IStandby;
//		break;

		case 8:
			TMCL.reply->Value.Int32 = (TMCSquirrel.readInt(TMCSQUIRREL_STATUS) & (1<<0)) ? 1:0;
		break;

		case 14:
			TMCL.reply->Value.Int32 = TMCSquirrel.rampMode<<1;
		break;

		case 15:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VSTART);
		break;

		case 16:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_ASTART)>>2;
		break;

		case 17:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_DMAX)>>2;
		break;

		case 18:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VBREAK);
		break;

		case 19:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_DFINAL)>>2;
		break;

		case 20:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VSTOP);
		break;

		case 21:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_DSTOP);
		break;

		case 22:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_BOW1);
		break;

		case 23:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_BOW2);
		break;

		case 24:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_BOW3);
		break;

		case 25:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_BOW4);
		break;

		case 26:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VIRT_STOP_LEFT);
		break;

		case 27:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_VIRT_STOP_RIGHT);
		break;

		case 214:
			TMCL.reply->Value.Int32 = TMCSquirrel.readInt(TMCSQUIRREL_STDBY_DELAY);
		break;

		default:
			TMCL.reply->Status=REPLY_WRONG_TYPE;
		break;
	}
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32	= TMCSquirrel.readInt(TMCL.command->Type);
}

static void writeRegister(void)
{
	TMCSquirrel.writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void periodicJob(uint32 tick)
{
	TMCSquirrel.periodicJob(tick);
	if(TMCSquirrel.config->isBusy) reset();
}

static void userFunction()
{
//	uint32 	uvalue;
//	int32 	svalue;

	switch(TMCL.command->Type)
	{
		case 0:	// simulate left/right reference switches, set high to support external ref swiches
		/*
		 * The the TMC4361 ref switch input is pulled high by external resistor an can be pulled low either by
		 * this �C or external signal. To use external signal make sure the signals from �C are high or floating.
		 */
			if(!(TMCL.command->Value.Int32 & ~3))
			{
				if(TMCL.command->Value.Int32 & (1<<0)) HAL.IOs->config->toInput(Pins.STOP_R); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.STOP_R);
					HAL.IOs->config->setLow(Pins.STOP_R);
				}

				if(TMCL.command->Value.Int32 & (1<<1)) HAL.IOs->config->toInput(Pins.STOP_L); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.STOP_L);
					HAL.IOs->config->setLow(Pins.STOP_L);
				}
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;

		break;

		case 1:	// simulate reference switche HOME_REF, set high to support external ref swiches
			/*
			 * The the TMC43x1 ref switch input is pulled high by external resistor an can be pulled low either by
			 * this �C or external signal. To use external signal make sure the signals from �C are high or floating.
			 */

				if(TMCL.command->Value.Int32) HAL.IOs->config->toInput(Pins.HOME_REF); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.HOME_REF);
					HAL.IOs->config->setLow(Pins.HOME_REF);
				}
		break;

		case 255:
			EvalBoards.ch2.config->reset();
			EvalBoards.ch1.config->reset();
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void init(void)
{
	Pins.STANDBY_CLK 		= &HAL.IOs->pins->DIO4;
	Pins.INTR 				= &HAL.IOs->pins->DIO5;
	Pins.STOP_L				= &HAL.IOs->pins->DIO12;
	Pins.STOP_R 			= &HAL.IOs->pins->DIO13;
	Pins.HOME_REF 			= &HAL.IOs->pins->DIO14;
	Pins.START	 			= &HAL.IOs->pins->DIO15;
	Pins.NRST 				= &HAL.IOs->pins->DIO17;
	Pins.TARGET_REACHED 	= &HAL.IOs->pins->DIO18;

	HAL.IOs->config->toOutput(Pins.NRST);
	HAL.IOs->config->toOutput(Pins.STOP_L);
	HAL.IOs->config->toOutput(Pins.STOP_R);
	HAL.IOs->config->toOutput(Pins.HOME_REF);
	HAL.IOs->config->toOutput(Pins.START);

	HAL.IOs->config->setHigh(Pins.NRST);
	HAL.IOs->config->setHigh(Pins.STOP_L);
	HAL.IOs->config->setHigh(Pins.STOP_R);
	HAL.IOs->config->setHigh(Pins.HOME_REF);
	HAL.IOs->config->setHigh(Pins.START);

	HAL.IOs->config->toInput(Pins.STANDBY_CLK);
	HAL.IOs->config->toInput(Pins.INTR);
	HAL.IOs->config->toInput(Pins.TARGET_REACHED);

	TMCSquirrel.SPIChannel 				= &HAL.SPI->ch1;
	TMCSquirrel.SPIChannel->CSN 		= &HAL.IOs->pins->SPI1_CSN;
	TMCSquirrel.config 					= EvalBoards.ch1.config;

	TMCSquirrel.rampMode				= TMCSQUIRREL_RAMP_TRAPEZ;

	EvalBoards.ch1.config->reset		= reset;

	EvalBoards.ch1.motorStop			= MotorStop;
	EvalBoards.ch1.getAxisParameter		= GetAxisParameter;
	EvalBoards.ch1.moveToPosition		= MoveToPosition;
	EvalBoards.ch1.rotateLeft			= RotateLeft;
	EvalBoards.ch1.rotateRight			= RotateRight;
	EvalBoards.ch1.setAxisParameter		= SetAxisParameter;
	EvalBoards.ch1.writeRegister		= writeRegister;
	EvalBoards.ch1.readRegister			= readRegister;
	EvalBoards.ch1.periodicJob			= periodicJob;
	EvalBoards.ch1.userFunction			= userFunction;
	EvalBoards.ch1.init					= init;
	EvalBoards.ch1.deInit				= deInit;
	EvalBoards.ch1.numberOfMotors		= 1;
	EvalBoards.numberOfMotors			= (EvalBoards.numberOfMotors < 1) ? 1 : EvalBoards.numberOfMotors;
};

static void deInit(void)
{
	HAL.IOs->config->setLow(Pins.NRST);

	HAL.IOs->config->reset(Pins.STOP_L);
	HAL.IOs->config->reset(Pins.STOP_R);
	HAL.IOs->config->reset(Pins.HOME_REF);
	HAL.IOs->config->reset(Pins.START);
	HAL.IOs->config->reset(Pins.STANDBY_CLK);
	HAL.IOs->config->reset(Pins.INTR);
	HAL.IOs->config->reset(Pins.TARGET_REACHED);
	HAL.IOs->config->reset(Pins.NRST);

	HAL.SPI->ch2.reset();
}

static uint8 reset()
{
	uint32_t 	value;
	uint8_t 	driver = 0;

	if(!TMCSquirrel.config->isBusy)
	{
		HAL.IOs->config->setLow(Pins.NRST);
		TMCSquirrel.config->isBusy = 1;
	}
	else
	{
		HAL.IOs->config->setHigh(Pins.NRST);

		switch(EvalBoards.ch2.id)
		{
			case ID_TMC2130: 	driver = 0b1101;		break;
			case ID_TMC2660: 	driver = 0b1011;		break;
			default: 			driver = 0b1111;		break;
		}

		value = 	0;
		value |= 	(driver << 0);	// mode
		value |= 	(((EvalBoards.ch2.id == ID_TMC2660) ? 20 : 40)	<< 13);		// data length
		value |= 	(4 	<< 20);		// low time
		value |= 	(4 	<< 24);		// high time
		value |= 	(4 	<< 28);		// block time
		value |= 	(1 	<< 6);		// block polling


		TMCSquirrel.writeInt(TMCSQUIRREL_SPIOUT_CONF, 		value);

		value = 	0;
		value |= 	(4 << 0);		// STP_LENGTH
		TMCSquirrel.writeInt(TMCSQUIRREL_STP_LENGTH_ADD, 	value);

		TMCSquirrel.config->isBusy = 0;
		EvalBoards.ch2.config->reset();
	}
	return 1;
}
