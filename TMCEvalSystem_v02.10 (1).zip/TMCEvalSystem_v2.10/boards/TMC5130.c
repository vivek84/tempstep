#include "rhino.h"
#include "TMC5130.h"
#include "../tmc/boardAssignment.h"

#define ERRORS_VM 		(1<<0)
#define ERRORS_VM_UNDER (1<<1)
#define ERRORS_VM_OVER 	(1<<2)

#define VM_MIN			50	// VM[V/10] min
#define VM_MAX			480	// VM[V/10] max

static int VMax[1];
static uint8 VMaxModified[1];

static void RotateRight(void);
static void RotateLeft(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void writeRegister(void);
static void readRegister(void);
static void periodicJob(uint32 tick);
static void checkErrors(uint32 tick);
static void init(void);
static void deInit(void);
static void userFunction(void);

static void rotate(void);
static uint8 reset();
static void enableDriver(uint8 disable0Enable1global2);


EvalBoardTypeDef TMC5130 = {.init = init};

typedef struct
{
	IOPinTypeDef *REFL_UC;
	IOPinTypeDef *REFR_UC;
	IOPinTypeDef *DRV_ENN_CFG6;
	IOPinTypeDef *ENCA_DCIN_CFG5;
	IOPinTypeDef *ENCB_DCEN_CFG4;
	IOPinTypeDef *ENCN_DCO;

	IOPinTypeDef *SWSEL;
	IOPinTypeDef *SWN_DIAG0;
	IOPinTypeDef *SWP_DIAG1;

	IOPinTypeDef *AIN_REF_SW;
	IOPinTypeDef *AIN_REF_PWM;
} PinsTypeDef;

static PinsTypeDef Pins;

static void rotate()
{
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		TMCRhino.writeInt(TMCRhino_VMAX, abs(TMCL.command->Value.Int32));
		VMaxModified[TMCL.command->Motor]=TRUE;
		if(TMCL.command->Value.Int32 >= 0)
		{
			TMCRhino.writeDatagram(TMCRhino_RAMPMODE, 0, 0, 0, TMCRhino_MODE_VELPOS);
		}
		else
		{
			TMCRhino.writeDatagram(TMCRhino_RAMPMODE, 0, 0, 0, TMCRhino_MODE_VELNEG);
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;

}

static void RotateRight(void)
{
	TMCL.command->Value.Int32 = (TMCL.command->Value.Int32);
	rotate();
}

static void RotateLeft(void)
{
	TMCL.command->Value.Int32 = -(TMCL.command->Value.Int32);
	rotate();
}

static void MotorStop(void)
{
	TMCL.command->Value.Int32 = 0;
	rotate();
}

static void MoveToPosition(void)
{
	int ActPos;

	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				TMCL.reply->Value.Int32 =TMCL.command->Value.Int32;
				TMCRhino.writeInt(TMCRhino_XTARGET, TMCL.command->Value.Int32);
				TMCRhino.writeDatagram(TMCRhino_RAMPMODE, 0, 0, 0, TMCRhino_MODE_POSITION);
				if(VMaxModified[TMCL.command->Motor])
				{
					TMCRhino.writeInt(TMCRhino_VMAX, VMax[TMCL.command->Motor]);
					VMaxModified[TMCL.command->Motor]	=	FALSE;
				}
			break;

			case MVP_REL:
				ActPos=TMCRhino.readInt(TMCRhino_XACTUAL);
				TMCRhino.writeInt(TMCRhino_XTARGET, ActPos+TMCL.command->Value.Int32);
				TMCRhino.writeDatagram(TMCRhino_RAMPMODE, 0, 0, 0, TMCRhino_MODE_POSITION);
				if(VMaxModified[TMCL.command->Motor])
				{
					TMCRhino.writeInt(TMCRhino_VMAX, VMax[TMCL.command->Motor]);
					VMaxModified[TMCL.command->Motor]=FALSE;
				}
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
	uint32 value;

	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				TMCRhino.writeInt(TMCRhino_XTARGET, TMCL.command->Value.Int32);
			break;

			case 1:
				TMCRhino.writeInt(TMCRhino_XACTUAL, TMCL.command->Value.Int32);
			break;

			case 2:
				VMaxModified[TMCL.command->Motor]=TRUE;
				TMCRhino.writeInt(TMCRhino_VMAX, abs(TMCL.command->Value.Int32));
			break;

			case 4:
				VMax[TMCL.command->Motor]=abs(TMCL.command->Value.Int32);
				if(TMCRhino.readInt(TMCRhino_RAMPMODE)==TMCRhino_MODE_POSITION)	TMCRhino.writeInt(TMCRhino_VMAX, abs(TMCL.command->Value.Int32));
			break;

			case 5:
				TMCRhino.writeInt(TMCRhino_AMAX, TMCL.command->Value.Int32);
			break;

			case 6:
				value	= TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
				TMCRhino.writeDatagram(TMCRhino_IHOLD_IRUN, 0, value >> 16, TMCL.command->Value.Byte[0], value & 0xff);
			break;

			case 7:
				value	= TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
				TMCRhino.writeDatagram(TMCRhino_IHOLD_IRUN, 0, value >> 16,value >> 8, TMCL.command->Value.Byte[0]);
			break;


			case 12:
				value	= TMCRhino.readInt(TMCRhino_SWMODE);
				if(TMCL.command->Value.Int32==0)	TMCRhino.writeInt(TMCRhino_SWMODE, value | TMCRhino_SW_STOPR_ENABLE);
				else 								TMCRhino.writeInt(TMCRhino_SWMODE, value & ~TMCRhino_SW_STOPR_ENABLE);
			break;

			case 13:
				value	= TMCRhino.readInt(TMCRhino_SWMODE);
				if(TMCL.command->Value.Int32==0)	TMCRhino.writeInt(TMCRhino_SWMODE, value | TMCRhino_SW_STOPL_ENABLE);
				else								TMCRhino.writeInt(TMCRhino_SWMODE, value & ~TMCRhino_SW_STOPL_ENABLE);
			break;

			case 14:
				TMCRhino.writeInt(TMCRhino_SWMODE, TMCL.command->Value.Int32);
			break;

			case 15:
				TMCRhino.writeInt(TMCRhino_A1, TMCL.command->Value.Int32);
			break;

			case 16:
				TMCRhino.writeInt(TMCRhino_V1, TMCL.command->Value.Int32);
			break;

			case 17:
				TMCRhino.writeInt(TMCRhino_DMAX, TMCL.command->Value.Int32);
			break;

			case 18:
				TMCRhino.writeInt(TMCRhino_D1, TMCL.command->Value.Int32);
			break;

			case 19:
				TMCRhino.writeInt(TMCRhino_VSTART, TMCL.command->Value.Int32);
			break;

			case 20:
				TMCRhino.writeInt(TMCRhino_VSTOP, TMCL.command->Value.Int32);
			break;

			case 21:
				TMCRhino.writeInt(TMCRhino_TZEROCROSS, TMCL.command->Value.Int32);
			break;

			case 22:
				value = (TMCL.command->Value.Int32) ? TMCL.command->Value.Int32 : 1;
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
				TMCRhino.writeInt(TMCRhino_TCOOLTHRS, value);

				TMCL.reply->Value.Int32 = value;
			break;

			case 23:
				value = (TMCL.command->Value.Int32) ? TMCL.command->Value.Int32 : 1;
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
				TMCRhino.writeInt(TMCRhino_THIGH, value);

				TMCL.reply->Value.Int32 = value;
			break;

			case 24:
				TMCRhino.writeInt(TMCRhino_VDCMIN, TMCL.command->Value.Int32);
			break;

			case 28:
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x01<<18);
				if(TMCL.command->Value.Int32) value |= (0x01<<18);
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			break;

			case 33:
				value = TMCRhino.readInt(TMCRhino_GCONF);
				value &= ~(1<<0);
				value |= (TMCL.command->Value.Int32) ? 1 : 0;
				TMCRhino.writeInt(TMCRhino_GCONF, value);
			break;

			case 34:
				value = TMCRhino.readInt(TMCRhino_GCONF);
				value &= ~(1<<1);
				value |= (TMCL.command->Value.Int32) ? 1 : 0;
				TMCRhino.writeInt(TMCRhino_GCONF, value);
			break;

			case 140:
				switch(TMCL.command->Value.Int32)
				{
					case 1:	 	TMCL.command->Value.Int32 = 8; break;
					case 2:	 	TMCL.command->Value.Int32 = 7; break;
					case 4:	 	TMCL.command->Value.Int32 = 6; break;
					case 8:	 	TMCL.command->Value.Int32 = 5; break;
					case 16:	TMCL.command->Value.Int32 = 4; break;
					case 32:	TMCL.command->Value.Int32 = 3; break;
					case 64:	TMCL.command->Value.Int32 = 2; break;
					case 128:	TMCL.command->Value.Int32 = 1; break;
					case 256:	TMCL.command->Value.Int32 = 0; break;
					default: 	TMCL.command->Value.Int32 = -1; break;
				}

				if(TMCL.command->Value.Int32 != -1)
				{
					value = TMCRhino.readInt(TMCRhino_CHOPCONF);
					value &= ~(0x0F<<24);
					value |= (TMCL.command->Value.Int32 & 0xF) << 24;
					TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
				}
				else TMCL.reply->Status = REPLY_INVALID_VALUE;
			break;

			case 162:
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x03<<15);
				value |= (TMCL.command->Value.Int32 & 0x3) << 15;
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			break;

			case 163:
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x01<<14);
				if(TMCL.command->Value.Int32) value |= (0x01<<14);
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			break;

			case 164:
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x01<<12);
				if(TMCL.command->Value.Int32) value |= (0x01<<12);
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			break;

			case 165:
				if(TMCRhino.readInt(TMCRhino_CHOPCONF) & (1<<14))
				{
					value = TMCRhino.readInt(TMCRhino_CHOPCONF);
					value &= ~(0x0F<<7);
					value |= (TMCL.command->Value.Int32 & 0x0F) << 7;
					TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
				}
				else
				{
					value = TMCRhino.readInt(TMCRhino_CHOPCONF);

					if(TMCL.command->Value.Int32 & (1<<3)) value |= (0x01<<11);
					else value &= ~(0x01<<11);

					value &= ~(0x07<<4);
					value |=  (TMCL.command->Value.Int32 & 0x0F) << 4;

					TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
				}
			break;

			case 166:
				if(TMCRhino.readInt(TMCRhino_CHOPCONF) & (1<<14))
				{
					value = TMCRhino.readInt(TMCRhino_CHOPCONF);
					value &= ~(0x07<<4);
					value |= (TMCL.command->Value.Int32 & 0x07) << 4;
					TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
				}
				else
				{
					value = TMCRhino.readInt(TMCRhino_CHOPCONF);
					value &= ~(0x0F<<7);
					value |= (TMCL.command->Value.Int32 & 0x0F) << 7;
					TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
				}
			break;

			case 167:
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x0F<<0);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 0;
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			break;

			case 168:
				value = TMCRhino.readInt(TMCRhino_COOLCONF);
				value &= ~(0x01<<15);
				if(TMCL.command->Value.Int32) value |= (0x01<<15);
				TMCRhino.writeInt(TMCRhino_COOLCONF,value);
			break;

			case 169:
				value = TMCRhino.readInt(TMCRhino_COOLCONF);
				value &= ~(0x03<<13);
				value |= (TMCL.command->Value.Int32 & 0x03) << 13;
				TMCRhino.writeInt(TMCRhino_COOLCONF,value);
			break;

			case 170:
				value = TMCRhino.readInt(TMCRhino_COOLCONF);
				value &= ~(0x0F<<8);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 8;
				TMCRhino.writeInt(TMCRhino_COOLCONF,value);
			break;

			case 171:
				value = TMCRhino.readInt(TMCRhino_COOLCONF);
				value &= ~(0x03<<5);
				value |= (TMCL.command->Value.Int32 & 0x03) << 5;
				TMCRhino.writeInt(TMCRhino_COOLCONF,value);
			break;

			case 172:
				value = TMCRhino.readInt(TMCRhino_COOLCONF);
				value &= ~(0x0F<<0);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 0;
				TMCRhino.writeInt(TMCRhino_COOLCONF,value);
			break;

			case 173:
				value = TMCRhino.readInt(TMCRhino_COOLCONF);
				value &= ~(0x01<<24);
				if(TMCL.command->Value.Int32) value |= (0x01<<24);
				TMCRhino.writeInt(TMCRhino_COOLCONF,value);
			break;

			case 174:
				value = TMCRhino.readInt(TMCRhino_COOLCONF);
				value &= ~(0x07F<<16);
				value |= (TMCL.command->Value.Int32 & 0x07F) << 16;
				TMCRhino.writeInt(TMCRhino_COOLCONF,value);
			break;

			case 179:
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x01<<17);
				if(TMCL.command->Value.Int32) value |= (0x01<<17);
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			break;

			case 181:
				value = (TMCL.command->Value.Int32) ? TMCL.command->Value.Int32 : 1;
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
				TMCRhino.writeInt(TMCRhino_TCOOLTHRS, value);

				TMCL.reply->Value.Int32 = value;

				value = TMCRhino.readInt(TMCRhino_SWMODE);
				value &= ~(1<<10);
				TMCRhino.writeInt(TMCRhino_SWMODE, value);
				value |= (TMCL.command->Value.Int32) ? (1<<10) : 0;

				TMCRhino.writeInt(TMCRhino_SWMODE, value);
			break;

			case 182:
				value = (TMCL.command->Value.Int32) ? TMCL.command->Value.Int32 : 1;
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
				TMCRhino.writeInt(TMCRhino_TCOOLTHRS, value);
				TMCL.reply->Value.Int32 = value;
			break;

			case 184:
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x01<<13);
				if(TMCL.command->Value.Int32) value |= (0x01<<13);
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			break;

			case 185:
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				value &= ~(0x0F<<20);
				value |= (TMCL.command->Value.Int32 & 0x0F) << 20;
				TMCRhino.writeInt(TMCRhino_CHOPCONF,value);
			break;

			case 209:
				TMCRhino.writeInt(TMCRhino_XENC,TMCL.command->Value.Int32);
			break;

			case 210:
				TMCRhino.writeInt(TMCRhino_ENC_CONST,TMCL.command->Value.Int32);
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_WRONG_TYPE;
}

static void GetAxisParameter(void)
{
  uint32 value;

  if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
  {
    switch(TMCL.command->Type)
    {
    	case 0:
    		TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_XTARGET);
        break;

      case 1:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_XACTUAL);
        break;

      case 2:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_VMAX);
        break;

      case 3:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_VACTUAL);
        break;

      case 4:
        TMCL.reply->Value.Int32=VMax[TMCL.command->Motor];
        break;

      case 5:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_AMAX);
        break;

      case 6:
        value=TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
        TMCL.reply->Value.Int32=(value>>8) & 0xff;
        break;

      case 7:
        value=TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
        TMCL.reply->Value.Int32=value & 0xff;
        break;

      case 8:
        TMCL.reply->Value.Int32=(TMCRhino.readInt(TMCRhino_RAMPSTAT) & TMCRhino_RS_POSREACHED) ? 1:0;
        break;

      case 10:
        TMCL.reply->Value.Int32=(TMCRhino.readInt(TMCRhino_RAMPSTAT) & TMCRhino_RS_STOPR) ? 0:1;
        break;

      case 11:
        TMCL.reply->Value.Int32=(TMCRhino.readInt(TMCRhino_RAMPSTAT) & TMCRhino_RS_STOPL) ? 0:1;
        break;

      case 12:
        TMCL.reply->Value.Int32=(TMCRhino.readInt(TMCRhino_SWMODE) & TMCRhino_SW_STOPR_ENABLE) ? 1:0;
        break;

      case 13:
        TMCL.reply->Value.Int32=(TMCRhino.readInt(TMCRhino_SWMODE) & TMCRhino_SW_STOPL_ENABLE) ? 1:0;
        break;

      case 14:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_SWMODE);
        break;

      case 15:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_A1);
        break;

      case 16:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_V1);
        break;

      case 17:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_DMAX);
        break;

      case 18:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_D1);
        break;

      case 19:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_VSTART);
        break;

      case 20:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_VSTOP);
        break;

      case 21:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_TZEROCROSS);
        break;

      case 22:
		value = TMCRhino.readInt(TMCRhino_TCOOLTHRS);
		value = (value) ? value : 1;
		value = (1<<24)/value;
		value = (value > 0xFFFFF) ? 0xFFFFF : value;
		TMCL.reply->Value.Int32 = value;
      break;

      case 23:
		value = TMCRhino.readInt(TMCRhino_THIGH);
		value = (value) ? value : 1;
		value = (1<<24)/value;
		value = (value > 0xFFFFF) ? 0xFFFFF : value;
		TMCL.reply->Value.Int32 = value;
      break;

      case 24:
        TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_VDCMIN);
		break;

		case 28:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 18) & 0x01;
		break;

		case 29:
			TMCL.reply->Value.Int32 = TMCRhino.velocity;
		break;

		case 33:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_GCONF) >> 0) & 1;
		break;

		case 34:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_GCONF) >> 1) & 1;
		break;

		case 140:
			TMCL.reply->Value.Int32 = 256>>((TMCRhino.readInt(TMCRhino_CHOPCONF) >> 24) & 0x0F);
		break;

		case 162:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 15) & 0x03;
		break;

		case 163:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 14) & 0x01;
		break;

		case 164:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 12) & 0x01;
		break;

		case 165:
			if(TMCRhino.readInt(TMCRhino_CHOPCONF) & (1<<14))
			{
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 7) & 0x0F;
			}
			else
			{
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 4) & 0x07;
				if(value & (1<<11)) TMCL.reply->Value.Int32 |= 1<<3;
			}
		break;

		case 166:
			if(TMCRhino.readInt(TMCRhino_CHOPCONF) & (1<<14))
			{
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 4) & 0x07;
			}
			else
			{
				value = TMCRhino.readInt(TMCRhino_CHOPCONF);
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 7) & 0x0F;
				if(value & (1<<11)) TMCL.reply->Value.Int32 |= 1<<3;
			}
		break;

		case 167:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 0) & 0x0F;
		break;

		case 168:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 15) & 0x01;
		break;

		case 169:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 13) & 0x03;
		break;

		case 170:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 8) & 0x0F;
		break;

		case 171:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 5) & 0x03;
		break;

		case 172:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 0) & 0x0F;
		break;

		case 173:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 24) & 0x01;
		break;

		case 174:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_COOLCONF) >> 16) & 0x7F;
			TMCL.reply->Value.Int32 |= (TMCL.reply->Value.Int32 & (1<<6)) ? 0xFFFFFF80 : 0;
		break;

		case 179:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 17) & 0x01;
		break;

		case 180:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_DRVSTATUS) >> 16) & 0x01F;
		break;

		case 181:
			if(TMCRhino.readInt(TMCRhino_SWMODE) & (1<<10))
			{
				value = TMCRhino.readInt(TMCRhino_TCOOLTHRS);
				value = (value) ? value : 1;
				value = (1<<24)/value;
				value = (value > 0xFFFFF) ? 0xFFFFF : value;
			}
			else value = 0;

			TMCL.reply->Value.Int32 = value;
		break;

		case 182:
			value = TMCRhino.readInt(TMCRhino_TCOOLTHRS);
			value = (value) ? value : 1;
			value = (1<<24)/value;
			value = (value > 0xFFFFF) ? 0xFFFFF : value;
			TMCL.reply->Value.Int32 = value;
		break;

		case 184:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 13) & 0x01;
		break;

		case 185:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_CHOPCONF) >> 20) & 0x0F;
		break;

		case 206:
			TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_DRVSTATUS) >> 0) & 0x03FF;
		break;

		case 209:
			TMCL.reply->Value.Int32 = TMCRhino.readInt(TMCRhino_XENC);
		break;

		case 210: 	// M�TZCHEN
			TMCL.reply->Value.Int32 = TMCRhino.readInt(TMCRhino_ENC_CONST);
		break;

		default:
			TMCL.reply->Status=REPLY_WRONG_TYPE;
		break;
    }
  }
  else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void getMeasuredSpeed(void)
{
	switch(TMCL.command->Motor)
	{
		case 0:
			TMCL.reply->Value.Int32 	= TMCRhino.velocity;
		break;

		default:
			TMCL.reply->Status 			= REPLY_WRONG_TYPE;
		break;
	}
}

static void writeRegister(void)
{
  TMCRhino.writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void readRegister(void)
{
  TMCL.reply->Value.Int32 = TMCRhino.readInt(TMCL.command->Type);
}

static void periodicJob(uint32 tick)
{
	TMCRhino.periodicJob(tick);
}

static void checkErrors(uint32 tick)
{
	UNUSED(tick);
	EvalBoards.ch1.errors = 0;
}

static void init(void)
{
	Pins.DRV_ENN_CFG6 	= &HAL.IOs->pins->DIO0;

	Pins.ENCN_DCO	 	= &HAL.IOs->pins->DIO1;
	Pins.ENCA_DCIN_CFG5 = &HAL.IOs->pins->DIO2;
	Pins.ENCB_DCEN_CFG4	= &HAL.IOs->pins->DIO3;

	Pins.REFL_UC		= &HAL.IOs->pins->DIO6;
	Pins.REFR_UC		= &HAL.IOs->pins->DIO7;
	Pins.AIN_REF_SW		= &HAL.IOs->pins->DIO10;
	Pins.AIN_REF_PWM	= &HAL.IOs->pins->DIO11;

	Pins.SWSEL 			= &HAL.IOs->pins->DIO14;
	Pins.SWP_DIAG1		= &HAL.IOs->pins->DIO15;
	Pins.SWN_DIAG0		= &HAL.IOs->pins->DIO16;


	HAL.IOs->config->toInput(Pins.ENCN_DCO);
	HAL.IOs->config->toInput(Pins.ENCB_DCEN_CFG4);
	HAL.IOs->config->toInput(Pins.ENCA_DCIN_CFG5);


	HAL.IOs->config->toInput(Pins.SWN_DIAG0);
	HAL.IOs->config->toInput(Pins.SWP_DIAG1);
	HAL.IOs->config->toOutput(Pins.SWSEL);
	HAL.IOs->config->toInput(Pins.REFL_UC);
	HAL.IOs->config->toInput(Pins.REFR_UC);
	HAL.IOs->config->toOutput(Pins.DRV_ENN_CFG6);
	HAL.IOs->config->toOutput(Pins.AIN_REF_SW);
	HAL.IOs->config->toOutput(Pins.AIN_REF_PWM);

	HAL.IOs->config->setLow(Pins.SWSEL);

	TMCRhino.SPIChannel					= &HAL.SPI->ch1;
	TMCRhino.SPIChannel->CSN			= &HAL.IOs->pins->SPI1_CSN;
	TMCRhino.config 					= EvalBoards.ch1.config;

	EvalBoards.ch1.config->reset		= reset;
	EvalBoards.ch1.config->restore		= TMCRhino.restore;
	EvalBoards.ch1.config->isBusy 		= 0;
	EvalBoards.ch1.config->ptr	 		= 0;

	EvalBoards.ch1.motorStop			= MotorStop;
	EvalBoards.ch1.getAxisParameter		= GetAxisParameter;
	EvalBoards.ch1.moveToPosition		= MoveToPosition;
	EvalBoards.ch1.rotateLeft			= RotateLeft;
	EvalBoards.ch1.rotateRight			= RotateRight;
	EvalBoards.ch1.setAxisParameter		= SetAxisParameter;
	EvalBoards.ch1.writeRegister		= writeRegister;
	EvalBoards.ch1.readRegister			= readRegister;
	EvalBoards.ch1.periodicJob			= periodicJob;
	EvalBoards.ch1.userFunction			= userFunction;
	EvalBoards.ch1.getMeasuredSpeed		= getMeasuredSpeed;
	EvalBoards.ch1.enableDriver			= enableDriver;
	EvalBoards.ch1.checkErrors			= checkErrors;
	EvalBoards.ch1.numberOfMotors		= 1;
	EvalBoards.ch1.VMMin				= VM_MIN;
	EvalBoards.ch1.VMMax				= VM_MAX;
	EvalBoards.numberOfMotors			= 1;
	EvalBoards.ch1.deInit				= deInit;
	enableDriver(2);

#if defined(Startrampe)
	Pins.AIN_REF_PWM->configuration.GPIO_Mode = GPIO_Mode_AF;
	GPIO_PinAFConfig(Pins.AIN_REF_PWM->port, Pins.AIN_REF_PWM->bit, GPIO_AF_TIM1);
#elif defined(Landungsbruecke)
	HAL.IOs->config->toOutput(Pins.AIN_REF_PWM);
	Pins.AIN_REF_PWM->configuration.GPIO_Mode = GPIO_Mode_AF4;
#endif

	HAL.IOs->config->set(Pins.AIN_REF_PWM);
	Timer.init();
	Timer.setDuty(0);
};

static void userFunction()
{
	uint32 uvalue;

	switch(TMCL.command->Type)
	{
		case 0:	// simulate reference switches, set high to support external ref swiches
			/*
			 * The the TMC5130 ref switch input is pulled high by external resistor an can be pulled low either by
			 * this �C or external signal. To use external signal make sure the signals from �C are high or floating.
			 */
			if(!(TMCL.command->Value.Int32 & ~3))
			{
				if(TMCL.command->Value.Int32 & (1<<0)) HAL.IOs->config->toInput(Pins.REFR_UC); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.REFR_UC);
					HAL.IOs->config->setLow(Pins.REFR_UC);
				}

				if(TMCL.command->Value.Int32 & (1<<1)) HAL.IOs->config->toInput(Pins.REFL_UC); // pull up -> set it to floating causes high
				else
				{
					HAL.IOs->config->toOutput(Pins.REFL_UC);
					HAL.IOs->config->setLow(Pins.REFL_UC);
				}
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;
		break;

		case 1:	// set analogue current duty
			/*
			 * Current will be defined by analogue value voltage or current signal. In any case this function
			 * will generate a analogue voltage by PWM for up to 50% duty and a switch for the other 50%.
			 * The reference voltage will be AIN_REF = VCC_IO * value/20000 with value = {0..20000}
			 */

			uvalue = (uint32) TMCL.command->Value.Int32;

			if(uvalue <= 20000)
			{
				if(uvalue > 10000)HAL.IOs->config->setHigh(Pins.AIN_REF_SW);
				else HAL.IOs->config->setLow(Pins.AIN_REF_SW);

				Timer.setDuty(uvalue%10001);
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;
		break;

		case 2:	// Use internal clock
			/*
			 * Internel clock will be enabled by calling this function with a value != 0 and unpower and repower the motor supply while keeping usb connected.
			 */
			if(TMCL.command->Value.Int32)
			{
				HAL.IOs->config->toOutput(&HAL.IOs->pins->CLK16);
				HAL.IOs->config->setLow(&HAL.IOs->pins->CLK16);
			}
			else HAL.IOs->config->reset(&HAL.IOs->pins->CLK16);
		break;

		case 3:	// writing a register at address = motor with value = value and reading back the value
			TMCRhino.writeInt(TMCL.command->Motor, TMCL.command->Value.Int32);
			TMCL.reply->Value.Int32 = TMCRhino.readInt(TMCL.command->Motor);
		break;

		case 4: // set or release/read ENCB_[DCEN_CFG4]
			switch(uvalue = TMCL.command->Value.Int32)
			{
				case 0:
					HAL.IOs->config->toOutput(Pins.ENCB_DCEN_CFG4);
					HAL.IOs->config->setLow(Pins.ENCB_DCEN_CFG4);
				break;
				case 1:
					HAL.IOs->config->toOutput(Pins.ENCB_DCEN_CFG4);
					HAL.IOs->config->setHigh(Pins.ENCB_DCEN_CFG4);
				break;
				default:
					HAL.IOs->config->toInput(Pins.ENCB_DCEN_CFG4);
					uvalue = HAL.IOs->config->isHigh(Pins.ENCB_DCEN_CFG4);;
				break;
			}
			TMCL.reply->Value.Int32 = uvalue;
		break;

		case 5:		// read interrupt pin SWN_DIAG0
			TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.SWN_DIAG0))	? 1 : 0;
		break;

		case 6:		// read interrupt pin SWP_DIAG1
			TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.SWP_DIAG1))	? 1 : 0;
		break;

		case 7:		// enable single wire interface (SWSEL)
			if(TMCL.reply->Value.Int32 == 1) HAL.IOs->config->setHigh(Pins.SWSEL);
			else HAL.IOs->config->setLow(Pins.SWSEL);
		break;

		case 253:
			EvalBoards.ch1.debugVar = TMCL.command->Value.Int32;
		break;

		case 254: // use TMC5130 as TMC2130 in TQFP48 package with external S/D signals
		case 255: // use TMC5130 as TMC2130 in TQFP48 package with internal(from this board) S/D signals
			/*
			 *  Assignes TMC2130_TQFP48 to ch1, discards all others
			 */

			if(TMCL.command->Value.Int32 == 1234)
			{
				IdAssignmentTypeDef ids;
				ids.ch1.id 					= ID_TMC2130_TQFP48;
				ids.ch1.state 				= 2;

				ids.ch2.id 					= ID_ERROR;
				ids.ch2.state 				= 2;
				TMCL.reply->Value.Int32 	= BoardAssignment.assign(&ids);

				TMCL.command->Value.Int32	= (TMCL.command->Type == 254) ? 1 : 0;
				TMCL.command->Type			= 0;
				EvalBoards.ch1.userFunction();
				TMCL.reply->Value.Int32 	= 1234;
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void deInit(void)
{

	HAL.IOs->config->setLow(Pins.DRV_ENN_CFG6);

	HAL.IOs->config->reset(Pins.AIN_REF_PWM);
	HAL.IOs->config->reset(Pins.AIN_REF_SW);
	HAL.IOs->config->reset(Pins.ENCA_DCIN_CFG5);
	HAL.IOs->config->reset(Pins.ENCB_DCEN_CFG4);
	HAL.IOs->config->reset(Pins.ENCN_DCO);
	HAL.IOs->config->reset(Pins.REFL_UC);
	HAL.IOs->config->reset(Pins.REFR_UC);
	HAL.IOs->config->reset(Pins.SWN_DIAG0);
	HAL.IOs->config->reset(Pins.SWP_DIAG1);
	HAL.IOs->config->reset(Pins.SWSEL);
	HAL.IOs->config->reset(Pins.DRV_ENN_CFG6);

	Timer.deInit();
};

static uint8 reset()
{
	if((!VitalSignsMonitor.brownOut) && (TMCRhino.readInt(TMCRhino_VACTUAL))) return 0;
	TMCRhino.reset();
	Timer.setDuty(0);
	HAL.IOs->config->setLow(Pins.AIN_REF_SW);
	HAL.IOs->config->toInput(Pins.REFL_UC);
	HAL.IOs->config->toInput(Pins.REFR_UC);
	return 1;

}

static void enableDriver(uint8 enable)
{
	if(enable == 2) enable = EvalBoards.driverEnable;

	if(enable ==  0)											HAL.IOs->config->setHigh(Pins.DRV_ENN_CFG6);
	else if((enable == 1) && (EvalBoards.driverEnable == 1))	HAL.IOs->config->setLow(Pins.DRV_ENN_CFG6);
}
