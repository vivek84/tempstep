#include "rhino.h"
#include "TMC2130_TQFP48.h"
#include "TMC5130.h"
#include "../tmc/boardAssignment.h"
#include "../tmc/stepDir.h"
#include "../hal/Timer.h"


static void RotateRight(void);
static void RotateLeft(void);
static void MotorStop(void);
static void MoveToPosition(void);
static void SetAxisParameter(void);
static void GetAxisParameter(void);
static void writeRegister(void);
static void readRegister(void);
static void rotate(void);
static void init(void);
static void deInit(void);
static void periodicJob(uint32 tick);
static void userFunction(void);

static uint8 reset();
static void enableDriver(uint8 disable0Enable1global2);

typedef struct
{
	IOPinTypeDef *REFL_STEP;
	IOPinTypeDef *REFR_DIR;
	IOPinTypeDef *DRV_ENN_CFG6;
	IOPinTypeDef *ENCA_DCIN_CFG5;
	IOPinTypeDef *ENCB_DCEN_CFG4;
	IOPinTypeDef *ENCN_DCO;

	IOPinTypeDef *SWSEL;
	IOPinTypeDef *SWN_DIAG0;
	IOPinTypeDef *SWP_DIAG1;

	IOPinTypeDef *AIN_REF_SW;
	IOPinTypeDef *AIN_REF_PWM;
} PinsTypeDef;

static PinsTypeDef Pins;
StepDirectionChannelType 		stepDirDummmy;
EvalBoardTypeDef 				TMC2130_TQFP48 	= {init};
static StepDirectionChannelType *StepDirCh[] 	= {&stepDirDummmy};

void rotate()
{
  if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
  {
	if(TMCL.command->Type==0)
	{
		StepDirCh[TMCL.command->Motor]->rampMode 		= SD_RAMP_MODE_VELOCITY;
		StepDirCh[TMCL.command->Motor]->targetVelocity 	= TMCL.command->Value.Int32;
	}
	else TMCL.reply->Status=REPLY_WRONG_TYPE;
  }
  else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void RotateRight(void)
{
	TMCL.command->Value.Int32 = -TMCL.command->Value.Int32;
	rotate();
}

static void RotateLeft(void)
{
	rotate();
}

static void MotorStop(void)
{
	TMCL.command->Value.Int32 = 0;
	rotate();
}

static void MoveToPosition(void)
{
	if(TMCL.command->Motor==0)
	{
		switch(TMCL.command->Type)
		{
			case MVP_ABS:
				StepDirCh[0]->targetPosition	= TMCL.command->Value.Int32;
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
			break;

			case MVP_REL:
				StepDirCh[0]->targetPosition	= StepDirCh[0]->actualPosition+TMCL.command->Value.Int32;
				StepDirCh[0]->rampMode			= SD_RAMP_MODE_POSITIONING;
			break;

			default:
				TMCL.reply->Status			= REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void SetAxisParameter(void)
{
  uint32 value;

  if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
  {
    switch(TMCL.command->Type)
    {
      case 0:
    	  StepDirCh[TMCL.command->Motor]->targetPosition			= TMCL.command->Value.Int32;
       break;

      case 1:
    	  StepDirCh[TMCL.command->Motor]->actualPosition			= TMCL.command->Value.Int32;
      break;

      case 2:
    	  StepDirCh[TMCL.command->Motor]->targetVelocity			= TMCL.command->Value.Int32;
      break;

      case 3:
    	  StepDirCh[TMCL.command->Motor]->actualVelocity			= TMCL.command->Value.Int32;
      break;

      case 4:
    	  StepDirCh[TMCL.command->Motor]->maxPositioningSpeed		= abs(TMCL.command->Value.Int32);
      break;

      case 5:
    	  StepDirCh[TMCL.command->Motor]->actualAcceleration		= TMCL.command->Value.Int32;
      break;

      case 6:
          value=TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
          TMCRhino.writeDatagram(TMCRhino_IHOLD_IRUN, 0, value >> 16,
                              TMCL.command->Value.Byte[0], value & 0xff);
   	  break;

      case 12:
        value=TMCRhino.readInt(TMCRhino_SWMODE);
        if(TMCL.command->Value.Int32==0) TMCRhino.writeInt(TMCRhino_SWMODE, value|TMCRhino_SW_STOPR_ENABLE);
        else TMCRhino.writeInt(TMCRhino_SWMODE, value & ~TMCRhino_SW_STOPR_ENABLE);
      break;

      case 13:
        value=TMCRhino.readInt(TMCRhino_SWMODE);
        if(TMCL.command->Value.Int32==0) TMCRhino.writeInt(TMCRhino_SWMODE, value|TMCRhino_SW_STOPL_ENABLE);
        else
          TMCRhino.writeInt(TMCRhino_SWMODE, value & ~TMCRhino_SW_STOPL_ENABLE);
        break;

      case 14:
        TMCRhino.writeInt(TMCRhino_SWMODE, TMCL.command->Value.Int32);
      break;

      case 22:
    	  TMCRhino.writeInt(TMCRhino_TCOOLTHRS, TMCL.command->Value.Int32);
      break;

      case 23:
    	  TMCRhino.writeInt(TMCRhino_THIGH, TMCL.command->Value.Int32);
      break;

      case 24:
    	  TMCRhino.writeInt(TMCRhino_VDCMIN, TMCL.command->Value.Int32);
      break;

		case 25:
			if(TMCL.command->Value.Int32) HAL.IOs->config->setHigh(Pins.AIN_REF_SW);
			else HAL.IOs->config->setLow(Pins.AIN_REF_SW);
		break;

		case 26:
			if(((uint32) TMCL.command->Value.Int32) > 10000)
			{
				TMCL.reply->Status = REPLY_INVALID_VALUE;
				return;
			}
			Timer.setDuty(TMCL.command->Value.Int32);
		break;

		case 27:
			value = TMCRhino.readInt(TMCRhino_GCONF);
			value &= ~(1<<0);
			value |= (TMCL.command->Value.Int32) ? 1 : 0;
			TMCRhino.writeInt(TMCRhino_GCONF, value);
		break;

		case 28:
			value = TMCRhino.readInt(TMCRhino_GCONF);
			value &= ~(1<<1);
			value |= (TMCL.command->Value.Int32) ? 1 : 0;
			TMCRhino.writeInt(TMCRhino_GCONF, value);
		break;

      default:
        TMCL.reply->Status=REPLY_WRONG_TYPE;
      break;
    }
  }
  else TMCL.reply->Status=REPLY_WRONG_TYPE;
}

static void GetAxisParameter(void)
{
	uint32 value;
	if(TMCL.command->Motor<EvalBoards.ch1.numberOfMotors)
	{
		switch(TMCL.command->Type)
		{
			case 0:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->targetPosition;
			break;

			case 1:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualPosition;
			break;

			case 2:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->targetPosition;
			break;

			case 3:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualVelocity;
			break;

			case 4:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->maxPositioningSpeed;
			break;

			case 5:
				TMCL.reply->Value.Int32		= StepDirCh[TMCL.command->Motor]->actualAcceleration;
			break;

			case 6:
				value = TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
				TMCL.reply->Value.Int32=(value>>8) & 0xff;
			break;

			case 12:
				TMCL.reply->Value.Int32=(TMCRhino.readInt(TMCRhino_SWMODE) & TMCRhino_SW_STOPR_ENABLE) ? 1:0;
			break;

			case 13:
				TMCL.reply->Value.Int32=(TMCRhino.readInt(TMCRhino_SWMODE) & TMCRhino_SW_STOPL_ENABLE) ? 1:0;
			break;

			case 14:
				TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_SWMODE);
			break;

			case 22:
				TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_TCOOLTHRS);
			break;

			case 23:
				TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_THIGH);
			break;

			case 24:
				TMCL.reply->Value.Int32=TMCRhino.readInt(TMCRhino_VDCMIN);
			break;

			case 25:
				TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.AIN_REF_SW)) ? 1 : 0;
			break;

			case 26:
				TMCL.reply->Value.Int32 = (HAL.IOs->config->isHigh(Pins.AIN_REF_PWM)) ? 1 : 0;
			break;

			case 27:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_GCONF) >> 0) & 1;
			break;

			case 28:
				TMCL.reply->Value.Int32 = (TMCRhino.readInt(TMCRhino_GCONF) >> 1) & 1;
			break;

			default:
				TMCL.reply->Status=REPLY_WRONG_TYPE;
			break;
		}
	}
	else TMCL.reply->Status=REPLY_INVALID_VALUE;
}

static void writeRegister(void)
{
	TMCRhino.writeInt(TMCL.command->Type, TMCL.command->Value.Int32);
}

static void readRegister(void)
{
	TMCL.reply->Value.Int32=TMCRhino.readInt(TMCL.command->Type);
}

static void periodicJob(uint32 tick)
{
	TMCRhino.periodicJob(tick);

//	static uint32
//			testTick = 0;
//
//	static uint8 isInit = 0;

//	if((abs(tick-testTick) > 10000) || !isInit)
//	{
//		isInit 		= 1;
//		testTick 	= tick;
//		StepDirCh[0]->targetVelocity = (StepDirCh[0]->targetVelocity > 0) ? -100000 : 100000;
//		StepDirCh[0]->actualAcceleration = 100000;
//		// TODO TESTCASE ONLY
//		uint32 value;
//		HAL.IOs->config->toOutput(Pins.REFL_STEP);
//		HAL.IOs->config->toOutput(Pins.REFR_DIR);
//
//		value=TMCRhino.readInt(TMCRhino_IHOLD_IRUN);
//		TMCRhino.writeDatagram(TMCRhino_IHOLD_IRUN, 0, value >> 16, 31, value & 0xff);
//
//	}
}

static void userFunction()
{
	switch(TMCL.command->Type)
	{
		case 0:
			if(TMCL.command->Value.Int32)
			{ // external S/D
				HAL.IOs->config->toInput(Pins.REFL_STEP);
				HAL.IOs->config->toInput(Pins.REFR_DIR);
			}
			else
			{ // internal S/D,
				HAL.IOs->config->toOutput(Pins.REFL_STEP);
				HAL.IOs->config->toOutput(Pins.REFR_DIR);
			}
		break;

		case 1: // set analogue current duty AIN_REF = AIN_REF_SW + AIN_REF_PWM = 0.5 * I_MAX * value + AIN_REF_PWM, value = {0,1}

			if(TMCL.command->Value.Int32) HAL.IOs->config->setHigh(Pins.AIN_REF_SW);
			else HAL.IOs->config->setLow(Pins.AIN_REF_SW);
		break;

		case 2: // set analogue current duty AIN_REF = AIN_REF_SW + AIN_REF_PWM = AIN_REF_SW + I_MAX * value/10000, value = {0..10000}
			if(((uint32) TMCL.command->Value.Int32) > 10000)
			{
				TMCL.reply->Status = REPLY_INVALID_VALUE;
				return;
			}
			Timer.setDuty(TMCL.command->Value.Int32);
		break;

		case 254: // use TMC5130
		case 255: // use TMC5130
			if(TMCL.command->Value.Int32 == 1234)
			{
				EvalBoards.ch1.deInit();
				EvalBoards.ch2.deInit();
				TMC5130.init();

				IdAssignmentTypeDef ids;
				ids.ch1.id 					= ID_TMC5130;
				ids.ch1.state 				= 2;

				ids.ch2.id 					= ID_ERROR;
				ids.ch2.state 				= 2;
				TMCL.reply->Value.Int32 	= BoardAssignment.assign(&ids);
			}
			else TMCL.reply->Status = REPLY_INVALID_VALUE;
		break;

		default:
			TMCL.reply->Status = REPLY_WRONG_TYPE;
		break;
	}
}

static void init(void)
{
	Pins.DRV_ENN_CFG6 	= &HAL.IOs->pins->DIO0;

	Pins.ENCN_DCO	 	= &HAL.IOs->pins->DIO1;
	Pins.ENCA_DCIN_CFG5 = &HAL.IOs->pins->DIO2;
	Pins.ENCB_DCEN_CFG4	= &HAL.IOs->pins->DIO3;

	Pins.REFL_STEP		= &HAL.IOs->pins->DIO6;
	Pins.REFR_DIR		= &HAL.IOs->pins->DIO7;
	Pins.AIN_REF_SW		= &HAL.IOs->pins->DIO10;
	Pins.AIN_REF_PWM	= &HAL.IOs->pins->DIO11;

	Pins.SWSEL 			= &HAL.IOs->pins->DIO14;
	Pins.SWP_DIAG1		= &HAL.IOs->pins->DIO15;
	Pins.SWN_DIAG0		= &HAL.IOs->pins->DIO16;

	HAL.IOs->config->toInput(Pins.ENCN_DCO);
	HAL.IOs->config->toOutput(Pins.ENCB_DCEN_CFG4);
	HAL.IOs->config->toInput(Pins.ENCA_DCIN_CFG5);

	HAL.IOs->config->toInput(Pins.SWN_DIAG0);
	HAL.IOs->config->toInput(Pins.SWP_DIAG1);
	HAL.IOs->config->toOutput(Pins.SWSEL);

	HAL.IOs->config->toInput(Pins.REFL_STEP);
	HAL.IOs->config->toInput(Pins.REFR_DIR);


	HAL.IOs->config->toOutput(Pins.DRV_ENN_CFG6);
	HAL.IOs->config->toOutput(Pins.AIN_REF_SW);
	HAL.IOs->config->toOutput(Pins.AIN_REF_PWM);

	HAL.IOs->config->setLow(Pins.SWSEL);
	HAL.IOs->config->setLow(Pins.ENCB_DCEN_CFG4);

	StepDir.init();
	StepDirCh[0] 						= StepDir.ch2;
	StepDirCh[0]->stepOut 				= Pins.REFL_STEP;
	StepDirCh[0]->dirOut 				= Pins.REFR_DIR;

	TMCRhino.SPIChannel					= &HAL.SPI->ch1;
	TMCRhino.SPIChannel->CSN			= &HAL.IOs->pins->SPI1_CSN;
	TMCRhino.config 					= EvalBoards.ch1.config;

	EvalBoards.ch1.config->reset		= reset;
	EvalBoards.ch1.config->restore		= TMCRhino.restore;
	EvalBoards.ch1.config->isBusy 		= 0;
	EvalBoards.ch1.config->ptr	 		= 0;

	EvalBoards.ch1.motorStop			= MotorStop;
	EvalBoards.ch1.getAxisParameter		= GetAxisParameter;
	EvalBoards.ch1.moveToPosition		= MoveToPosition;
	EvalBoards.ch1.rotateLeft			= RotateLeft;
	EvalBoards.ch1.rotateRight			= RotateRight;
	EvalBoards.ch1.setAxisParameter		= SetAxisParameter;
	EvalBoards.ch1.writeRegister		= writeRegister;
	EvalBoards.ch1.readRegister			= readRegister;
	EvalBoards.ch1.periodicJob			= periodicJob;
	EvalBoards.ch1.userFunction			= userFunction;
	EvalBoards.ch1.enableDriver			= enableDriver;
	EvalBoards.ch1.numberOfMotors		= 1;
	EvalBoards.numberOfMotors			= 1;
	EvalBoards.ch1.deInit				= deInit;
	enableDriver(2);

#if defined(Startrampe)
	Pins.AIN_REF_PWM->configuration.GPIO_Mode = GPIO_Mode_AF;
	GPIO_PinAFConfig(Pins.AIN_REF_PWM->port, Pins.AIN_REF_PWM->bit, GPIO_AF_TIM1);
#elif defined(Landungsbruecke)
	HAL.IOs->config->toOutput(Pins.AIN_REF_PWM);
	Pins.AIN_REF_PWM->configuration.GPIO_Mode = GPIO_Mode_AF4;
#endif

	HAL.IOs->config->set(Pins.AIN_REF_PWM);
	Timer.init();
	Timer.setDuty(0);
};

static void deInit(void)
{
	HAL.IOs->config->setLow(Pins.DRV_ENN_CFG6);

	HAL.IOs->config->reset(Pins.AIN_REF_PWM);
	HAL.IOs->config->reset(Pins.AIN_REF_SW);
	HAL.IOs->config->reset(Pins.ENCA_DCIN_CFG5);
	HAL.IOs->config->reset(Pins.ENCB_DCEN_CFG4);
	HAL.IOs->config->reset(Pins.ENCN_DCO);
	HAL.IOs->config->reset(Pins.REFL_STEP);
	HAL.IOs->config->reset(Pins.REFR_DIR);
	HAL.IOs->config->reset(Pins.SWN_DIAG0);
	HAL.IOs->config->reset(Pins.SWP_DIAG1);
	HAL.IOs->config->reset(Pins.SWSEL);
	HAL.IOs->config->reset(Pins.DRV_ENN_CFG6);

	StepDir.deInit();
	Timer.deInit();
};

static uint8 reset()
{
	if((!VitalSignsMonitor.brownOut) && (TMCRhino.readInt(TMCRhino_VACTUAL))) return 0;
	TMCRhino.reset();
	return 1;
}

static void enableDriver(uint8 enable)
{
	if(enable == 2) enable = EvalBoards.driverEnable;

	if(enable ==  0)											HAL.IOs->config->setHigh(Pins.DRV_ENN_CFG6);
	else if((enable == 1) && (EvalBoards.driverEnable == 1))	HAL.IOs->config->setLow(Pins.DRV_ENN_CFG6);
}
