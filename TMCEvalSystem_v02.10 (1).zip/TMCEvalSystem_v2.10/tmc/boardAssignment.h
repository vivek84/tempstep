#ifndef BOARDASSIGNMENT_H_
	#include "../hal/typedefs.h"
	#define BOARDASSIGNMENT_H_

	typedef struct
	{
		uint8 state;
		uint8 id;
	} IdStateTypeDef;

	typedef struct
	{
		IdStateTypeDef ch1;
		IdStateTypeDef ch2;
	} IdAssignmentTypeDef;

	typedef struct
	{
		int32 	(*assign)(IdAssignmentTypeDef *ids);
		int32 	(*supported)(IdAssignmentTypeDef *ids);
		void 	(*periodicJob)();
		void 	(*deInit)();
	} BoardAssignmentTypeDef;

	BoardAssignmentTypeDef BoardAssignment;

//	=======================================
//	CHANNEL 0
//	vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

		#define ID_ERROR				0

		#define ID_TMC5130				5

		#define ID_TMC4361				4
		#define ID_TMC4331				10

		#define ID_TMC5041				6
		#define ID_TMC5072				7
		#define ID_TMC5031				2
		#define ID_TMC5062				25

		//#define ID_TMCC160			9

		#define ID_TMC2130_TQFP48		0xFE

		#define ID_SELFTEST	255

//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

//	=======================================
//	CHANNEL 1
//	vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

		#define ID_TMC2660	1
		#define ID_TMC2130	3
		#define ID_TMC2100	4
		#define ID_TMCC160	9

//	^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


#endif /* BOARDASSIGNMENT_H_ */
