/*
 * idDetection.c
 *
 *  Created on: 	24.10.2013
 *  Author: 		ernst
 *
 *  Determine the ids of connected boards by calling getId(&result) where result is a struct
 *  of IdDetectionTypeDef. result will contain the current state of the id determination(stateCh[0,1]) and
 *  the assigned ids idCh[0,1]for each board.
 *
 *  The states of id determination are:
 *	#define ID_STATE_IDLE		0			// id detection state definitions
 *	#define ID_STATE_PENDING	1			// id detection pending running
 *	#define ID_STATE_DONE		2			// id detection finished
 *	#define ID_STATE_ERROR		3			// id detection failed
 *	#define ID_STATE_NO_ANSWER	4			// id detection failed because board doesn't answer
 *	#define ID_STATE_TIMEOUT	5			// id detection failed because of timeout, board id signal went
 *											   high not low again
 *
 *  Once getId was called the determination is started. While its not finished getId will
 *  return the constant ID_STATE_PENDING. While the detection happens parallel for both channels the detection
 *  of one channel may finish earlier. The result struct will always contain the actual data so if the determination
 *  state of one channel is done the id is valid.
 *
 *  If the id detection is finished for both channels getId will return ID_STATE_DONE and the results are
 *  put into the result struct. The next call of getId will start the next id determination.
 *
 */

#include "../hal/derivative.h"
#include "../hal/bits.h"
#include "../hal/HAL.h"
#include "idDetection.h"
#include "boardAssignment.h"

static void init(void);
static uint8 assign(uint32 pulse);
static uint8 detect(IdAssignmentTypeDef *out);
static void deInit();

volatile uint8 idState;
volatile IdAssignmentTypeDef	IdDetectionState =
{
		.ch1  =
		{
			.id 	= 0,
			.state	= ID_STATE_PENDING
		},
		.ch2 =
		{
			.id 	= 0,
			.state	= ID_STATE_PENDING
		}
};


IdDetectionTypeDef IdDetection =
{
	.init 	= init,
	.detect = detect,
	.deInit = deInit
};

void __attribute__ ((interrupt)) EXTI0_IRQHandler(void)
/*
 * pin changed interrupt to detect edges of id pulse for this channel
*/
{
	if(EXTI_GetITStatus(EXTI_Line0) != RESET)
	{
		if(idState == ID_STATE_PENDING) 						// try 2 get id?
		{
			if(ID_CH0_STATE)									// id pulse heigh?
			{
				TIM5->EGR 					|= TIM_EGR_CC1G;		// capture time between id clk high and id pulse high
				IdDetectionState.ch1.state	= ID_STATE_PENDING;		// set id detection state for this channel to pending
				ID_CLK_LOW();
			}
			else
			{
				TIM5->EGR 				|= TIM_EGR_CC2G;		// capture time on puls high 2 low edge
				IdDetectionState.ch1.state	= ID_STATE_DONE;		// set id detection state for this channel to done
			}
		}
		EXTI_ClearITPendingBit(EXTI_Line0);
	}
}

void __attribute__ ((interrupt)) EXTI1_IRQHandler(void)
/*
 * pin changed interrupt to detect edges of id pulse for this channel
*/
{
	if(EXTI_GetITStatus(EXTI_Line1) != RESET)
	{
		if(idState == ID_STATE_PENDING) 						// try 2 get id?
		{
			if(ID_CH1_STATE)									// id pulse heigh?
			{
				TIM5->EGR 					|= TIM_EGR_CC3G;		// capture time between id clk high and id pulse high
				IdDetectionState.ch2.state	= ID_STATE_PENDING;		// set id detection state for this channel to pending
				ID_CLK_LOW();
			}
			else
			{
				TIM5->EGR 					|= TIM_EGR_CC4G;		// capture time on puls high 2 low edge
				IdDetectionState.ch2.state	= ID_STATE_DONE;		// set id detection state for this channel to done
			}
		}
		EXTI_ClearITPendingBit(EXTI_Line1);
	}
}

void TIM5_IRQHandler(void)
/*
 * timer interrupt to determine timout on id detection(missing boards, errors)
*/
{

	if(TIM_GetITStatus(TIM5, TIM_IT_Update)!=RESET)
  {
	  if(idState == ID_STATE_PENDING)
	  {
		  if(IdDetectionState.ch1.state == ID_STATE_PENDING)		// id detection for this channel still pending?
		  {
			  IdDetectionState.ch1.state = ID_STATE_TIMEOUT;		// set id detection state to timeout
		  }
		  else if(IdDetectionState.ch1.state == ID_STATE_IDLE)	// id detection for this channel still idle?
		  {
			  IdDetectionState.ch1.state = ID_STATE_NO_ANSWER;	// set id detection state to no answer
		  }

		  if(IdDetectionState.ch2.state == ID_STATE_PENDING)		// id detection for this channel still pending?
		  {
			  IdDetectionState.ch2.state = ID_STATE_TIMEOUT;		// set id detection state to timeout
		  }
		  else if(IdDetectionState.ch2.state == ID_STATE_IDLE)	// id detection for this channel still idle?
		  {
			  IdDetectionState.ch2.state = ID_STATE_NO_ANSWER;	// set id detection state to no answer
		  }
	  }
	  TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
  }
}

static void init(void)
{
/*
 * initialize timer an port change interrupts
*/
	idState		= ID_STATE_DONE;

	HAL.IOs->config->toOutput(&HAL.IOs->pins->ID_CLK);
	HAL.IOs->config->toInput(&HAL.IOs->pins->ID_CH0);
	HAL.IOs->config->toInput(&HAL.IOs->pins->ID_CH1);

	//====================================================
	// enable external interrupt on line 0 (idChannel0)
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

		SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOC, EXTI_PinSource0);

		EXTI_InitTypeDef EXTI_InitStructure;
		EXTI_StructInit(&EXTI_InitStructure);
		EXTI_InitStructure.EXTI_Line							= EXTI_Line0;
		EXTI_InitStructure.EXTI_Mode							= EXTI_Mode_Interrupt;
		EXTI_InitStructure.EXTI_Trigger							= EXTI_Trigger_Rising_Falling;
		EXTI_InitStructure.EXTI_LineCmd							= ENABLE;
		EXTI_Init(&EXTI_InitStructure);

		NVIC_InitTypeDef NVIC_InitStructure;
		NVIC_InitStructure.NVIC_IRQChannel					 	= EXTI0_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority 	= 1;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority 			= 1;
		NVIC_InitStructure.NVIC_IRQChannelCmd 					= ENABLE;
		NVIC_Init(&NVIC_InitStructure);

		EXTI_ClearITPendingBit(EXTI_Line0);


		SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOC, EXTI_PinSource1);

		EXTI_StructInit(&EXTI_InitStructure);
		EXTI_InitStructure.EXTI_Line							= EXTI_Line1;
		EXTI_InitStructure.EXTI_Mode							= EXTI_Mode_Interrupt;
		EXTI_InitStructure.EXTI_Trigger							= EXTI_Trigger_Rising_Falling;
		EXTI_InitStructure.EXTI_LineCmd							= ENABLE;
		EXTI_Init(&EXTI_InitStructure);

		NVIC_InitStructure.NVIC_IRQChannel					 	= EXTI1_IRQn;
		NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority 	= 1;
		NVIC_InitStructure.NVIC_IRQChannelSubPriority 			= 1;
		NVIC_InitStructure.NVIC_IRQChannelCmd 					= ENABLE;
		NVIC_Init(&NVIC_InitStructure);

		EXTI_ClearITPendingBit(EXTI_Line1);

	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//====================================================
	// TIM5 config
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

		  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);

		  TIM_DeInit(TIM5);

		  TIM5->CNT		= 		0;

		  TIM5->CR1 	|= (uint16)
			(
					  TIM_CR1_ARPE		// bufferred auto reload register
					//| TIM_CR1_OPM		// stop on update
			);

		  TIM5->DIER 	|= (uint16)
			(
					  TIM_DIER_UIE		// update interrupt
//					| TIM_DIER_CC1IE
			);


		  TIM5->CCMR1	|=		(uint16)
			(
					  TIM_CCMR1_CC1S	// channel as input
					| TIM_CCMR1_CC2S	// channel as input
			);

		  TIM5->CCMR2	|=		(uint16)
			(
					  TIM_CCMR2_CC3S	// channel as input
					| TIM_CCMR2_CC4S	// channel as input
			);

		  // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
		  // KEEP ORDER OF SETTING CCMR[1,2] and CCER
		  // vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

		  TIM5->CCER	|=	(uint16)
			(
					  TIM_CCER_CC1E	// capture enable
					| TIM_CCER_CC2E	// capture enable
					| TIM_CCER_CC3E	// capture enable
					| TIM_CCER_CC4E	// capture enable
			);

		  TIM5->PSC		= 5;								// prescaler 	-> 0.1us
		  TIM5->ARR		= 13500000;							// timeout 		-> 1.35s

		  TIM5->EGR 	|= (uint16)
			(
				  TIM_EGR_UG		// update event to initialize
			);

		  //Timer-Interrupt im NVIC freischalten
		  NVIC_InitStructure.NVIC_IRQChannel					= TIM5_IRQn;
		  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 0xF;
		  NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0xF;
		  NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
		  NVIC_Init(&NVIC_InitStructure);
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

}

static void deInit()
{
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel						= TIM5_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd					= DISABLE;
	NVIC_Init(&NVIC_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel					 	= EXTI0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd 					= DISABLE;
	NVIC_Init(&NVIC_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel					 	= EXTI1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd 					= DISABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM_DeInit(TIM5);
	EXTI_DeInit();
}

static uint8 assign(uint32 pulse)
/*
 * returns id assigned to given pulse length in 0.1us
 *
 *	arguments:
 *		pulse:
 *			pulse length in 0.1us
 *		returns:
 *			assigned id or 0 on error
 */
{
	if(pulse < 5			) return 	0	;	// error
	else if(pulse < 110		) return 	1	;
	else if(pulse < 135		) return 	2	;
	else if(pulse < 165		) return 	3	;
	else if(pulse < 200		) return 	4	;
	else if(pulse < 245		) return 	5	;
	else if(pulse <	300		) return	6	;
	else if(pulse <	360		) return	7	;
	else if(pulse <	430		) return	8	;
	else if(pulse <	515		) return	9	;
	else if(pulse <	620		) return	10	;
	else if(pulse <	750		) return	11	;
	else if(pulse <	910		) return	12	;
	else if(pulse <	1100	) return	13	;
	else if(pulse <	1350	) return	14	;
	else if(pulse <	1650	) return	15	;
	else if(pulse <	2000	) return	16	;
	else if(pulse <	2450	) return	17	;
	else if(pulse <	3000	) return	18	;
	else if(pulse <	3600	) return	19	;
	else if(pulse <	4300	) return	20	;
	else if(pulse <	5150	) return	21	;
	else if(pulse <	6200	) return	22	;
	else if(pulse <	7500	) return	23	;
	else if(pulse <	9100	) return	24	;
	else if(pulse <	11000	) return	25	;
	else if(pulse <	13500	) return	26	;
	else if(pulse <	16500	) return	27	;
	else if(pulse <	20000	) return	28	;
	else if(pulse <	24500	) return	29	;
	else if(pulse <	30000	) return	30	;
	else if(pulse <	36000	) return	31	;
	else if(pulse <	43000	) return	32	;
	else if(pulse <	51500	) return	33	;
	else if(pulse <	62000	) return	34	;
	else if(pulse <	75000	) return	35	;
	else if(pulse <	91000	) return	36	;


	return 0;									// error
}

static uint8 detect(IdAssignmentTypeDef *out)
/*
 * start of id determination or request of its result
 *
 *	arguments:
 *		out:
 *			reference to IdDetectionTypeDef to gain results
 *	returns:
 *		state of id determination: pending
 */
{
//	uint8 x;
//	uint32 y;
	if(idState == ID_STATE_DONE)
	{
		TIM_Cmd(TIM5, DISABLE);									// stop timer
		TIM5->CNT 					= 0;							// clear counter
		idState 					= ID_STATE_PENDING;				// set id detection state to pending
		IdDetectionState.ch1.state 	= ID_STATE_IDLE;				// set id detection state for this channel to idle
		IdDetectionState.ch2.state	= ID_STATE_IDLE;				// set id detection state for this channel to idle
		TIM_Cmd(TIM5, ENABLE);									// start timer
		ID_CLK_HIGH();											// set id clk to high
	}
	else
	{
		if
		( 		   (IdDetectionState.ch1.state != ID_STATE_IDLE)
				&& (IdDetectionState.ch2.state != ID_STATE_IDLE)
				&& (IdDetectionState.ch1.state != ID_STATE_PENDING)
				&& (IdDetectionState.ch2.state != ID_STATE_PENDING)
		)
		{

			idState = ID_STATE_DONE;								// set id detection state to done
			ID_CLK_LOW();											// set id clock 2 low
		}

		out->ch1.state 	= IdDetectionState.ch1.state;				// assign id detection state for this channel

		if(IdDetectionState.ch1.state == ID_STATE_DONE)				// if id detection for this channel is finished successfull
		{
			out->ch1.id = assign(TIM5->CCR2-TIM5->CCR1);			// assign id
			if(!out->ch1.id)	out->ch1.state = ID_STATE_ERROR;	// if assignment failed set id detection state for this channel 2 error
		}
		else out->ch1.id = 0;

		out->ch2.state 	= IdDetectionState.ch2.state;				// assign id detection state for this channel

		if(IdDetectionState.ch2.state == ID_STATE_DONE)				// if id detection for this channel is finished successfull
		{
			out->ch2.id = assign(TIM5->CCR4-TIM5->CCR3);			// assign id
			if(!out->ch2.id)	out->ch2.state = ID_STATE_ERROR;	// if assignment failed set id detection state for this channel 2 error
			//out->idCh1 |= (1<<7);									// offset for channel 2
		}
		else out->ch2.id = 0;
	}
	return idState;
}
