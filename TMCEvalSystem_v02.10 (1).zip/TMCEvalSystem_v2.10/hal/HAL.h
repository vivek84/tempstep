#ifndef _HAL_H_
	#define _HAL_H_
	#include "IOs.h"
	#include "IOMap.h"
	#include "SPI.h"
	#include "ADCs.h"
	#include "USB.h"
	#include "LEDs.h"
	#include "wireless.h"
	#include "RS232.h"
	#include "Timer.h"
	#include "systemTick.h"
	#include "derivative.h"


	#ifndef UNUSED
		#define UNUSED(x) (void)(x)
	#endif

	typedef struct
	{
		IOsTypeDef		*config;
		IOPinMapTypeDef *pins;
		const uint8 	LOW;
		const uint8 	HIGH;
		const uint8 	OPEN;
	}IOsFunctionsTypeDef;

	typedef struct
	{
		void(*init)(void);
		void(*reset)(uint8 ResetPeripherals);
		void(*NVIC_DeInit)(void);
		const IOsFunctionsTypeDef	*IOs;
		SPITypeDef 					*SPI;
		RXTXTypeDef 				*USB;
		LEDsTypeDef	 				*LEDs;
		ADCTypeDef 					*ADCs;
		RXTXTypeDef 				*RS232;
		RXTXTypeDef 				*Wireless;
		SystemTickTypeDef 			*SystemTick;
		TimerTypeDef 				*Timer;
	} HALTypeDef;

	const HALTypeDef HAL;
#endif
