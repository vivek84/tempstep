/*
 * TMC22xx_Register.h
 *
 *  Created on: 10.11.2016
 *      Author: bd
 */

#ifndef TMC22xx_REGISTER_H
#define TMC22xx_REGISTER_H

	// ===== TMC2208 & 2202 & TMC2224 & 2220 & 2225 "Donkey Kong" family register set =====

	#define TMC22xx_GCONF      		0x00
	#define TMC22xx_GSTAT      		0x01
	#define TMC22xx_IFCNT      		0x02
	#define TMC22xx_SLAVECONF  		0x03
	#define TMC22xx_OTP_PROG   		0x04
	#define TMC22xx_OTP_READ   		0x05
	#define TMC22xx_IOIN       		0x06
	#define TMC22xx_FACTORY_CONF  	0x07

	#define TMC22xx_IHOLD_IRUN 		0x10
	#define TMC22xx_TPOWERDOWN  	0x11
	#define TMC22xx_TSTEP  			0x12
	#define TMC22xx_TPWMTHRS  		0x13

	#define TMC22xx_VACTUAL   		0x22

	#define TMC22xx_MSCNT      		0x6A
	#define TMC22xx_MSCURACT   		0x6B
	#define TMC22xx_CHOPCONF   		0x6C
	#define TMC22xx_DRVSTATUS  		0x6F
	#define TMC22xx_PWMCONF  		0x70
	#define TMC22xx_PWMSCALE  		0x71
	#define TMC22xx_PWM_AUTO		0x72

#endif /* TMC22xx_Register */
