#ifndef _BOARD_H_
	#define _BOARD_H_

	#include "../hal/derivative.h"
	#include "../hal/HAL.h"
	#include "../tmc/TMCL.h"
	#include "../tmc/VitalSignsMonitor.h"

	typedef struct								// general functions for boards
	{
		void (*init)( void);
	} EvalBoardTypeDef;

	typedef struct								// structure for configuration mechanism
	{
		uint8 						isBusy;
		uint8						ptr;
		int32 						shadowRegister[128];
		uint8 (*reset)				(void);
		void (*resetCallBack)		(void);
		uint8 (*restore)			(void);
		void (*restoreCallBack)		(void);
	} ConfigurationTypeDef;

	typedef struct								// struct of references functions of detected board on one channel
	{
		uint8	 id;
		uint32 errors;
		uint32 VMMax;
		uint32 VMMin;
		int8 						debugVar;
		unsigned char 				numberOfMotors;
		ConfigurationTypeDef 		*config;
		void (*rotateLeft)			(void);
		void (*rotateRight)			(void);
		void (*motorStop)			(void);
		void (*moveToPosition)		(void);
		void (*setAxisParameter)	(void);
		void (*getAxisParameter)	(void);
		void (*storeAxisParameter)	(void);
		void (*restoreAxisParameter)(void);
		void (*readRegister) 		(void);
		void (*writeRegister) 		(void);
		void (*periodicJob) 		(uint32 tick);
		void (*init) 				(void);
		void (*deInit) 				(void);
		void (*userFunction)		(void);
		void (*getMeasuredSpeed)	(void);
		void (*checkErrors)			(uint32 tick);
		void (*enableDriver)		(uint8 disable0Enable1global2);

	} EvalBoardFunctionsTypeDef;

	typedef struct								// struct of two evalboards
	{
		EvalBoardFunctionsTypeDef ch1;
		EvalBoardFunctionsTypeDef ch2;
		uint8 numberOfMotors;
		uint8 driverEnable;
	} EvalboardsTypeDef;

	volatile EvalboardsTypeDef EvalBoards;

	#include "TMCDummy.h"
	#include "TMCMotionController.h"
	#include "TMCDriver.h"
#endif
