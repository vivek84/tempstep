#include "rhino.h"
#include "../tmc/boardAssignment.h"

#define R10 0x00<<24 	| 0x07<<16	| 0x17<<8	| 0x03			// not reset but preconfiguration
#define R3A 65536
#define R60 0b10101010101010101011010101010100
#define R61 0b01001010100101010101010010101010
#define R62 0b00100100010010010010100100101001
#define R63 0b00010000000100000100001000100010
#define R64 0b11111011111111111111111111111111
#define R65 0b10110101101110110111011101111101
#define R66 0b01001001001010010101010101010110
#define R67 0b00000000010000000100001000100010
#define R68 255<<24 	| 255<<16 	| 0x80<<8 	| 0b01010110
#define R69 247<<16
#define R6C 0x00<<24 	| 0x01<<16	| 0x01<<8	| 0xd5			// not reset but preconfiguration

static void writeDatagram(uint8 Address, uint8 x1, uint8 x2, uint8 x3, uint8 x4);
static void writeInt(uint8 Address, int Value);
static int readInt(uint8 Address);
static void periodicJob(unsigned int tick);
static uint8 reset();
static uint8 restore();
static void writeConfiguration();

TMCRhinoTypeDef TMCRhino =
{
	.SPIChannel 			= &SPI.ch1,
	.velocity				= 0,
	.periodicJob			= periodicJob,
	.writeDatagram			= writeDatagram,
	.writeInt				= writeInt,
	.readInt				= readInt,
	.reset					= reset,
	.restore				= restore,
	.registerAccess			=
	{
	// access
	// none :	0
	// r 	:	1
	// w 	: 	2
	// rw 	: 	3
	// r/w 	: 	7 (read and write separate values)

	//	0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F
		3, 1, 1, 2, 7, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//00..0f
		2, 2, 1, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//10..1f

		3, 3, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 0, 0,    	//20..2f
		0, 0, 0, 2, 3, 1, 1, 0, 3, 3, 2, 1, 1, 0, 0, 0,    	//30..3f
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//40..2f
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,    	//50..3f

		2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 3, 2, 2, 1,    	//60..6f
		2, 1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0		//70..7f
	},

	.registerResetState		=
	{
	//	0,   1,   2,   3,   4,   5,   6,   7,   8,   9,   A,   B,   C,   D,   E,   F
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //00..0f
		R10, 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //10..1f
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //20..2f
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   R3A, 0,   0,   0,   0,   0,   //30..3f
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //40..4f
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //50..5f
		R60, R61, R62, R63, R64, R65, R66, R67, R68, R69, 0,   0,   R6C, 0,   0,   0,   //60..6f
		0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   //70..7f
	},
};



static void writeDatagram(uint8 address, uint8 x1, uint8 x2, uint8 x3, uint8 x4)
{
  int value;

  TMCRhino.SPIChannel->readWrite(address|0x80, FALSE);
  TMCRhino.SPIChannel->readWrite(x1, FALSE);
  TMCRhino.SPIChannel->readWrite(x2, FALSE);
  TMCRhino.SPIChannel->readWrite(x3, FALSE);
  TMCRhino.SPIChannel->readWrite(x4, TRUE);

  value	=	x1;
  value	<<=	8;
  value	|=	x2;
  value	<<=	8;
  value	|=	x3;
  value	<<=	8;
  value	|=	x4;

  TMCRhino.config->shadowRegister[address & 0x7f] = value;
}

static void writeInt(uint8 Address, int Value)
{
	writeDatagram(Address, 0xFF & (Value>>24), 0xFF & (Value>>16), 0xFF & (Value>>8), 0xFF & (Value>>0));
}

static int readInt(uint8 address)
{
	int Value;

	address &= 0x7f;
	if(!(TMCRhino.registerAccess[address] & 1) && !(TMCRhino.registerAccess[address] & 4))  return TMCRhino.config->shadowRegister[address];	// register not readable -> softwarecopy

	TMCRhino.SPIChannel->readWrite(address, FALSE);
	TMCRhino.SPIChannel->readWrite(0, FALSE);
	TMCRhino.SPIChannel->readWrite(0, FALSE);
	TMCRhino.SPIChannel->readWrite(0, FALSE);
	TMCRhino.SPIChannel->readWrite(0, TRUE);

	TMCRhino.SPIChannel->readWrite(address, FALSE);
	Value	=	TMCRhino.SPIChannel->readWrite(0, FALSE);
	Value	<<=	8;
	Value	|=	TMCRhino.SPIChannel->readWrite(0, FALSE);
	Value	<<=	8;
	Value	|=	TMCRhino.SPIChannel->readWrite(0, FALSE);
	Value	<<=	8;
	Value	|=	TMCRhino.SPIChannel->readWrite(0, TRUE);

	if((address==0x22)	&& (Value & BIT23)) Value|=0xff000000;

	return Value;
}

static void periodicJob(unsigned int tick)
{
	// mesure speed
	// store xactual

	if(EvalBoards.ch1.id == ID_TMC5130)
	{
		int
			XActual,t;

		static int
			oldTick	= 0,
			oldX[]	= {0};

		if((t = abs(tick-oldTick)) >= 5)	// measured speed dx/dt
		{
			VitalSignsMonitor.checkVitalSigns(tick);
			XActual				= readInt(TMCRhino_XACTUAL);
			if(!VitalSignsMonitor.brownOut) TMCRhino.config->shadowRegister[TMCRhino_XACTUAL] = XActual;
			TMCRhino.velocity 	= (int) ((float) ((XActual-oldX[0]) / (float) t) 	* (float) 1048.576);

	//		if(readInt(TMCRhino_VACTUAL)<0) TMCRhino.velocity *= -1;
			oldX[0]				= XActual;
			oldTick				= tick;
		}

	}

	if(TMCRhino.config->isBusy)			// serializied writing of (pre) configuration
	{
		writeConfiguration();
		return;
	}




}

static uint8 reset()
{
	/* // ONLY NEEDED FOR SIMULATED STANDALONE MODE
		if(TMCRhino.isStandAlone)
		{
			standAlone_reset();
			return 1;
		}
	*/

	if(TMCRhino.config->isBusy) return 0;
	TMCRhino.config->isBusy 			= 1;
	TMCRhino.config->ptr	 			= 0;
	return 1;
}

static uint8 restore()
{
	if(TMCRhino.config->isBusy) return 0;
	TMCRhino.config->isBusy 			= 2;
	TMCRhino.config->ptr	 			= 0;
	return 1;
}

static void writeConfiguration()
{
	uint8 *ptr			= &TMCRhino.config->ptr;
	const int32 *settings	= (TMCRhino.config->isBusy == 2) ? TMCRhino.config->shadowRegister : TMCRhino.registerResetState;

	while(!(TMCRhino.registerAccess[*ptr]&2) && (*ptr<128)) (*ptr)++;
	if(*ptr<128)
	{
		TMCRhino.writeInt(*ptr, settings[*ptr]);
		(*ptr)++;
	}
	else
	{
		if(TMCRhino.config->isBusy == 1) TMCRhino.config->resetCallBack();
		else TMCRhino.config->restoreCallBack();
		TMCRhino.config->isBusy = 0;
	}
}

