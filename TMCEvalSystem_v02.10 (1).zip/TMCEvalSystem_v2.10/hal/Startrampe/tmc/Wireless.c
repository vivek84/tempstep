#include "../../HAL.h"
#include "../../../tmc/VitalSignsMonitor.h"
#include "../../RXTX.h"
#include "../../wireless.h"


#define BUFFER_SIZE 		1024
#define INTR_PRI	 		6


static void init();
static void deInit();

static void tx(char ch);
static unsigned char rx(char *ch);
static void txN(char *str, unsigned char number);
static unsigned char rxN(char *ch, unsigned char number);
static void clearBuffers(void);
static unsigned char bytesAvailable();

static char
	rxBuffer[BUFFER_SIZE],
	txBuffer[BUFFER_SIZE],
	send = 0;


unsigned int
	lastTick 	= 0;

static volatile unsigned int
	available 	= 0;


RXTXTypeDef Wireless =
{
	.init 			= init,
	.deInit 		= deInit,
	.rx				= rx,
	.tx				= tx,
	.rxN			= rxN,
	.txN			= txN,
	.clearBuffers	= clearBuffers,
	.baudRate		= 115200,
	.bytesAvailable	= bytesAvailable
};

static RXTXBufferingTypeDef buffers =
{
	.rx =
	{
			.read	= 0,
			.wrote	= 0,
			.buffer = rxBuffer
	},

	.tx =
	{
		.read	= 0,
		.wrote	= 0,
		.buffer = txBuffer
	}
};

void __attribute__ ((interrupt)) USART3_IRQHandler(void);

static void init()
{
  USART_InitTypeDef UART_InitStructure;
  NVIC_InitTypeDef	NVIC_InitStructure;

  USART_DeInit(USART3);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

  HAL.IOs->config->reset(&HAL.IOs->pins->WIRELESS_RX);
  HAL.IOs->config->reset(&HAL.IOs->pins->WIRELESS_TX);
  HAL.IOs->config->reset(&HAL.IOs->pins->WIRELESS_NRST);

  GPIO_PinAFConfig(HAL.IOs->pins->WIRELESS_RX.port, HAL.IOs->pins->WIRELESS_RX.bit, GPIO_AF_USART3);
  GPIO_PinAFConfig(HAL.IOs->pins->WIRELESS_TX.port, HAL.IOs->pins->WIRELESS_TX.bit, GPIO_AF_USART3);

  USART_StructInit(&UART_InitStructure);
  UART_InitStructure.USART_BaudRate						= Wireless.baudRate;
  USART_Init(USART3,&UART_InitStructure);

  NVIC_InitStructure.NVIC_IRQChannel					= USART3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= INTR_PRI;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
  NVIC_Init(&NVIC_InitStructure);


  USART_ClearFlag(USART3, USART_FLAG_CTS | USART_FLAG_LBD  | USART_FLAG_TXE  |
                          USART_FLAG_TC  | USART_FLAG_RXNE | USART_FLAG_IDLE |
                          USART_FLAG_ORE | USART_FLAG_NE   | USART_FLAG_FE |
                          USART_FLAG_PE);
  USART_ITConfig(USART3,USART_IT_PE  ,DISABLE);
  USART_ITConfig(USART3,USART_IT_TXE ,ENABLE);
  USART_ITConfig(USART3,USART_IT_TC  ,ENABLE);
  USART_ITConfig(USART3,USART_IT_RXNE,ENABLE);
  USART_ITConfig(USART3,USART_IT_IDLE,DISABLE);
  USART_ITConfig(USART3,USART_IT_LBD ,DISABLE);
  USART_ITConfig(USART3,USART_IT_CTS ,DISABLE);
  USART_ITConfig(USART3,USART_IT_ERR ,DISABLE);

  USART_Cmd(USART3, ENABLE);
}

static void deInit()
{
	NVIC_InitTypeDef	NVIC_InitStructure;
	USART_Cmd(USART3, DISABLE);
	 NVIC_InitStructure.NVIC_IRQChannel			= USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd		= DISABLE;
	NVIC_Init(&NVIC_InitStructure);

	USART_ClearFlag
	(
		USART3,
		0
		| USART_FLAG_CTS
		| USART_FLAG_LBD
		| USART_FLAG_TXE
		| USART_FLAG_TC
		| USART_FLAG_RXNE
		| USART_FLAG_IDLE
		| USART_FLAG_ORE
		| USART_FLAG_NE
		| USART_FLAG_FE
		| USART_FLAG_PE
	);
	clearBuffers();
}

void USART3_IRQHandler(void)
{

	if(USART3->SR & USART_FLAG_RXNE)
	{
		buffers.rx.buffer[buffers.rx.wrote] = USART3->DR;
		if(++buffers.rx.wrote >= BUFFER_SIZE) buffers.rx.wrote = 0;
		available++;
	}

	if(USART3->SR & USART_FLAG_TXE)
	{
		if(buffers.tx.read != buffers.tx.wrote)
		{
			if(SystemTick.tick != lastTick)
			{
				lastTick = SystemTick.tick;
				send = 0;
			}

			if(++send < 2)
			{
				USART3->DR	= buffers.tx.buffer[buffers.tx.read];
				if(++buffers.tx.read >= BUFFER_SIZE) buffers.tx.read = 0;
			}
		}
		else USART_ITConfig(USART3,USART_IT_TXE ,DISABLE);
	}

  if(USART3->SR & USART_FLAG_TC) USART_ClearITPendingBit(USART3, USART_IT_TC);
}

static void tx(char ch)
{
	buffers.tx.buffer[buffers.tx.wrote] = ch;
	if(++buffers.tx.wrote >= BUFFER_SIZE) buffers.tx.wrote = 0;
	USART_ITConfig(USART3, USART_IT_TXE, ENABLE);
}

static unsigned char rx(char *ch)
{
  if(buffers.rx.read == buffers.rx.wrote) return 0;
  *ch = buffers.rx.buffer[buffers.rx.read];
  if(++buffers.rx.read >= BUFFER_SIZE) buffers.rx.read = 0;
  available--;
  return 1;
}

static void txN(char *str, unsigned char number)
{
	for(int i=0; i<number; i++) tx(str[i]);
}

static unsigned char rxN(char *str, unsigned char number)
{
	int i;
	if(bytesAvailable() < number) return 0;
	for(i=0; i<number; i++) rx(&str[i]);
	return 1;
}

static void clearBuffers(void)
{
  __disable_irq();
  available			= 0;
  buffers.rx.read	= 0;
  buffers.rx.wrote	= 0;

  buffers.tx.read	= 0;
  buffers.tx.wrote	= 0;
  __enable_irq();
}

static unsigned char bytesAvailable()
{
	return available;
}

