#ifndef __RHINO_STANDALONE_H
	#define __RHINO_STANDALONE_H

	#include "board.h"

	typedef struct 	{ const enum IOS_STATES	TCLKx140, 		TCLKx236, 			TCLKx332; 		} TMCRhinoChopperOffTimeTypeDef;
	typedef struct 	{ const enum IOS_STATES	RSENSE_ONLY, 	INTERNAL_RSENSE, 	I_SCALE_ANALOG; } TMCRhinoCurrentSettingTypeDef;
	typedef struct 	{ const enum IOS_STATES	TOFF5, 			TOFF9, 				I_SCALE_ANALOG; } TMCRhinoChopperHysteresisTypeDef;
	typedef struct 	{ const enum IOS_STATES	BLANK16, 		BLANK24, 			BLANK36; 		} TMCRhinoChopperBlankTimeTypeDef;
	typedef struct 	{ const enum IOS_STATES	ENABLED_MAX,	DISABLED, 			ENABLED_034;	} TMCRhinoEnable_StStPwrDnTypeDef;
	typedef struct 	{ const enum IOS_STATES	BY1_INTERPOL0,
											BY2_INTERPOL0, 	BY2_INTERPOL256,
											BY4_INTERPOL0, 	BY4_INTERPOL256,	PWM_CHOP_BY4_INTERPOL256,
											BY16_INTERPOL0, BY16_INTERPOL256,	PWM_CHOP_BY16_INTERPOL256;
																								} TMCRhinoMicrosteResolutionTypeDef;

	typedef struct
	{
		enum IOS_STATES chopperOffTime;
		enum IOS_STATES	microsteResolution1;
		enum IOS_STATES	microsteResolution2;
		enum IOS_STATES currentSetting;
		enum IOS_STATES chopperHysteresis;
		enum IOS_STATES chopperBlankTime;
		enum IOS_STATES enable_StandStillPowerDown;
	}TMCRhinoTypeStandAloneConfigDef;

	typedef struct
	{
		const TMCRhinoChopperOffTimeTypeDef			ChopperOffTimeSettings;
		const TMCRhinoMicrosteResolutionTypeDef 	MicrosteResolutionSettings1;
		const TMCRhinoMicrosteResolutionTypeDef 	MicrosteResolutionSettings2;
		const TMCRhinoCurrentSettingTypeDef			CurrentSettings;
		const TMCRhinoChopperHysteresisTypeDef		ChopperHysteresisSettings;
		const TMCRhinoChopperBlankTimeTypeDef		ChopperBlankTimeSettings;
		const TMCRhinoEnable_StStPwrDnTypeDef		Enable_StandStillPowerDownSettings;
		const uint32 								resetSettings;

		void (*reset) (void);
		void (*setConfig) (TMCRhinoTypeStandAloneConfigDef *config);
		void (*getConfig) (TMCRhinoTypeStandAloneConfigDef *config);
		void (*setPins) (enum IOS_STATES *CFG);
		void (*getPins) (enum IOS_STATES *CFG);
		void (*setInt) (uint32 state);
		uint32 (*getInt) (void);
		IOPinTypeDef *CFGPins[7];

	} TMCRhinoTypeStandAloneDef;

	TMCRhinoTypeStandAloneDef TMCRhinoSA;

#endif
