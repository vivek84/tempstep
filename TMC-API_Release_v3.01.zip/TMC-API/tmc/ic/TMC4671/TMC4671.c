/*
 * TMC4671.c
 *
 *  Created on: 30.09.2016
 *      Author: ed
 *  Updated on: 15.11.2016 (bs)
 */
#include "TMC4671.h"

// motion modes
#define MOTION_MODE_STOPPED		0
#define MOTION_MODE_TORQUE		1
#define MOTION_MODE_VELOCITY	2
#define MOTION_MODE_POSITION	3
#define MOTION_MODE_UQ_UD_EXT	8

// PHI_E selections
#define PHI_E_EXTERNAL			1
#define PHI_E_OPEN_LOOP			2
#define PHI_E_ABN				3
#define PHI_E_HALL				5
#define PHI_E_AENC				6
#define PHI_A_AENC				7

#define STATE_NOTHING_TO_DO		0
#define STATE_START_INIT		1
#define STATE_WAIT_INIT_TIME	2
#define STATE_ESTIMATE_OFFSET	3

typedef struct
{
	u32 startVoltage;
	u16 initWaitTime;
	u16 actualInitWaitTime;
	u8 initState;
	u8 initMode;
	u16 torqueMeasurementFactor;	// u8.u8
	u8	motionMode;
} TMinimalMotorConfig;

TMinimalMotorConfig motorConfig;

// => SPI wrapper
extern int tmc4671_readInt(uint8 address);
extern void tmc4671_writeInt(uint8 address, int value);
extern u16 tmc4671_readRegister16BitValue(u8 address, u8 channel);
extern void tmc4671_writeRegister16BitValue(u8 address, u8 channel, u16 value);
// <= SPI wrapper

void tmc4671_init()
{
	motorConfig.initWaitTime = 1000;
	motorConfig.startVoltage = 6000;
	motorConfig.initMode = 0;
	motorConfig.torqueMeasurementFactor = 256;
}

void tmc4671_switchToMotionMode(u8 mode)
{
	// switch motion mode
	u32 actualModeRegister = tmc4671_readInt(TMC4671_MODE_RAMP_MODE_MOTION);
	actualModeRegister &= 0xFFFFFF00;
	actualModeRegister |= mode;
	tmc4671_writeInt(TMC4671_MODE_RAMP_MODE_MOTION, actualModeRegister);
}

void tmc4671_setTargetTorque_raw(s32 targetTorque)
{
	tmc4671_switchToMotionMode(MOTION_MODE_TORQUE);
	tmc4671_writeRegister16BitValue(TMC4671_PID_TORQUE_FLUX_TARGET, Bit16to31, targetTorque);
}

s32 tmc4671_getTargetTorque_raw()
{
	tmc4671_writeInt(TMC4671_INTERIM_ADDR, 0);
	return (s32)tmc4671_readInt(TMC4671_INTERIM_DATA);
}

s32 tmc4671_getActualTorque_raw()
{
	return (s16)tmc4671_readRegister16BitValue(TMC4671_PID_TORQUE_FLUX_ACTUAL, Bit16to31);
}

s32 tmc4671_getActualRampTorque_raw()
{
	// todo
	return 0;
}

void tmc4671_setTargetTorque_mA(s32 targetTorque)
{
	tmc4671_switchToMotionMode(MOTION_MODE_TORQUE);
	tmc4671_writeRegister16BitValue(TMC4671_PID_TORQUE_FLUX_TARGET, Bit16to31, (targetTorque * 256) / (s32)motorConfig.torqueMeasurementFactor);
}

s32 tmc4671_getTargetTorque_mA()
{
	return (tmc4671_getTargetTorque_raw() * (s32)motorConfig.torqueMeasurementFactor) / 256;
}

s32 tmc4671_getActualTorque_mA()
{
	return (tmc4671_getActualTorque_raw() * (s32)motorConfig.torqueMeasurementFactor) / 256;
}

s32 tmc4671_getActualRampTorque_mA()
{
	// todo
	return 0;
}

void tmc4671_setTargetFlux_raw(s32 targetFlux)
{
	// do not change the MOTION_MODE here! target flux can also be used during velocity and position modes
	tmc4671_writeRegister16BitValue(TMC4671_PID_TORQUE_FLUX_TARGET, Bit0to15, targetFlux);
}

s32 tmc4671_getTargetFlux_raw()
{
	tmc4671_writeInt(TMC4671_INTERIM_ADDR, 1);
	return (s32)tmc4671_readInt(TMC4671_INTERIM_DATA);
}

s32 tmc4671_getActualFlux_raw()
{
	return (s16)tmc4671_readRegister16BitValue(TMC4671_PID_TORQUE_FLUX_ACTUAL, Bit0to15);
}

void tmc4671_setTargetFlux_mA(s32 targetFlux)
{
	// do not change the MOTION_MODE here! target flux can also be used during velocity and position modes
	tmc4671_writeRegister16BitValue(TMC4671_PID_TORQUE_FLUX_TARGET, Bit0to15, (targetFlux * 256) / (s32)motorConfig.torqueMeasurementFactor);
}

s32 tmc4671_getTargetFlux_mA()
{
	return (tmc4671_getTargetFlux_raw() * (s32)motorConfig.torqueMeasurementFactor) / 256;
}

s32 tmc4671_getActualFlux_mA()
{
	return (tmc4671_getActualFlux_raw() * (s32)motorConfig.torqueMeasurementFactor) / 256;
}

void tmc4671_setTorqueFluxLimit_mA(s32 max)
{
	tmc4671_writeRegister16BitValue(TMC4671_PID_TORQUE_FLUX_LIMITS, Bit0to15, (max * 256) / (s32)motorConfig.torqueMeasurementFactor);
}

s32 tmc4671_getTorqueFluxLimit_mA()
{
	return ((s32)tmc4671_readRegister16BitValue(TMC4671_PID_TORQUE_FLUX_LIMITS, Bit0to15) * (s32)motorConfig.torqueMeasurementFactor) / 256;
}

void tmc4671_setTargetVelocity(s32 targetVelocity)
{
	tmc4671_switchToMotionMode(MOTION_MODE_VELOCITY);
	tmc4671_writeInt(TMC4671_PID_VELOCITY_TARGET, targetVelocity);
}

s32 tmc4671_getTargetVelocity()
{
	return (s32)tmc4671_readInt(TMC4671_PID_VELOCITY_TARGET);
}

s32 tmc4671_getActualVelocity()
{
	return (s32)tmc4671_readInt(TMC4671_PID_VELOCITY_ACTUAL);
}

s32 tmc4671_getActualRampVelocity()
{
	// todo:
	return 0;
}

void tmc4671_setAbsolutTargetPosition(s32 targetPosition)
{
	tmc4671_switchToMotionMode(MOTION_MODE_POSITION);
	tmc4671_writeInt(TMC4671_PID_POSITION_TARGET, targetPosition);
}

void tmc4671_setRelativeTargetPosition(s32 relativePosition)
{
	tmc4671_switchToMotionMode(MOTION_MODE_POSITION);
	// determine actual position and add relative position ticks
	tmc4671_writeInt(TMC4671_PID_POSITION_TARGET, (s32)tmc4671_readInt(TMC4671_PID_POSITION_ACTUAL) + relativePosition);
}

s32 tmc4671_getTargetPosition()
{
	return (s32)tmc4671_readInt(TMC4671_PID_POSITION_TARGET);
}

void tmc4671_setActualPosition(s32 actualPosition)
{
	tmc4671_writeInt(TMC4671_PID_POSITION_ACTUAL, actualPosition);
}

s32 tmc4671_getActualPosition()
{
	return (s32)tmc4671_readInt(TMC4671_PID_POSITION_ACTUAL);
}

s32 tmc4671_getActualRampPosition()
{
	// todo:
	return 0;
}

// encoder initialization
void tmc4671_doEncoderInitializationMode0()
{
	static uint16 last_Phi_E_Selection = 0;
	static uint32 last_UQ_UD_EXT = 0;
	static s16 last_PHI_E_EXT = 0;

	//debug_setTestVar9(minimalMotorConfig.initState * 100);

	switch (motorConfig.initState)
	{
		case STATE_NOTHING_TO_DO:
			motorConfig.actualInitWaitTime =  0;
			break;
		case STATE_START_INIT: // started by writing 1 to initState

			// save actual set values for PHI_E_SELECTION, UQ_UD_EXT, and PHI_E_EXT
			last_Phi_E_Selection = (u16)tmc4671_readRegister16BitValue(TMC4671_PHI_E_SELECTION, Bit0to15);
			last_UQ_UD_EXT = (u32)tmc4671_readInt(TMC4671_UQ_UD_EXT);
			last_PHI_E_EXT = (s16)tmc4671_readRegister16BitValue(TMC4671_PHI_E_EXT, Bit0to15);

			// set ABN_DECODER_PHI_E_OFFSET to zero
			tmc4671_writeRegister16BitValue(TMC4671_ABN_DECODER_PHI_E_PHI_M_OFFSET, Bit16to31, 0);

			// select phi_e_ext
			tmc4671_writeRegister16BitValue(TMC4671_PHI_E_SELECTION, Bit0to15, 1);

			// set an initialization voltage on UD_EXT (to the flux, not the torque!)
			tmc4671_writeRegister16BitValue(TMC4671_UQ_UD_EXT, Bit16to31, 0);
			tmc4671_writeRegister16BitValue(TMC4671_UQ_UD_EXT, Bit0to15, motorConfig.startVoltage);

			// set the "zero" angle
			tmc4671_writeRegister16BitValue(TMC4671_PHI_E_EXT, Bit0to15, 0);

			motorConfig.initState = STATE_WAIT_INIT_TIME;
			break;
		case STATE_WAIT_INIT_TIME:
			// wait until initialization time is over (until no more vibration on the motor)
			motorConfig.actualInitWaitTime++;
			if (motorConfig.actualInitWaitTime >= motorConfig.initWaitTime)
			{
				// set internal encoder value to zero
				tmc4671_writeInt(TMC4671_ABN_DECODER_COUNT, 0);

				// switch back to last used UQ_UD_EXT setting
				tmc4671_writeInt(TMC4671_UQ_UD_EXT, last_UQ_UD_EXT);

				// set PHI_E_EXT back to last value
				tmc4671_writeRegister16BitValue(TMC4671_PHI_E_EXT, Bit0to15, last_PHI_E_EXT);

				// switch back to last used PHI_E_SELECTION setting
				tmc4671_writeRegister16BitValue(TMC4671_PHI_E_SELECTION, Bit0to15, last_Phi_E_Selection);

				// go to next state
				motorConfig.initState = STATE_ESTIMATE_OFFSET;
			}
			break;
		case STATE_ESTIMATE_OFFSET:
			// todo: do offset estimation here

			// wait for N-Channel if available

			// go to ready state
			motorConfig.initState = 0;
			break;
		default:
			motorConfig.initState = 0;
			break;
	}
}

s16 tmc4671_getS16CircleDifference(s16 newValue, s16 oldValue)
{
	return (newValue - oldValue);
}

void tmc4671_doEncoderInitializationMode2()
{
	static s16 hall_phi_e_old = 0;
	static s16 hall_phi_e_new = 0;
	static s16 actual_coarse_offset = 0;

	//debug_setTestVar9(minimalMotorConfig.initState * 100);

	switch (motorConfig.initState)
	{
		case STATE_NOTHING_TO_DO:
			motorConfig.actualInitWaitTime =  0;
			break;
		case STATE_START_INIT: // started by writing 1 to initState
			// turn hall_mode interpolation off (read, clear bit 8, write back)
			tmc4671_writeInt(TMC4671_HALL_MODE, tmc4671_readInt(TMC4671_HALL_MODE) & 0xFFFFFEFF);

			// set ABN_DECODER_PHI_E_OFFSET to zero
			tmc4671_writeRegister16BitValue(TMC4671_ABN_DECODER_PHI_E_PHI_M_OFFSET, Bit16to31, 0);

			// read actual hall angle
			hall_phi_e_old = (s16)tmc4671_readRegister16BitValue(TMC4671_HALL_PHI_E_INTERPOLATED_PHI_E, Bit0to15);
			debug_setTestVar7(hall_phi_e_old);
			debug_setTestVar8(hall_phi_e_old);

			// read actual abn_decoder angle and compute difference to actual hall angle
			actual_coarse_offset = tmc4671_getS16CircleDifference(hall_phi_e_old, (s16)tmc4671_readRegister16BitValue(TMC4671_ABN_DECODER_PHI_E_PHI_M, Bit16to31));

			// set ABN_DECODER_PHI_E_OFFSET to actual hall-abn-difference, to use the actual hall angle for coarse initialization
			tmc4671_writeRegister16BitValue(TMC4671_ABN_DECODER_PHI_E_PHI_M_OFFSET, Bit16to31, actual_coarse_offset);

			motorConfig.initState = STATE_WAIT_INIT_TIME;
			break;
		case STATE_WAIT_INIT_TIME:
			// read actual hall angle
			hall_phi_e_new = (s16)tmc4671_readRegister16BitValue(TMC4671_HALL_PHI_E_INTERPOLATED_PHI_E, Bit0to15);

			// wait until hall angle changed
			if (hall_phi_e_old != hall_phi_e_new)
			{
				debug_setTestVar8(hall_phi_e_new);

				// estimated value = old value + diff between old and new (handle s16 overrun)
				s16 hall_phi_e_estimated = hall_phi_e_old + tmc4671_getS16CircleDifference(hall_phi_e_new, hall_phi_e_old)/2;
				debug_setTestVar6(hall_phi_e_estimated);

				// read actual abn_decoder angle and consider last set abn_decoder_offset
				s16 abn_phi_e_actual = (s16)tmc4671_readRegister16BitValue(TMC4671_ABN_DECODER_PHI_E_PHI_M, Bit16to31) - actual_coarse_offset;

				// set ABN_DECODER_PHI_E_OFFSET to actual estimated angle - abn_phi_e_actual difference
				tmc4671_writeRegister16BitValue(TMC4671_ABN_DECODER_PHI_E_PHI_M_OFFSET, Bit16to31, tmc4671_getS16CircleDifference(hall_phi_e_estimated, abn_phi_e_actual));

				// go to ready state
				motorConfig.initState = 0;
			}
			break;
		default:
			motorConfig.initState = 0;
			break;
	}
}

void tmc4671_checkEncderInitialization(u32 actualSystick)
{
	// use the systick as 1ms timer for encoder initialization
	static uint32 lastSystick = 0;
	if (actualSystick != lastSystick)
	{
		// needs timer to use the wait time
		if (motorConfig.initMode == 0)
		{
			tmc4671_doEncoderInitializationMode0();
		}
		lastSystick = actualSystick;
	}

	// needs no timer
	if (motorConfig.initMode == 2)
	{
		tmc4671_doEncoderInitializationMode2();
	}
}

void tmc4671_periodicJob(u32 actualSystick)
{
	tmc4671_checkEncderInitialization(actualSystick);
}

void tmc4671_setTorqueMeasurementFactor(u16 factor)
{
	motorConfig.torqueMeasurementFactor = factor;
}

u16 tmc4671_getTorqueMeasurementFactor()
{
	return motorConfig.torqueMeasurementFactor;
}

void tmc4671_startEncoderInitialization(u8 mode)
{
	// allow only a new initialization if no actual initialization is running
	if (motorConfig.initState == STATE_NOTHING_TO_DO)
	{
		if (mode == 0)		// estimate offset
		{
			// set mode
			motorConfig.initMode = 0;

			// start initialization
			motorConfig.initState = 1;
		}
		else if (mode == 2)	// use hall sensor signals
		{
			// set mode
			motorConfig.initMode = 2;

			// start initialization
			motorConfig.initState = 1;
		}
	}
}

u8 tmc4671_getEncoderInitMode()
{
	return motorConfig.initMode;
}

u8 tmc4671_getEncoderInitState()
{
	return motorConfig.initState;
}

u16 tmc4671_getEncoderWaitTime()
{
	return motorConfig.actualInitWaitTime;
}

void tmc4671_disablePWM()
{
	tmc4671_writeInt(TMC4671_PWM_SV_CHOP, 0);
}

void tmc4671_load_BLDC_Eval_Defaults()
{
	tmc4671_writeInt(TMC4671_MOTOR_TYPE_N_POLE_PAIRS, 0x000010004);	// select 4 pole pairs and motor type BLDC
	tmc4671_writeInt(TMC4671_PWM_POLARITIES, 1);              		// Low Side 1, and High Side 0
	tmc4671_writeInt(TMC4671_PWM_SV_CHOP, 7);                 		// centered PWM for FOC
}

void tmc4671_load_Stepper_Eval_Defaults()
{
	tmc4671_writeInt(TMC4671_MOTOR_TYPE_N_POLE_PAIRS, 50);    	// select 50 pole pairs and motor type Stepper
	tmc4671_writeInt(TMC4671_PWM_POLARITIES, 0);              	// Low Side 0, and High Side 0
	tmc4671_writeInt(TMC4671_PWM_SV_CHOP, 7);                 	// centered PWM for FOC
}

void tmc4671_start_Open_Loop_Test()
{
	tmc4671_writeInt(TMC4671_PHI_E_SELECTION, PHI_E_OPEN_LOOP);
	tmc4671_writeRegister16BitValue(TMC4671_MODE_RAMP_MODE_MOTION, Bit0to15, MOTION_MODE_UQ_UD_EXT);
	tmc4671_writeInt(TMC4671_UQ_UD_EXT, 2000);					// select UQ_EXT=0, UD_EXT=2000
	tmc4671_writeInt(TMC4671_OPENLOOP_ACCELERATION, 60);      	// 60 [rpm/s]
	tmc4671_writeInt(TMC4671_OPENLOOP_VELOCITY_TARGET, 5);
}

void tmc4671_load_Hall_Config(u32 mode, u16 PHI_M_Offset, u16 PHI_E_Offset)
{
	tmc4671_writeInt(TMC4671_HALL_MODE, mode);
	tmc4671_writeRegister16BitValue(TMC4671_HALL_PHI_E_PHI_M_OFFSET, Bit0to15, PHI_M_Offset);
	tmc4671_writeRegister16BitValue(TMC4671_HALL_PHI_E_PHI_M_OFFSET, Bit16to31, PHI_E_Offset);
	tmc4671_writeRegister16BitValue(TMC4671_MODE_RAMP_MODE_MOTION, Bit0to15, MOTION_MODE_STOPPED);
	tmc4671_writeInt(TMC4671_PHI_E_SELECTION, PHI_E_HALL);
}

void tmc4671_load_ABN_Config()
{
	tmc4671_writeRegister16BitValue(TMC4671_MODE_RAMP_MODE_MOTION, Bit0to15, MOTION_MODE_STOPPED);
	tmc4671_writeInt(TMC4671_PHI_E_SELECTION, PHI_E_ABN);
}

void tmc4671_loadDefaultPISettings()
{
	tmc4671_writeInt(TMC4671_PID_FLUX_P_FLUX_I, 0x00FF0200);
	tmc4671_writeInt(TMC4671_PID_TORQUE_P_TORQUE_I, 0x00FF0200);
	tmc4671_writeInt(TMC4671_PID_VELOCITY_P_VELOCITY_I, 0x00FF0200);
	tmc4671_writeInt(TMC4671_PID_POSITION_P_POSITION_I, 0x00200000);
}
