/*
 * TMC4671.h
 *
 *  Created on: 30.09.2016
 *      Author: ed
 *  Updated on: 15.11.2016 (bs)
 */

#ifndef API_IC_TMC4671_H
#define API_IC_TMC4671_H

	#include "../../helpers/API_Header.h"
	#include "TMC4671_Register.h"

	void tmc4671_init();
	void tmc4671_periodicJob(u32 actualSystick);

	void tmc4671_setTorqueMeasurementFactor(u16 factor);
	u16 tmc4671_getTorqueMeasurementFactor();

	// encoder functions
	void tmc4671_startEncoderInitialization(u8 mode);
	u8 tmc4671_getEncoderInitMode();
	u8 tmc4671_getEncoderInitState();
	u16 tmc4671_getEncoderWaitTime();

	// === modes of operation ===
	void tmc4671_switchToMotionMode(u8 mode);

	// torque mode
	void tmc4671_setTargetTorque_raw(s32 targetTorque);
	s32 tmc4671_getTargetTorque_raw();
	s32 tmc4671_getActualTorque_raw();
	s32 tmc4671_getActualRampTorque_raw();

	void tmc4671_setTargetTorque_mA(s32 targetTorque);
	s32 tmc4671_getTargetTorque_mA();
	s32 tmc4671_getActualTorque_mA();
	s32 tmc4671_getActualRampTorque_mA();

	// flux
	void tmc4671_setTargetFlux_raw(s32 targetFlux);
	s32 tmc4671_getTargetFlux_raw();
	s32 tmc4671_getActualFlux_raw();

	void tmc4671_setTargetFlux_mA(s32 targetFlux);
	s32 tmc4671_getTargetFlux_mA();
	s32 tmc4671_getActualFlux_mA();

	// torque/flux limit
	void tmc4671_setTorqueFluxLimit_mA(s32 max);
	s32 tmc4671_getTorqueFluxLimit_mA();

	// velocity mode
	void tmc4671_setTargetVelocity(s32 targetVelocity);
	s32 tmc4671_getTargetVelocity();
	s32 tmc4671_getActualVelocity();
	s32 tmc4671_getActualRampVelocity();

	// position mode
	void tmc4671_setAbsolutTargetPosition(s32 targetPosition);
	void tmc4671_setRelativeTargetPosition(s32 relativePosition);
	s32 tmc4671_getTargetPosition();
	void tmc4671_setActualPosition(s32 actualPosition);
	s32 tmc4671_getActualPosition();
	s32 tmc4671_getActualRampPosition();

	// evaluation
	void tmc4671_disablePWM();
	void tmc4671_load_BLDC_Eval_Defaults();
	void tmc4671_load_Stepper_Eval_Defaults();
	void tmc4671_start_Open_Loop_Test();
	void tmc4671_load_Hall_Config(u32 mode, u16 PHI_M_Offset, u16 PHI_E_Offset);
	void tmc4671_load_ABN_Config();
	void tmc4671_loadDefaultPISettings();

#endif
